import type { MetadataRoute } from 'next';

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Intellect Olympiad — Onlayn Olimpiada Platformasi',
    short_name: 'Intellect Olympiad',
    description: "«SIFAT TA'LIM XIZMATI» MChJ tomonidan tashkil etilgan onlayn olimpiada platformasi.",
    start_url: '/',
    display: 'standalone',
    background_color: '#f2f5f8',
    theme_color: '#0877B5',
    lang: 'uz',
    icons: [
      { src: '/favicon.svg', sizes: 'any', type: 'image/svg+xml' },
      { src: '/logo-mark.svg', sizes: 'any', type: 'image/svg+xml', purpose: 'any' },
    ],
  };
}
