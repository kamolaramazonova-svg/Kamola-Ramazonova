export const metadata = { title: 'Bog‘lanish — Intellect Olympiad' };

export default function ContactPage() {
  return (
    <main className="min-h-screen bg-parchment-2 py-16">
      <div className="max-w-[760px] mx-auto px-6">
        <a href="/" className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-ink-2 bg-surface border border-line-2 rounded-lg px-3 py-2 hover:border-bordo hover:text-bordo transition-colors"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>Bosh sahifa</a>
        <h1 className="font-serif text-3xl font-semibold mt-4 mb-2">Bog‘lanish</h1>
        <p className="text-ink-2 text-[15px] mb-8">Savol, hamkorlik yoki maktab/litsey paketlari bo‘yicha biz bilan bog‘laning.</p>

        <div className="grid sm:grid-cols-2 gap-4">
          {[
            { l: 'Telefon', v: '+998 90 036 21 21 · +998 90 068 44 20' },
            { l: 'Telegram bot', v: '@Intellect_Olympiad_bot' },
            { l: 'Manzil', v: 'Toshkent sh., Uchtepa tumani, Degrez MFY, Beshqayrag‘och ko‘chasi, 12A-uy' },
            { l: 'Tashkilot', v: '“SIFAT TA’LIM XIZMATI” MChJ' },
          ].map((c) => (
            <div key={c.l} className="bg-surface border border-line rounded-lg p-5">
              <div className="text-[11px] uppercase tracking-[.1em] text-muted font-bold mb-1">{c.l}</div>
              <div className="text-ink font-semibold text-[15px]">{c.v}</div>
            </div>
          ))}
        </div>

        {/* Rasmiy rekvizitlar */}
        <div className="mt-6 bg-surface border border-line rounded-lg p-6">
          <h2 className="font-serif text-[18px] font-semibold mb-4">Rasmiy rekvizitlar</h2>
          <div className="grid sm:grid-cols-2 gap-x-8 gap-y-3 text-[14px]">
            {[
              ['Tashkilot', '“SIFAT TA’LIM XIZMATI” MChJ'],
              ['STIR (INN)', '310241724'],
              ['OKED', '79400'],
              ['Hisob raqam', '20208000605616986001'],
              ['Bank', '“ASIA ALLIANCE BANK” ATB, Toshkent'],
              ['MFO', '01095'],
              ['Direktor', 'Agzamova X. M.'],
              ['Manzil', 'Toshkent sh., Uchtepa tumani, Degrez MFY, Beshqayrag‘och ko‘chasi, 12A-uy'],
            ].map(([l, v]) => (
              <div key={l} className="flex flex-col">
                <span className="text-[11px] uppercase tracking-[.08em] text-muted font-bold">{l}</span>
                <span className="text-ink font-semibold">{v}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6 bg-surface border border-line rounded-lg p-6">
          <h2 className="font-serif text-[18px] font-semibold mb-2">Maktablar uchun hamkorlik</h2>
          <p className="text-ink-2 text-[14.5px] leading-relaxed">
            Maktab va litseylar uchun maxsus korporativ paket mavjud — barcha o‘quvchilaringizni
            yagona platformada boshqaring. Batafsil ma‘lumot uchun yuqoridagi telefon orqali murojaat qiling.
          </p>
        </div>
      </div>
    </main>
  );
}
