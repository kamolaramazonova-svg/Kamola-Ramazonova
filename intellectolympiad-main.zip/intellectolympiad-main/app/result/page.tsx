'use client';
import { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { results, BASE, type MyResultResponse } from '@/lib/api';
import { LoadingRow } from '@/components/Spinner';
import { getToken, getUser } from '@/lib/auth';

const IcDownload = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
    <polyline points="7 10 12 15 17 10" />
    <line x1="12" y1="15" x2="12" y2="3" />
  </svg>
);

const IcShare = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="18" cy="5" r="3" />
    <circle cx="6" cy="12" r="3" />
    <circle cx="18" cy="19" r="3" />
    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49" />
    <line x1="15.41" y1="6.51" x2="8.59" y2="10.49" />
  </svg>
);

function fmtTime(sec: number | null) {
  if (sec == null) return '—';
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return h > 0
    ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
    : `${m}:${String(s).padStart(2, '0')}`;
}

export default function ResultPageWrapper() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center bg-parchment"><LoadingRow /></div>}>
      <ResultPage />
    </Suspense>
  );
}

function ResultPage() {
  const router = useRouter();
  const sp = useSearchParams();
  const sessionId = sp.get('sessionId') ?? '';

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [data, setData] = useState<MyResultResponse | null>(null);

  useEffect(() => {
    const token = getToken();
    if (!token) { router.replace('/login'); return; }
    if (!sessionId) { setError("Sessiya ID topilmadi"); setLoading(false); return; }
    results.mine(token, sessionId)
      .then(setData)
      .catch(err => setError(err?.message ?? 'Natijani yuklashda xatolik'))
      .finally(() => setLoading(false));
  }, [sessionId, router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-parchment p-6">
        <div className="text-center anim-fade-up">
          <div className="anim-float mb-4 inline-block">
            <img src="/logo-mark.svg" alt="IO" className="w-14 h-14" />
          </div>
          <div className="text-muted text-[14px] timer-pulse">Natija yuklanmoqda…</div>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-parchment p-6">
        <div className="max-w-[440px] w-full bg-surface border border-line rounded-2xl p-8 sm:p-10 text-center shadow-sm anim-fade-up">
          <div className="relative w-[72px] h-[72px] mx-auto mb-5">
            <span className="absolute inset-0 rounded-full anim-ring bg-ds-red/30" />
            <span className="absolute inset-0 rounded-full anim-ring bg-ds-red/25" style={{ animationDelay: '.7s' }} />
            <div className="relative w-[72px] h-[72px] rounded-full flex items-center justify-center anim-pop bg-ds-red-tint text-ds-red">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 9v4M12 17h.01" /><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z" /></svg>
            </div>
          </div>
          <h2 className="font-serif text-[21px] font-semibold mb-2 anim-fade-up" style={{ animationDelay: '.08s' }}>Xatolik</h2>
          <p className="text-[14px] text-muted mb-6 leading-relaxed anim-fade-up" style={{ animationDelay: '.14s' }}>{error || 'Natija topilmadi'}</p>
          <div className="anim-fade-up" style={{ animationDelay: '.2s' }}>
            <button onClick={() => router.push('/cabinet')}
              className="font-semibold text-[14px] px-6 py-[11px] rounded-lg bg-bordo text-white hover:bg-bordo-700 border-none cursor-pointer transition-colors">
              Kabinetga qaytish
            </button>
          </div>
        </div>
      </div>
    );
  }

  const isInProgress = data.status === 'IN_PROGRESS' || data.status === 'NOT_STARTED';
  if (isInProgress) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-parchment p-6">
        <div className="max-w-[440px] w-full bg-surface border border-line rounded-2xl p-8 sm:p-10 text-center shadow-sm anim-fade-up">
          <div className="relative w-[72px] h-[72px] mx-auto mb-5">
            <span className="absolute inset-0 rounded-full anim-ring bg-ds-amber/30" />
            <span className="absolute inset-0 rounded-full anim-ring bg-ds-amber/25" style={{ animationDelay: '.7s' }} />
            <div className="relative w-[72px] h-[72px] rounded-full flex items-center justify-center anim-pop bg-ds-amber-tint text-ds-amber">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></svg>
            </div>
          </div>
          <h2 className="font-serif text-[21px] font-semibold mb-2 anim-fade-up" style={{ animationDelay: '.08s' }}>Imtihon hali yakunlanmagan</h2>
          <p className="text-[14px] text-muted mb-6 leading-relaxed anim-fade-up" style={{ animationDelay: '.14s' }}>Natijani ko&apos;rish uchun avval testni yakunlang.</p>
          <div className="anim-fade-up" style={{ animationDelay: '.2s' }}>
            <button onClick={() => router.push(`/exam?olympiadId=${data.olympiadId}`)}
              className="font-semibold text-[14px] px-6 py-[11px] rounded-lg bg-bordo text-white hover:bg-bordo-700 border-none cursor-pointer transition-colors">
              Imtihonga qaytish
            </button>
          </div>
        </div>
      </div>
    );
  }

  const user = getUser();
  const fullName = user ? `${user.firstName} ${user.lastName}` : 'Ishtirokchi';
  const score = data.score ?? 0;
  const maxScore = data.totalScore ?? 100;
  const pct = maxScore > 0 ? (score / maxScore) * 100 : 0;
  const passed = data.passed;
  const disqualified = data.status === 'DISQUALIFIED';
  const timedOut = data.status === 'TIMED_OUT';

  const R = 74;
  const CIRC = 2 * Math.PI * R;
  const OFFSET = CIRC - (pct / 100) * CIRC;
  const ringColor = passed ? '#2e6b4f' : '#9c2b2b';
  const scoreColor = passed ? 'text-ds-green' : 'text-ds-red';

  const stats = [
    { v: String(data.answeredCount), l: "Javob berilgan savol", col: 'text-ink' },
    { v: fmtTime(data.timeTakenSec), l: 'Sarflangan vaqt', col: 'text-ink' },
    { v: `${score}/${maxScore}`, l: 'Ball', col: scoreColor },
    { v: passed ? "O'tdi" : disqualified ? 'Diskval.' : timedOut ? 'Vaqt tugadi' : "O'tmadi", l: 'Holat', col: passed ? 'text-ds-green' : 'text-ds-red' },
  ];

  return (
    <div className="min-h-screen bg-parchment">
      {/* Top bar */}
      <div className="bg-bordo-900 text-white sticky top-0 z-30">
        <div className="max-w-wrap mx-auto px-6 flex items-center justify-between min-h-[60px] gap-4">
          <a href="/cabinet" className="flex items-center gap-3 flex-none">
            <img src="/logo-mark-light.svg" alt="IO" className="w-9 h-9 flex-none" />
            <div className="flex flex-col leading-[1.05]">
              <b className="font-serif font-semibold text-sm text-white">Intellect Olympiad</b>
              <small className="text-[#b6c7d6]" style={{ fontSize: 10.5 }}>Natija</small>
            </div>
          </a>
          <a href="/cabinet" className="text-[13px] font-semibold px-4 py-[7px] rounded border border-white/25 bg-transparent text-white hover:bg-white/10 transition-colors">
            ← Kabinetga qaytish
          </a>
        </div>
      </div>

      {/* Hero */}
      <section className="bg-gradient-to-b from-surface to-parchment border-b border-line py-[44px] px-6 text-center">
        <div className="max-w-wrap mx-auto">
          {/* Score ring */}
          <div className="w-[120px] h-[120px] sm:w-[168px] sm:h-[168px] mx-auto mb-5 relative">
            <svg width="168" height="168" viewBox="0 0 168 168" className="w-full h-full" style={{ transform: 'rotate(-90deg)' }}>
              <circle cx="84" cy="84" r={R} fill="none" stroke="#dce3eb" strokeWidth="14" />
              <circle cx="84" cy="84" r={R} fill="none"
                stroke={ringColor} strokeWidth="14" strokeLinecap="round"
                strokeDasharray={CIRC} strokeDashoffset={OFFSET} />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <b className={`font-serif text-[34px] sm:text-[48px] font-bold leading-none ${scoreColor}`}>{score}</b>
              <span className="text-[13px] text-muted">{maxScore} balldan</span>
            </div>
          </div>

          <span className={`inline-flex items-center gap-2 ${passed ? 'bg-ds-green-tint text-ds-green' : 'bg-ds-red-tint text-ds-red'} text-[13px] font-bold px-4 py-[6px] rounded-full mb-[14px]`}>
            <span className="w-[7px] h-[7px] rounded-full bg-current inline-block" />
            {passed ? 'Muvaffaqiyatli yakunlandi' : disqualified ? 'Diskvalifikatsiya' : timedOut ? 'Vaqt tugagan' : "O'ta olmadingiz"}
          </span>

          <h1 className="font-serif text-[22px] sm:text-[30px] font-semibold text-ink mb-2 mt-[14px]">
            {passed ? `Tabriklaymiz, ${user?.firstName ?? ''}!` : 'Natija'}
          </h1>
          <p className="text-ink-2 mt-3">{data.olympiad.title}</p>

          {/* Stats grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-px bg-line border border-line rounded-lg overflow-hidden max-w-[720px] mx-auto mt-7">
            {stats.map((s, i) => (
              <div key={i} className="bg-surface py-[18px] px-5 text-center">
                <b className={`font-serif text-[22px] font-bold block ${s.col}`}>{s.v}</b>
                <span className="text-[11px] sm:text-[12.5px] text-muted">{s.l}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Body */}
      <section className="py-[44px] px-6 pb-[60px]">
        <div className="max-w-wrap mx-auto grid lg:grid-cols-2 gap-4 lg:gap-7 items-start">

          {/* Left: Summary */}
          <div className="bg-surface border border-line rounded-lg shadow-sm p-4 sm:p-7">
            <h3 className="font-serif text-[18px] font-semibold mb-1">Imtihon xulosasi</h3>
            <p className="text-[13.5px] text-muted mb-5">Tafsilotlar va keyingi qadamlar.</p>

            <div className="space-y-3 text-[13.5px]">
              {[
                ['Olimpiada', data.olympiad.title],
                ['O\'tish bali', `${data.olympiad.passScore} ball`],
                ['Sizning balingiz', `${score} / ${maxScore}`],
                ['Foiz', `${Math.round(pct)}%`],
                ['Javob berilgan savollar', String(data.answeredCount)],
                ['Sarflangan vaqt', fmtTime(data.timeTakenSec)],
                ['Holat', passed ? 'O\'tdi' : disqualified ? 'Diskvalifikatsiya' : timedOut ? 'Vaqt tugagan' : 'O\'ta olmadi'],
              ].map(([k, v]) => (
                <div key={k} className="flex items-center justify-between border-b border-line py-2 last:border-0">
                  <span className="text-muted">{k}</span>
                  <b className="text-ink font-semibold">{v}</b>
                </div>
              ))}
            </div>

            {!passed && (
              <div className="mt-5 bg-ds-amber-tint border border-ds-amber/30 rounded-lg px-4 py-3 text-[13px] text-[#7a5a1a]">
                <b className="block mb-1">Ko&apos;proq mashq qiling</b>
                Keyingi olimpiadalarga tayyorgarlik ko&apos;rish uchun bizning yangiliklar va materiallarimizdan foydalaning.
              </div>
            )}
          </div>

          {/* Right: Certificate or status */}
          <div className="lg:sticky lg:top-[88px]">
            {passed && data.certificate ? (
              <>
                <div className="relative rounded-lg p-5 sm:p-[38px_40px_32px] border border-line-2 shadow-lg text-center"
                  style={{ background: 'linear-gradient(155deg,#fbfdff,#f7f0e6)', boxShadow: '0 18px 48px rgba(31,27,25,.13)' }}>
                  <div className="absolute inset-3 border-2 rounded pointer-events-none" style={{ borderColor: 'rgba(154,123,63,.4)', borderRadius: 6 }} />
                  <div className="absolute inset-4 border rounded pointer-events-none" style={{ borderColor: 'rgba(154,123,63,.2)', borderRadius: 4 }} />

                  <div className="relative text-center">
                    <img src="/logo-mark.svg" alt="IO" className="w-16 h-16 mx-auto mb-[14px]" />
                    <div className="font-mono text-[11px] tracking-[.2em] uppercase text-gold">Intellect Olympiad</div>
                    <div className="font-serif text-[26px] font-bold text-bordo mt-[6px] mb-1">SERTIFIKAT</div>
                    <div className="text-[13px] text-ink-2">Ushbu sertifikat</div>
                    <div className="font-serif text-[26px] font-bold text-ink my-2">{fullName}</div>
                    <p className="text-[14px] text-ink-2 mx-auto leading-[1.5]" style={{ maxWidth: '40ch' }}>
                      {data.olympiad.title}da <b>{score} ball</b> bilan <b>muvaffaqiyatli natija</b>ni qo&apos;lga kiritgani uchun beriladi.
                    </p>
                    <div className="w-20 h-[2px] bg-bordo mx-auto my-[14px]" />
                    <div className="font-mono text-[12px] text-bordo font-semibold mt-2">{data.certificate.certCode}</div>
                    <div className="font-mono text-[11px] text-muted mt-1">intellectolympiad.uz/verify</div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 mt-5">
                  {data.certificate && (
                    <a
                      href={`${BASE}/certificates/${data.certificate.certCode}/pdf`}
                      target="_blank" rel="noopener noreferrer"
                      className="flex-1 inline-flex items-center justify-center gap-2 font-semibold text-[14px] px-5 py-[10px] rounded bg-bordo text-white hover:bg-bordo-700 transition-colors border-none cursor-pointer">
                      <IcDownload /> PDF yuklab olish
                    </a>
                  )}
                  <button onClick={() => {
                    const url = `${location.origin}/verify?code=${data.certificate?.certCode}`;
                    navigator.clipboard?.writeText(url);
                    alert("Tekshirish havolasi nusxalandi");
                  }}
                    className="flex-1 inline-flex items-center justify-center gap-2 font-semibold text-[14px] px-5 py-[10px] rounded border border-line-2 bg-transparent text-ink hover:bg-parchment-2 transition-colors cursor-pointer">
                    <IcShare /> Ulashish
                  </button>
                </div>
                <p className="text-center text-[12.5px] text-muted mt-[14px]">QR-kod orqali sertifikat haqiqiyligini istalgan vaqtda tekshirish mumkin.</p>
              </>
            ) : passed ? (
              <div className="bg-surface border border-line rounded-lg p-4 sm:p-7 text-center">
                <h3 className="font-serif text-[18px] font-semibold mb-2">Sertifikat tayyorlanmoqda</h3>
                <p className="text-[13.5px] text-muted">Sertifikatingiz tez orada tayyor bo&apos;ladi. Iltimos, sahifani biroz vaqtdan keyin yangilang.</p>
              </div>
            ) : (
              <div className="bg-surface border border-line rounded-lg p-4 sm:p-7 text-center">
                <h3 className="font-serif text-[18px] font-semibold mb-2">Sertifikat berilmadi</h3>
                <p className="text-[13.5px] text-muted">
                  Sertifikat olish uchun kamida {data.olympiad.passScore} ball kerak edi. Sizning balingiz: {score} ball.
                </p>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
