export const metadata = { title: 'Foydalanish shartlari — Intellect Olympiad' };

export default function TermsPage() {
  return (
    <main className="min-h-screen bg-parchment-2 py-16">
      <div className="max-w-[760px] mx-auto px-6">
        <a href="/" className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-ink-2 bg-surface border border-line-2 rounded-lg px-3 py-2 hover:border-bordo hover:text-bordo transition-colors"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>Bosh sahifa</a>
        <h1 className="font-serif text-3xl font-semibold mt-4 mb-2">Foydalanish shartlari</h1>
        <p className="text-muted text-[13px] mb-8">Oxirgi yangilanish: 2026-yil</p>

        <div className="space-y-6 text-ink-2 text-[14.5px] leading-relaxed">
          <section>
            <h2 className="font-serif text-[18px] font-semibold text-ink mb-2">1. Umumiy qoidalar</h2>
            <p>Platformadan foydalanish orqali siz ushbu shartlarni qabul qilasiz. Intellect Olympiad — «SIFAT TA‘LIM XIZMATI» MChJ tomonidan tashkil etilgan onlayn olimpiada platformasi.</p>
          </section>
          <section>
            <h2 className="font-serif text-[18px] font-semibold text-ink mb-2">2. Ishtirok va to‘lov</h2>
            <p>Har bir olimpiada uchun alohida narx belgilanadi. To‘lov tasdiqlangach joy band qilinadi. Bir foydalanuvchi bir olimpiadaga faqat bir marta ishtirok etadi.</p>
          </section>
          <section>
            <h2 className="font-serif text-[18px] font-semibold text-ink mb-2">3. Halol ishtirok</h2>
            <p>Test davomida begona yordam, nusxa ko‘chirish yoki boshqa qurilmadan kirish taqiqlanadi. Qoidabuzarlik aniqlansa, ishtirokchi diskvalifikatsiya qilinadi va sertifikat berilmaydi.</p>
          </section>
          <section>
            <h2 className="font-serif text-[18px] font-semibold text-ink mb-2">4. To‘lovni qaytarish</h2>
            <p>To‘lov tasdiqlangandan so‘ng, texnik nosozlik platforma aybi bilan yuz bergan hollardan tashqari, mablag‘ qaytarilmaydi.</p>
          </section>
          <section>
            <h2 className="font-serif text-[18px] font-semibold text-ink mb-2">5. Sertifikat</h2>
            <p>Berilgan raqamli sertifikatlar QR-kod orqali tekshiriladi. Soxta sertifikatlardan foydalanish javobgarlikka olib keladi.</p>
          </section>
        </div>
      </div>
    </main>
  );
}
