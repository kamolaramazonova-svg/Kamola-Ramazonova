'use client';
import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { auth, users as usersApi } from '@/lib/api';
import { saveSession, getToken } from '@/lib/auth';
import SocialAuth from '@/components/SocialAuth';
import { Spinner } from '@/components/Spinner';
import { UZ_REGIONS, districtsByRegion } from '@/lib/uz-locations';
import { useLocale, LOCALES, LOCALE_LABEL, LOCALE_FULL } from '@/lib/locale';

const IcCheck = () => (<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>);

const STEPS_LABEL = ['Hisob ma’lumotlari', 'Yakunlash', 'Tayyor'];

const inputCls = 'w-full font-sans text-[15px] text-ink px-[13px] py-[11px] border border-line-2 rounded bg-surface transition-colors focus:outline-none focus:border-bordo focus:shadow-[0_0_0_3px_#e3f1f9]';

// Server rule: >=10 chars, upper + lower + digit + special
const pwChecks = (p: string) => ({
  len: p.length >= 10, lower: /[a-z]/.test(p), upper: /[A-Z]/.test(p), digit: /\d/.test(p), special: /[^A-Za-z0-9]/.test(p),
});
const pwOk = (p: string) => Object.values(pwChecks(p)).every(Boolean);

// ── Kiritishni tartiblash ───────────────────────────────────────────────────
// Telefon: +998 99 999 99 99
function fmtPhone(v: string): string {
  let d = v.replace(/\D/g, '');
  if (d.startsWith('998')) d = d.slice(3);
  d = d.slice(0, 9);
  if (!d) return '';
  let out = '+998';
  if (d.length) out += ' ' + d.slice(0, 2);
  if (d.length > 2) out += ' ' + d.slice(2, 5);
  if (d.length > 5) out += ' ' + d.slice(5, 7);
  if (d.length > 7) out += ' ' + d.slice(7, 9);
  return out;
}
// Pasport: 2 bosh harf (katta) + bo'sh joy + 7 raqam — "AD 3177775".
// Raqam bilan boshlansa — JSHSHIR (14 raqam), formatlanmaydi.
function fmtPassport(v: string): string {
  const a = v.toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!a) return '';
  if (/^[A-Z]/.test(a)) {
    const m = a.slice(0, 9).match(/^([A-Z]{0,2})(\d{0,7})/)!;
    const [, letters, digits] = m;
    return letters && digits ? `${letters} ${digits}` : `${letters}${digits}`;
  }
  return a.slice(0, 14); // JSHSHIR
}
// Ism/familiya: har so'zning bosh harfini katta qiladi
function capName(v: string): string {
  return v.replace(/(^|\s)(\p{L})/gu, (_, sp: string, c: string) => sp + c.toUpperCase());
}

export default function RegisterPage() {
  const router = useRouter();
  const [locale, setLocale] = useLocale();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ fname: '', lname: '', email: '', password: '', phone: '', pphone: '', passport: '', school: '', region: '', regionId: 0, district: '' });
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [asTeacher, setAsTeacher] = useState(false);
  const [refCode, setRefCode] = useState('');
  // Telegram/Google orqali kirgan bo'lsa: hisob allaqachon yaratilgan, faqat profil to'ldiriladi.
  const [socialMode, setSocialMode] = useState<null | 'telegram' | 'google'>(null);
  const [agreed, setAgreed] = useState(false); // Maxfiylik siyosati roziligi

  // Read referral / teacher params from the URL (no Suspense needed)
  useEffect(() => {
    const p = new URLSearchParams(window.location.search);
    const ref = p.get('ref');
    if (ref) setRefCode(ref.trim());
    if (p.get('ustoz') === '1' || p.get('teacher') === '1') setAsTeacher(true);
  }, []);

  const set = (k: keyof typeof form, v: string) => setForm(p => ({ ...p, [k]: v }));
  const checks = pwChecks(form.password);

  // Muvaffaqiyat ovozi — Web Audio (faylsiz). Foydalanuvchi bosganida ochiladi.
  const audioCtxRef = useRef<AudioContext | null>(null);
  const ensureAudio = () => {
    if (typeof window === 'undefined') return null;
    if (!audioCtxRef.current) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AC) audioCtxRef.current = new AC();
    }
    audioCtxRef.current?.resume().catch(() => {});
    return audioCtxRef.current;
  };
  const playSuccessChime = () => {
    const ctx = audioCtxRef.current;
    if (!ctx) return;
    const now = ctx.currentTime;
    const master = ctx.createGain();
    master.gain.value = 0.28; // o'rtacha ovoz
    master.connect(ctx.destination);
    [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => {   // C5–E5–G5–C6 mажор arpeggio
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = 'sine';
      o.frequency.value = f;
      o.connect(g); g.connect(master);
      const t = now + i * 0.11;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(1, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.55);
      o.start(t); o.stop(t + 0.6);
    });
  };
  // 3-qadamga (muvaffaqiyat) o'tilganda ovoz chalinadi (animatsiya CSS bilan).
  useEffect(() => {
    if (step === 3) playSuccessChime();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step]);

  const validateStep1 = () => {
    if (!form.fname.trim() || !form.lname.trim()) return 'Ism va familiyani kiriting';
    if (!socialMode) { // ijtimoiy kirish bo'lsa hisob bor — email/parol shart emas
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) return 'To‘g‘ri email kiriting';
      if (!pwOk(form.password)) return 'Parol talablariga javob bermaydi';
    }
    // Majburiy: telefon, (o'quvchi) ota-ona telefoni + pasport/JSHSHIR, viloyat, tuman
    if (form.phone.replace(/\D/g, '').length < 12) return 'Telefon raqamini to‘liq kiriting';
    if (!asTeacher) {
      if (form.pphone.replace(/\D/g, '').length < 12) return 'Ota-ona telefon raqamini to‘liq kiriting';
      if (form.passport.replace(/[^A-Za-z0-9]/g, '').length < 7) return 'Pasport yoki tug‘ilganlik guvohnomasi (JSHSHIR) ma’lumotini kiriting';
    }
    if (!form.region.trim()) return 'Viloyatni tanlang';
    if (!form.district.trim()) return 'Tuman / shaharni tanlang';
    return '';
  };

  const next1 = () => { const e = validateStep1(); if (e) { setError(e); return; } setError(''); setStep(2); };

  // Telegram/Google muvaffaqiyatli — hisob yaratildi, profilni to'ldirishga o'tamiz.
  const handleSocialAuthed = (res: { accessToken: string; user: { firstName: string; lastName: string; email: string; role: string } }) => {
    saveSession(res.accessToken, res.user as Parameters<typeof saveSession>[1]);
    setForm(f => ({ ...f, fname: res.user.firstName || f.fname, lname: res.user.lastName || f.lname, email: res.user.email || f.email }));
    setSocialMode(res.user.email ? 'google' : 'telegram');
    setError('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleRegister = async () => {
    if (!agreed) { setError("Davom etish uchun Maxfiylik siyosati va Foydalanish shartlariga rozilik bering"); return; }
    ensureAudio(); // bosish gesturida audio kontekstini ochamiz
    setSubmitting(true); setError('');
    try {
      if (socialMode) {
        // Hisob allaqachon mavjud (Telegram/Google) — faqat profil ma'lumotlarini saqlaymiz.
        const token = getToken();
        if (!token) throw new Error('Sessiya topilmadi, qaytadan kiring');
        await usersApi.updateProfile(token, {
          firstName: form.fname.trim(),
          lastName: form.lname.trim(),
          phone: form.phone.replace(/\s/g, '') || undefined,
          school: form.school.trim() || undefined,
          region: form.region.trim() || undefined,
          district: form.district.trim() || undefined,
          ...(!asTeacher && form.pphone.trim() && { parentPhone: form.pphone.replace(/\s/g, '') }),
          ...(!asTeacher && form.passport.trim() && { passport: form.passport.trim() }),
        });
        setStep(3);
        return;
      }
      const res = await auth.register({
        email: form.email.trim(),
        password: form.password,
        firstName: form.fname.trim(),
        lastName: form.lname.trim(),
        phone: form.phone.replace(/\s/g, '') || undefined,
        school: form.school.trim() || undefined,
        region: form.region.trim() || undefined,
        district: form.district.trim() || undefined,
        ...(!asTeacher && form.pphone.trim() && { parentPhone: form.pphone.replace(/\s/g, '') }),
        ...(!asTeacher && form.passport.trim() && { passport: form.passport.trim() }),
        ...(asTeacher && { asTeacher: true }),
        ...(refCode && !asTeacher && { ref: refCode }),
      });
      saveSession(res.accessToken, res.user);
      setStep(3);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Ro‘yxatdan o‘tishda xatolik');
    } finally { setSubmitting(false); }
  };

  return (
    <div className="min-h-screen bg-parchment">
      <header className="bg-surface border-b border-line">
        <div className="max-w-wrap mx-auto px-4 sm:px-6 flex items-center gap-3 sm:gap-4 min-h-[60px]">
          <a href="/" className="flex items-center gap-2 sm:gap-3 flex-none">
            <img src="/logo-mark.svg" alt="Intellect Olympiad" className="w-9 h-9 flex-none" />
            <b className="font-serif font-semibold text-[15px] text-ink hidden sm:inline">Intellect Olympiad</b>
          </a>

          {/* Bosh sahifaga qaytish — aniq ko'rinadigan tugma */}
          <a href="/" className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-ink-2 bg-surface border border-line-2 rounded-lg px-3 py-2 hover:border-bordo hover:text-bordo transition-colors flex-none">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="flex-none"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>
            Bosh sahifa
          </a>

          <div className="ml-auto flex items-center gap-2 sm:gap-3 flex-none">
            {/* Yordam telefoni */}
            <a href="tel:+998900362121" className="hidden sm:flex items-center gap-1.5 text-[13px] font-semibold text-ink-2 hover:text-bordo transition-colors whitespace-nowrap" aria-label="Yordam telefoni">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" className="text-bordo flex-none"><path d="M3 11a9 9 0 0 1 18 0"/><path d="M21 16v1a2 2 0 0 1-2 2h-1a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1h3zM3 16v1a2 2 0 0 0 2 2h1a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1H3z"/></svg>
              <span>+998 90 036 21 21</span>
            </a>
            {/* Til tanlagich (real) */}
            <div className="flex items-center gap-[2px] bg-parchment-2 border border-line rounded p-[3px]">
              {LOCALES.map(l => (
                <button key={l} type="button" title={LOCALE_FULL[l]} aria-label={`Til: ${LOCALE_FULL[l]}`} onClick={() => setLocale(l)}
                  className={`text-[11px] font-semibold px-[7px] py-[3px] rounded-sm cursor-pointer border-none transition-colors ${
                    locale === l ? 'bg-surface text-ink shadow-sm' : 'bg-transparent text-muted hover:text-ink'
                  }`}>
                  {LOCALE_LABEL[l]}
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      {/* Stepper */}
      <div className="bg-surface border-b border-line">
        <div className="max-w-wrap mx-auto px-6 py-5">
          <div className="flex items-center gap-0">
            {STEPS_LABEL.map((label, i) => {
              const n = i + 1; const done = step > n; const active = step === n;
              return (
                <div key={n} className="flex items-center flex-1 last:flex-none">
                  <div className="flex items-center gap-2 flex-none">
                    <div className={`w-6 h-6 sm:w-7 sm:h-7 rounded-full flex items-center justify-center text-[12px] font-bold flex-none ${done ? 'bg-ds-green text-white' : active ? 'bg-bordo text-white' : 'bg-parchment-2 text-muted border border-line-2'}`}>{done ? <IcCheck /> : n}</div>
                    <span className={`text-[13px] font-semibold hidden sm:block ${active ? 'text-ink' : done ? 'text-ds-green' : 'text-muted'}`}>{label}</span>
                  </div>
                  {i < STEPS_LABEL.length - 1 && (<div className={`flex-1 h-[2px] mx-1 sm:mx-3 ${step > n ? 'bg-ds-green' : 'bg-line'}`} />)}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="max-w-wrap mx-auto px-6 py-8 grid lg:grid-cols-[1fr_300px] gap-8 items-start">
        <div>
          {error && (
            <div className="mb-5 bg-ds-red-tint border border-ds-red/30 text-ds-red text-[14px] rounded-lg px-4 py-3">{error}</div>
          )}

          {/* Step 1 — account */}
          {step === 1 && (
            <div className="bg-surface border border-line rounded-lg shadow-sm p-5 sm:p-7">
              {/* Role toggle — student or teacher */}
              <div className="inline-flex p-1 rounded-lg bg-parchment-2 border border-line mb-5">
                {[
                  { v: false, label: "O'quvchi" },
                  { v: true, label: 'Ustoz' },
                ].map(opt => (
                  <button
                    key={String(opt.v)}
                    type="button"
                    onClick={() => setAsTeacher(opt.v)}
                    className={`px-5 py-[7px] rounded-md text-[13.5px] font-semibold transition-colors ${asTeacher === opt.v ? 'bg-bordo text-white shadow-sm' : 'text-ink-2 hover:text-ink'}`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>

              {asTeacher && (
                <div className="mb-5 bg-gold-tint border border-gold/30 rounded-lg px-4 py-3 text-[13px] text-ink-2 leading-relaxed">
                  <b className="text-ink">Ustozlar dasturi.</b> Ro&apos;yxatdan o&apos;tgach shaxsiy <b>referal havolangizni</b> olasiz. Havola orqali kelgan har bir o&apos;quvchi uchun ball to&apos;playsiz, reytingda ko&apos;rinasiz va eng faol ustozlar pul mukofot hamda sovg&apos;alar yutib oladi.
                </div>
              )}

              {refCode && !asTeacher && (
                <div className="mb-5 bg-bordo-tint border border-bordo/20 rounded-lg px-4 py-3 text-[13px] text-bordo-700 leading-relaxed flex items-center gap-2">
                  <span className="font-bold">Ustoz havolasi:</span>
                  <span className="font-mono font-semibold">{refCode}</span>
                  <span className="text-ink-2">— natijalaringiz ustozingiz reytingiga qo&apos;shiladi.</span>
                </div>
              )}

              {!socialMode ? (
                <>
                  <h2 className="font-serif text-xl sm:text-2xl font-semibold mb-2">{asTeacher ? "Ustoz sifatida ro'yxatdan o'tish" : "Tezkor ro'yxatdan o'tish"}</h2>
                  <p className="text-muted text-[14px] mb-4">Telegram yoki Google orqali bir bosishda — keyin profilni to&apos;ldirasiz.</p>
                  <SocialAuth onAuthed={handleSocialAuthed} />
                  <div className="flex items-center gap-3 my-6">
                    <span className="flex-1 h-px bg-line" />
                    <span className="text-[12px] text-muted font-semibold whitespace-nowrap">yoki to&apos;liq ma&apos;lumot bilan</span>
                    <span className="flex-1 h-px bg-line" />
                  </div>
                </>
              ) : (
                <div className="mb-6 bg-ds-green-tint border border-ds-green/30 rounded-lg px-4 py-3 flex items-start gap-2.5">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-ds-green flex-none mt-[1px]"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                  <div className="text-[13.5px] text-ink-2 leading-relaxed">
                    <b className="text-ink">{socialMode === 'google' ? 'Google' : 'Telegram'} orqali kirdingiz.</b> Hisobingiz yaratildi — endi quyidagi ma&apos;lumotlarni to&apos;ldiring, so&apos;ngra yakunlang.
                  </div>
                </div>
              )}
              <h2 className="font-serif text-2xl font-semibold mb-6">Hisob ma&apos;lumotlari</h2>
              <div className="grid sm:grid-cols-2 gap-5">
                <div><label className="block text-[13px] font-semibold text-ink mb-[6px]">Ism *</label><input value={form.fname} onChange={e => set('fname', capName(e.target.value))} placeholder="Dostonbek" className={inputCls} /></div>
                <div><label className="block text-[13px] font-semibold text-ink mb-[6px]">Familiya *</label><input value={form.lname} onChange={e => set('lname', capName(e.target.value))} placeholder="Solijonov" className={inputCls} /></div>
                <div className="sm:col-span-2">
                  <label className="block text-[13px] font-semibold text-ink mb-[6px]">Email *</label>
                  <input type="email" value={form.email} onChange={e => set('email', e.target.value)} readOnly={!!socialMode} placeholder="dostonbek@email.com" className={`${inputCls} ${socialMode ? 'bg-parchment-2 text-muted cursor-not-allowed' : ''}`} />
                </div>
                {!socialMode && (
                <div className="sm:col-span-2">
                  <label className="block text-[13px] font-semibold text-ink mb-[6px]">Parol *</label>
                  <input type="password" value={form.password} onChange={e => set('password', e.target.value)} placeholder="Kuchli parol" className={inputCls} />
                  {form.password && (
                    <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-[12px]">
                      {[['len', '10+ belgi'], ['upper', 'Katta harf'], ['lower', 'Kichik harf'], ['digit', 'Raqam'], ['special', 'Maxsus belgi']].map(([k, lbl]) => (
                        <span key={k} className={`flex items-center gap-1 ${checks[k as keyof typeof checks] ? 'text-ds-green' : 'text-muted'}`}>
                          <span className="w-[5px] h-[5px] rounded-full inline-block" style={{ background: 'currentColor' }} />{lbl}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                )}
                <div><label className="block text-[13px] font-semibold text-ink mb-[6px]">Telefon *</label><input value={form.phone} onChange={e => set('phone', fmtPhone(e.target.value))} inputMode="tel" placeholder="+998 90 123 45 67" className={inputCls} /></div>
                {!asTeacher && (
                <div><label className="block text-[13px] font-semibold text-ink mb-[6px]">Ota-ona telefoni *</label><input value={form.pphone} onChange={e => set('pphone', fmtPhone(e.target.value))} inputMode="tel" placeholder="+998 90 111 22 33" className={inputCls} /></div>
                )}
                {!asTeacher && (
                <div className="sm:col-span-2">
                  <label className="block text-[13px] font-semibold text-ink mb-[6px]">Pasport seriya/raqam yoki tug&apos;ilganlik guvohnomasi (JSHSHIR) *</label>
                  <input value={form.passport} onChange={e => set('passport', fmtPassport(e.target.value))} placeholder="AD 3177775 yoki 14 xonali JSHSHIR" className={inputCls} />
                  <div className="text-[11.5px] text-muted mt-1">Maxfiy — shifrlangan holda saqlanadi, faqat tasdiqlash uchun ishlatiladi.</div>
                </div>
                )}
                <div>
                  <label className="block text-[13px] font-semibold text-ink mb-[6px]">Viloyat *</label>
                  <select value={form.regionId || ''} onChange={e => { const id = +e.target.value; const r = UZ_REGIONS.find(x => x.id === id); setForm(f => ({ ...f, regionId: id, region: r?.name ?? '', district: '' })); }} className={inputCls}>
                    <option value="">Tanlang…</option>
                    {UZ_REGIONS.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-[13px] font-semibold text-ink mb-[6px]">Tuman / shahar *</label>
                  <select value={form.district} onChange={e => set('district', e.target.value)} disabled={!form.regionId} className={`${inputCls} disabled:opacity-50`}>
                    <option value="">{form.regionId ? 'Tanlang…' : 'Avval viloyatni tanlang'}</option>
                    {districtsByRegion(form.regionId).map(d => <option key={d.name} value={d.name}>{d.name}</option>)}
                  </select>
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-[13px] font-semibold text-ink mb-[6px]">Maktab / muassasa</label>
                  <input value={form.school} onChange={e => set('school', e.target.value)} placeholder="Masalan: 12-umumiy o'rta ta'lim maktabi" className={inputCls} />
                </div>
              </div>
              <div className="mt-6 flex justify-end">
                <button onClick={next1} className="inline-flex items-center gap-2 font-semibold text-[15px] px-6 py-[11px] rounded bg-bordo text-white hover:bg-bordo-700 transition-colors">Keyingisi →</button>
              </div>
            </div>
          )}

          {/* Step 2 — interests + grade */}

          {/* Step 2 — finalize (real register) */}
          {step === 2 && (
            <div className="bg-surface border border-line rounded-lg shadow-sm p-5 sm:p-7">
              <h2 className="font-serif text-2xl font-semibold mb-3">Ro&apos;yxatdan o&apos;tishni yakunlash</h2>
              <p className="text-[14.5px] text-ink-2 leading-relaxed mb-5">
                {asTeacher
                  ? <>{socialMode ? 'Ustoz profilingiz saqlanadi' : 'Ustoz hisobingiz yaratiladi'}. So&apos;ngra <b>shaxsiy kabinetda referal havolangizni</b> olib, o&apos;quvchilaringizga ulashasiz — har bir ishtirokchi uchun ball to&apos;playsiz.</>
                  : <>{socialMode ? 'Profilingiz saqlanadi' : 'Hisobingiz yaratiladi'}. So&apos;ngra <b>shaxsiy kabinetda</b> olimpiadani tanlab, <b>Click / Payme / Uzum</b> orqali to&apos;lov qilasiz va to&apos;lov chekini yuklaysiz. To&apos;lov tasdiqlangach joyingiz band qilinadi.</>}
              </p>
              <div className="bg-parchment border border-line rounded-lg p-4 text-[13.5px] text-ink-2 space-y-1 mb-6">
                <div><span className="text-muted">{asTeacher ? 'Ustoz:' : 'Ism:'}</span> <b className="text-ink">{form.fname} {form.lname}</b></div>
                <div><span className="text-muted">Email:</span> <b className="text-ink">{form.email}</b></div>
              </div>

              {/* Maxfiylik siyosati roziligi — belgilanmasa yakunlash ishlamaydi */}
              <label className="flex items-start gap-3 mb-6 cursor-pointer select-none">
                <button type="button" role="checkbox" aria-checked={agreed} onClick={() => { setAgreed(a => !a); setError(''); }}
                  className={`mt-[1px] w-5 h-5 rounded-[5px] flex items-center justify-center flex-none border transition-colors ${agreed ? 'bg-bordo border-bordo text-white' : 'bg-surface border-line-2 hover:border-bordo'}`}>
                  {agreed && <IcCheck />}
                </button>
                <span className="text-[13.5px] text-ink-2 leading-relaxed">
                  Men <a href="/privacy" target="_blank" className="text-bordo font-semibold hover:underline">Maxfiylik siyosati</a> va <a href="/terms" target="_blank" className="text-bordo font-semibold hover:underline">Foydalanish shartlari</a>ni o&apos;qidim va roziman.
                </span>
              </label>

              <div className="flex items-stretch gap-2.5">
                <button onClick={() => { setError(''); setStep(1); }} disabled={submitting} className="inline-flex items-center justify-center gap-1.5 font-semibold text-[13.5px] px-3.5 py-[9px] rounded-lg border border-line-2 bg-transparent text-ink hover:bg-parchment-2 transition-colors whitespace-nowrap flex-none">← Orqaga</button>
                <button onClick={handleRegister} disabled={submitting || !agreed}
                  title={!agreed ? 'Avval rozilik bering' : undefined}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 font-semibold text-[14px] px-4 py-[9px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap">
                  {submitting ? <><Spinner size={16} /> {socialMode ? 'Saqlanmoqda…' : 'Yaratilmoqda…'}</> : (socialMode ? 'Yakunlash' : 'Ro‘yxatdan o‘tish')}
                </button>
              </div>
            </div>
          )}

          {/* Step 3 — real success (animatsiyali ptichka + ovoz) */}
          {step === 3 && (
            <div className="bg-surface border border-line rounded-lg shadow-sm p-6 sm:p-10 text-center">
              {/* Animatsiyali muvaffaqiyat belgisi */}
              <div className="relative w-20 h-20 mx-auto mb-5">
                <span className="success-ring absolute inset-0 rounded-full bg-ds-green/25" aria-hidden />
                <span className="success-ring success-ring-2 absolute inset-0 rounded-full bg-ds-green/20" aria-hidden />
                <div className="success-pop relative w-20 h-20 rounded-full bg-ds-green-tint text-ds-green flex items-center justify-center">
                  <svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
                    <path className="success-check" d="M20 6L9 17l-5-5" />
                  </svg>
                </div>
              </div>
              <h2 className="font-serif text-2xl font-semibold mb-3">Hisobingiz yaratildi!</h2>
              <p className="text-[15px] text-ink-2 mb-8 max-w-[420px] mx-auto leading-relaxed">
                {asTeacher
                  ? <>Tabriklaymiz, {form.fname}! Endi kabinetga o&apos;tib <b>referal havolangizni</b> oling va o&apos;quvchilaringizga ulashing — har bir ishtirokchi uchun ball to&apos;playsiz.</>
                  : <>Tabriklaymiz, {form.fname}! Endi kabinetga o&apos;tib olimpiadani tanlang, to&apos;lovni amalga oshiring va joyingizni band qiling.</>}
              </p>
              <div className="flex flex-col sm:flex-row gap-2.5 justify-center">
                <button onClick={() => router.push('/cabinet')} className="inline-flex items-center justify-center gap-1.5 font-semibold text-[14px] px-5 py-[10px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors">Kabinetga o&apos;tish →</button>
                <a href="/" className="inline-flex items-center justify-center gap-1.5 font-semibold text-[14px] px-5 py-[10px] rounded-lg border border-line-2 bg-transparent text-ink hover:bg-parchment-2 transition-colors">Bosh sahifa</a>
              </div>
            </div>
          )}
        </div>

        {/* Summary card */}
        <div className="bg-surface border border-line rounded-lg shadow-sm p-6 lg:sticky lg:top-6">
          <div className="text-[12px] tracking-[.1em] uppercase text-muted font-bold mb-4">Hisob</div>
          <div className="space-y-2 text-[13.5px]">
            <div className="flex justify-between"><span className="text-muted">Ism</span><span className="font-semibold text-ink">{form.fname || '—'} {form.lname}</span></div>
          </div>
          <div className="mt-5 bg-gold-tint rounded p-3 text-[12px] text-gold font-semibold leading-snug">
            To&apos;lov va olimpiada tanlash — ro&apos;yxatdan o&apos;tgach kabinetda amalga oshiriladi.
          </div>
        </div>
      </div>
    </div>
  );
}
