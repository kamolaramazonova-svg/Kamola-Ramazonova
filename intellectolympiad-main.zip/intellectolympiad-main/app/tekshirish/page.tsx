import { redirect } from 'next/navigation';

export default function TekshirishPage({
  searchParams,
}: {
  searchParams: { code?: string };
}) {
  const code = searchParams?.code;
  redirect(code ? `/verify?code=${encodeURIComponent(code)}` : '/verify');
}
