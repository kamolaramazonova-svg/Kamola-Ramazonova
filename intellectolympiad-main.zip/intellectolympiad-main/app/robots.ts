import type { MetadataRoute } from 'next';

const SITE = 'https://intellectolympiad.uz';

export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: '*',
      allow: '/',
      // Shaxsiy / xizmat sahifalari indekslanmaydi
      disallow: ['/cabinet', '/exam', '/result', '/login', '/api/'],
    },
    sitemap: `${SITE}/sitemap.xml`,
    host: SITE,
  };
}
