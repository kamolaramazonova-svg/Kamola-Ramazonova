export const metadata = {
  title: 'Ko‘p so‘raladigan savollar — Intellect Olympiad',
  description: "Onlayn olimpiadada qatnashish, to'lov, sertifikat va test bo'yicha ko'p so'raladigan savollar.",
  alternates: { canonical: '/faq' },
};

const FAQ = [
  { q: 'Olimpiadada qanday qatnashaman?', a: 'Ro‘yxatdan o‘ting, kabinetda olimpiadani tanlab to‘lovni amalga oshiring va chekni yuklang. To‘lov tasdiqlangach joyingiz band qilinadi va belgilangan vaqtda test ochiladi.' },
  { q: 'To‘lov qanday amalga oshiriladi?', a: 'Click, Payme yoki Uzum orqali to‘lab, chek (screenshot yoki PDF) ni kabinetga yuklaysiz. Admin tasdiqlagach ishtirok faollashadi.' },
  { q: 'Test qancha davom etadi?', a: 'Har bir olimpiadaning davomiyligi alohida belgilanadi (odatda 60–150 daqiqa). Aniq vaqt olimpiada kartasida ko‘rsatiladi.' },
  { q: 'Sertifikat qanday beriladi?', a: 'Test yakunida natija avtomatik baholanadi. O‘tgan ishtirokchilarga IO-2026-XXXXXXX formatidagi QR-kod bilan tekshiriladigan raqamli sertifikat beriladi.' },
  { q: 'Sertifikatni qanday tekshiraman?', a: 'Bosh sahifadagi “Sertifikat tekshirish” yoki /verify sahifasiga sertifikat kodini kiriting.' },
  { q: 'Bir olimpiadaga necha marta kirish mumkin?', a: 'Bir foydalanuvchi bir olimpiadaga faqat bir marta kira oladi. Test bitta qurilmada bir martaga mo‘ljallangan.' },
];

const FAQ_JSONLD = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: FAQ.map((f) => ({
    '@type': 'Question',
    name: f.q,
    acceptedAnswer: { '@type': 'Answer', text: f.a },
  })),
};

export default function FaqPage() {
  return (
    <main className="min-h-screen bg-parchment-2 py-16">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(FAQ_JSONLD) }}
      />
      <div className="max-w-[760px] mx-auto px-6">
        <a href="/" className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-ink-2 bg-surface border border-line-2 rounded-lg px-3 py-2 hover:border-bordo hover:text-bordo transition-colors"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>Bosh sahifa</a>
        <h1 className="font-serif text-3xl font-semibold mt-4 mb-8">Ko‘p so‘raladigan savollar</h1>
        <div className="space-y-3">
          {FAQ.map((f, i) => (
            <details key={i} className="bg-surface border border-line rounded-lg p-5 group">
              <summary className="font-serif text-[16px] font-semibold cursor-pointer list-none flex items-center justify-between gap-3">
                {f.q}
                <span className="text-bordo transition-transform group-open:rotate-45 text-xl leading-none">+</span>
              </summary>
              <p className="text-ink-2 text-[14.5px] leading-relaxed mt-3">{f.a}</p>
            </details>
          ))}
        </div>
      </div>
    </main>
  );
}
