'use client';
import { useState, useEffect, useCallback, useRef, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import type { Socket } from 'socket.io-client';
import { exams, type ExamQuestion, type ExamSessionInfo } from '@/lib/api';
import { getToken, getUser } from '@/lib/auth';
import { connectExamSocket, reportAntiCheat } from '@/lib/exam-socket';
import MathText from '@/components/MathText';
import { Spinner, LoadingRow } from '@/components/Spinner';

function fmt(sec: number) {
  if (sec < 0) sec = 0;
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return h > 0
    ? `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
    : `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

const IcClock = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7v5l3 2" />
  </svg>
);

const IcShield = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z" />
  </svg>
);

const IcFlag = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z" />
    <line x1="4" y1="22" x2="4" y2="15" />
  </svg>
);

const IcWarning = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 9v4M12 17h.01" />
    <path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z" />
  </svg>
);

const KEYS = ['A', 'B', 'C', 'D', 'E', 'F'];

export default function ExamPageWrapper() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center bg-parchment"><LoadingRow /></div>}>
      <ExamPage />
    </Suspense>
  );
}

function ExamPage() {
  const router = useRouter();
  const sp = useSearchParams();
  const olympiadId = sp.get('olympiadId') ?? '';

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [session, setSession] = useState<ExamSessionInfo | null>(null);
  const [questions, setQuestions] = useState<ExamQuestion[]>([]);
  const [answers, setAnswers] = useState<Record<string, string | null>>({});
  const [flagged, setFlagged] = useState<Record<string, boolean>>({});
  const [now, setNow] = useState(Date.now());
  const [syncedExpiry, setSyncedExpiry] = useState<number | null>(null); // server-authoritative expiry (ms)
  const [showModal, setShowModal] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMsg, setToastMsg] = useState('Diqqat: test oynasidan chiqish qayd etildi');
  const [tabSwitchCount, setTabSwitchCount] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [finishing, setFinishing] = useState(false);

  const tokenRef = useRef<string | null>(null);
  const finishedRef = useRef(false);
  const socketRef = useRef<Socket | null>(null);
  const toastTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Pastki toast'ni xabar bilan ko'rsatish (anti-cheat bildirishnomalari uchun umumiy)
  const flashToast = useCallback((msg: string) => {
    setToastMsg(msg);
    setShowToast(true);
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(() => setShowToast(false), 3500);
  }, []);
  const [adminStopReason, setAdminStopReason] = useState<string | null>(null);

  // ── Initial load ────────────────────────────────────────────────────────────
  useEffect(() => {
    const token = getToken();
    if (!token) { router.replace('/login'); return; }
    if (!olympiadId) { setError("Olimpiada tanlanmagan. Kabinetdan o'tib keling."); setLoading(false); return; }
    tokenRef.current = token;

    exams.start(token, olympiadId)
      .then(payload => {
        setSession(payload.session);
        setQuestions(payload.questions);
        const initAnswers: Record<string, string | null> = {};
        payload.session.answers?.forEach(a => { initAnswers[a.questionId] = a.optionId ?? null; });
        setAnswers(initAnswers);
        setTabSwitchCount(payload.session.tabSwitches);
        if (payload.session.status !== 'IN_PROGRESS') {
          router.replace(`/result?sessionId=${payload.session.id}`);
        }
      })
      .catch(err => {
        setError(err?.message ?? 'Imtihonni boshlashda xatolik');
      })
      .finally(() => setLoading(false));
  }, [olympiadId, router]);

  // ── Ticker for timer display ────────────────────────────────────────────────
  useEffect(() => {
    if (!session?.expiresAt) return;
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, [session?.expiresAt]);

  // ── Auto-finish when timer expires ──────────────────────────────────────────
  // Prefer the server-synced expiry (from WebSocket ticks); fall back to the session value.
  const sessionExpiryMs = session?.expiresAt ? new Date(session.expiresAt).getTime() : null;
  const expiresAtMs = syncedExpiry ?? sessionExpiryMs;
  const timeLeftSec = expiresAtMs ? Math.max(0, Math.floor((expiresAtMs - now) / 1000)) : 0;

  const handleFinish = useCallback(async () => {
    if (!session || finishedRef.current) return;
    const token = tokenRef.current;
    if (!token) return;
    finishedRef.current = true;
    setFinishing(true);
    try {
      await exams.finish(token, session.id);
      router.replace(`/result?sessionId=${session.id}`);
    } catch (err: unknown) {
      finishedRef.current = false;
      setError(err instanceof Error ? err.message : 'Yakunlashda xatolik');
      setFinishing(false);
    }
  }, [session, router]);

  useEffect(() => {
    if (!session || session.status !== 'IN_PROGRESS') return;
    if (expiresAtMs && now >= expiresAtMs && !finishedRef.current) {
      handleFinish();
    }
  }, [now, expiresAtMs, session, handleFinish]);

  // ── Anti-cheat: visibility change ───────────────────────────────────────────
  useEffect(() => {
    if (!session) return;
    const onVisibility = () => {
      if (!document.hidden) return;
      const token = tokenRef.current;
      if (!token) return;
      exams.reportTabSwitch(token, session.id)
        .then(res => {
          setTabSwitchCount(res.tabSwitches);
          flashToast(`Diqqat: test oynasidan chiqish qayd etildi (${res.tabSwitches})`);
        })
        .catch(() => flashToast('Diqqat: test oynasidan chiqish qayd etildi'));
      // Also report over WebSocket for live admin awareness
      const sock = socketRef.current;
      if (sock?.connected) {
        reportAntiCheat(sock, session.id, 'tab-switch', { hiddenAt: Date.now() });
      }
    };
    document.addEventListener('visibilitychange', onVisibility);
    return () => document.removeEventListener('visibilitychange', onVisibility);
  }, [session, flashToast]);

  // ── Anti-cheat: nusxa/qo'yish, o'ng tugma, chop etish, DevTools yorliqlari ──
  // MUHIM: bu faqat to'siq (deterrent). Asl himoya server tomonda — to'g'ri javoblar
  // (isCorrect) hech qachon clientga yuborilmaydi, timer ham serverda.
  useEffect(() => {
    if (!session || session.status !== 'IN_PROGRESS') return;

    let lastReport = 0;
    const report = (type: 'copy-paste' | 'context-menu' | 'devtools-key' | 'print', meta?: Record<string, unknown>) => {
      const sock = socketRef.current;
      const t = Date.now();
      if (sock?.connected && t - lastReport > 800) {
        lastReport = t;
        reportAntiCheat(sock, session.id, type, meta);
      }
    };

    const blockClipboard = (e: Event) => {
      e.preventDefault();
      report('copy-paste', { kind: e.type });
      flashToast('Nusxa olish / qo\'yish test vaqtida o\'chirib qo\'yilgan');
    };
    const onContextMenu = (e: Event) => {
      e.preventDefault();
      report('context-menu');
      flashToast('O\'ng tugma menyusi o\'chirib qo\'yilgan');
    };
    const stop = (e: Event) => e.preventDefault();
    const onBeforePrint = () => { report('print'); flashToast('Chop etish test vaqtida bloklangan'); };

    const onKeyDown = (e: KeyboardEvent) => {
      const k = e.key;
      const ctrl = e.ctrlKey || e.metaKey;
      const isDevtools =
        k === 'F12' ||
        (ctrl && e.shiftKey && ['I', 'J', 'C', 'i', 'j', 'c'].includes(k)) ||  // DevTools / Console / Inspect
        (ctrl && ['U', 'u'].includes(k));                                       // View source
      const isCopyPaste = ctrl && ['c', 'x', 'v', 'a', 'C', 'X', 'V', 'A'].includes(k); // nusxa/kes/qo'y/hammasini tanlash
      const isSaveOrPrint = ctrl && ['s', 'p', 'S', 'P'].includes(k);          // saqlash / chop etish
      if (isDevtools || isCopyPaste || isSaveOrPrint || k === 'PrintScreen') {
        e.preventDefault();
        e.stopPropagation();
        if (isDevtools) { report('devtools-key', { key: k }); flashToast('Bu yorliq test vaqtida bloklangan'); }
        else if (isSaveOrPrint) { report('print', { key: k }); flashToast('Saqlash / chop etish bloklangan'); }
        else { report('copy-paste', { key: k }); flashToast('Nusxa olish test vaqtida o\'chirib qo\'yilgan'); }
        return false;
      }
    };

    // Matn tanlash / chop etishni o'chiruvchi CSS (test davomida)
    const style = document.createElement('style');
    style.setAttribute('data-exam-guard', '1');
    style.textContent =
      'body{-webkit-user-select:none;-moz-user-select:none;user-select:none;-webkit-touch-callout:none}' +
      'input,textarea{-webkit-user-select:text;user-select:text}' +
      '@media print{body *{display:none!important;visibility:hidden!important}}';
    document.head.appendChild(style);

    document.addEventListener('copy', blockClipboard);
    document.addEventListener('cut', blockClipboard);
    document.addEventListener('paste', blockClipboard);
    document.addEventListener('contextmenu', onContextMenu);
    document.addEventListener('selectstart', stop);
    document.addEventListener('dragstart', stop);
    document.addEventListener('keydown', onKeyDown, true);
    window.addEventListener('beforeprint', onBeforePrint);

    return () => {
      style.remove();
      document.removeEventListener('copy', blockClipboard);
      document.removeEventListener('cut', blockClipboard);
      document.removeEventListener('paste', blockClipboard);
      document.removeEventListener('contextmenu', onContextMenu);
      document.removeEventListener('selectstart', stop);
      document.removeEventListener('dragstart', stop);
      document.removeEventListener('keydown', onKeyDown, true);
      window.removeEventListener('beforeprint', onBeforePrint);
    };
  }, [session, flashToast]);

  // ── WebSocket: timer sync, admin stop, kick ─────────────────────────────────
  useEffect(() => {
    if (!session || session.status !== 'IN_PROGRESS') return;
    const token = tokenRef.current;
    if (!token) return;

    const sock = connectExamSocket(token, session.id, {
      onTick: ({ remainingSec }) => {
        // Server is authoritative: re-anchor the expiry to the server's remaining time.
        setSyncedExpiry(Date.now() + remainingSec * 1000);
        setNow(Date.now());
      },
      onExpired: () => {
        if (!finishedRef.current) handleFinish();
      },
      onStopped: ({ reason }) => {
        setAdminStopReason(reason);
        if (!finishedRef.current) handleFinish();
      },
      onKicked: ({ reason }) => {
        setError(reason || "Boshqa qurilmadan kirildi");
      },
    });
    socketRef.current = sock;

    return () => {
      sock.disconnect();
      socketRef.current = null;
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session?.id, session?.status]);

  // ── Answer selection (with server save) ─────────────────────────────────────
  const selectAnswer = useCallback(async (questionId: string, optionId: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: optionId }));
    const token = tokenRef.current;
    if (!token || !session) return;
    setSubmitting(true);
    try {
      await exams.submitAnswer(token, session.id, questionId, optionId);
    } catch (err: unknown) {
      // Restore previous on failure
      setAnswers(prev => {
        const restored = { ...prev };
        delete restored[questionId];
        return restored;
      });
      const msg = err instanceof Error ? err.message : 'Saqlashda xatolik';
      if (msg.includes('muddati tugagan') || msg.includes('yakunlangan')) {
        await handleFinish();
      } else {
        setError(msg);
      }
    } finally {
      setSubmitting(false);
    }
  }, [session, handleFinish]);

  const toggleFlag = useCallback((questionId: string) => {
    setFlagged(prev => ({ ...prev, [questionId]: !prev[questionId] }));
  }, []);

  // ── Loading / error states ──────────────────────────────────────────────────
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-parchment p-6">
        <div className="text-center anim-fade-up">
          <div className="anim-float mb-4 inline-block">
            <img src="/logo-mark.svg" alt="IO" className="w-14 h-14" />
          </div>
          <div className="text-muted text-[14px] timer-pulse">Imtihon tayyorlanmoqda…</div>
        </div>
      </div>
    );
  }

  if (error) {
    const finished = /yakunlangan|tugagan|allaqachon/i.test(error);
    return (
      <div className="min-h-screen flex items-center justify-center bg-parchment p-6">
        <div className="max-w-[440px] w-full bg-surface border border-line rounded-2xl p-8 sm:p-10 text-center shadow-sm anim-fade-up">
          <div className="relative w-[72px] h-[72px] mx-auto mb-5">
            <span className={`absolute inset-0 rounded-full anim-ring ${finished ? 'bg-ds-green/30' : 'bg-ds-red/30'}`} />
            <span className={`absolute inset-0 rounded-full anim-ring ${finished ? 'bg-ds-green/25' : 'bg-ds-red/25'}`} style={{ animationDelay: '.7s' }} />
            <div className={`relative w-[72px] h-[72px] rounded-full flex items-center justify-center anim-pop ${finished ? 'bg-ds-green-tint text-ds-green' : 'bg-ds-red-tint text-ds-red'}`}>
              {finished ? (
                <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5" /></svg>
              ) : (
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 9v4M12 17h.01" /><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z" /></svg>
              )}
            </div>
          </div>
          <h2 className="font-serif text-[21px] font-semibold mb-2 anim-fade-up" style={{ animationDelay: '.08s' }}>
            {finished ? 'Imtihon yakunlangan' : 'Xatolik'}
          </h2>
          <p className="text-[14px] text-muted mb-6 leading-relaxed anim-fade-up" style={{ animationDelay: '.14s' }}>
            {finished ? "Siz bu imtihonni allaqachon topshirgansiz. Natijangizni kabinetdan ko'rishingiz mumkin." : error}
          </p>
          <div className="anim-fade-up" style={{ animationDelay: '.2s' }}>
            <button onClick={() => router.push('/cabinet')}
              className="font-semibold text-[14px] px-6 py-[11px] rounded-lg bg-bordo text-white hover:bg-bordo-700 border-none cursor-pointer transition-colors">
              {finished ? 'Natijalarim →' : 'Kabinetga qaytish'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!session || questions.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-parchment p-6">
        <div className="max-w-[420px] w-full bg-surface border border-line rounded-2xl p-8 text-center shadow-sm anim-fade-up">
          <div className="w-16 h-16 rounded-full bg-parchment-2 text-muted flex items-center justify-center mx-auto mb-4 anim-pop">
            <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6" /></svg>
          </div>
          <h2 className="font-serif text-[19px] font-semibold mb-2">Savollar topilmadi</h2>
          <p className="text-[13.5px] text-muted mb-5">Bu olimpiada uchun savollar hali biriktirilmagan.</p>
          <button onClick={() => router.push('/cabinet')}
            className="font-semibold text-[14px] px-6 py-[11px] rounded-lg bg-bordo text-white hover:bg-bordo-700 border-none cursor-pointer">
            Kabinetga qaytish
          </button>
        </div>
      </div>
    );
  }

  // ── UI ──────────────────────────────────────────────────────────────────────
  const total = questions.length;
  const answered = Object.values(answers).filter(v => v !== null).length;
  const unanswered = total - answered;
  const flaggedCount = Object.values(flagged).filter(Boolean).length;
  const isLow = timeLeftSec < 300;
  const scrollToQ = (i: number) =>
    document.getElementById(`q-${i}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  const me = getUser();
  const meInitials = me ? `${me.firstName?.[0] ?? ''}${me.lastName?.[0] ?? ''}`.toUpperCase() : '';
  const meMeta = me ? [me.region, me.school].filter(Boolean).join(' · ') : '';

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: '#eaf2fb' }}>
      {/* Test bar */}
      <div className="bg-surface border-b border-line sticky top-0 z-30 flex-none">
        <div className="max-w-[1120px] mx-auto px-3 sm:px-6 flex items-center justify-between min-h-[64px] gap-2 sm:gap-4">
          <div className="flex items-center gap-2 sm:gap-[14px] min-w-0">
            <img src="/logo-mark.svg" alt="IO" className="w-[32px] h-[32px] sm:w-[38px] sm:h-[38px] flex-none" />
            <div className="min-w-0">
              <div className="font-serif font-bold text-[13px] sm:text-[15px] text-ink leading-tight truncate">
                {session.olympiad?.title ?? 'Olimpiada'}
              </div>
              <small className="text-[11px] sm:text-[12px] text-muted block leading-tight truncate">
                {total} savol · {session.olympiad?.durationMin ?? 0} daqiqa
              </small>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-4 flex-none">
            {submitting && <span className="hidden sm:inline text-[11.5px] text-muted font-medium animate-pulse">saqlanmoqda…</span>}
            <div className="hidden sm:flex items-center gap-[7px] text-[12.5px] font-semibold text-ds-green">
              <span className="w-[7px] h-[7px] rounded-full bg-ds-green flex-none animate-pulse" />
              <IcShield />
              <span>Nazorat faol</span>
              {tabSwitchCount > 0 && (
                <span className="text-ds-amber font-mono ml-2">({tabSwitchCount} tab almashtirildi)</span>
              )}
            </div>
            {/* Compact anti-cheat indicator for mobile */}
            <div className="flex sm:hidden items-center gap-[5px] text-[12px] font-semibold text-ds-green">
              <IcShield />
              {tabSwitchCount > 0 && (
                <span className="text-ds-amber font-mono">({tabSwitchCount})</span>
              )}
            </div>

            <div className={`flex items-center gap-[6px] sm:gap-[10px] px-2.5 sm:px-4 py-2 rounded border transition-colors ${
              isLow
                ? 'bg-ds-red-tint border-[#d2e0ec] text-ds-red'
                : 'bg-bordo-tint border-bordo-tint2 text-bordo'
            }`}>
              <span className={isLow ? 'text-ds-red' : 'text-bordo'}><IcClock /></span>
              <b className="font-mono text-[16px] sm:text-[19px] font-semibold tracking-[.02em]">{fmt(timeLeftSec)}</b>
            </div>
          </div>
        </div>

        {/* Progress bar — javob berilgan savollar ulushi */}
        <div className="h-[4px] bg-parchment-2">
          <div className="h-full bg-bordo transition-all duration-300"
            style={{ width: `${(answered / total) * 100}%` }} />
        </div>
      </div>

      {/* Layout — sahifa scroll bo'ladi, o'ng (xarita) sticky bilan joyida qotib turadi */}
      <div className="flex-1 max-w-[1160px] mx-auto w-full px-3 sm:px-6 grid lg:grid-cols-[1fr_320px] gap-4 lg:gap-7 items-start">
        <div className="flex flex-col gap-3 py-5 sm:py-7">
          {questions.map((q, qi) => (
            <div key={q.id} id={`q-${qi}`} className="scroll-mt-[84px] bg-surface border border-line rounded-lg p-4 sm:p-5 shadow-sm">
              <div className="flex justify-between items-center mb-2.5 gap-2">
                <div className="text-[12px] text-muted font-semibold tracking-[.03em]">
                  Savol <b className="text-bordo text-[14px]">{qi + 1}</b> / {total}
                </div>
                <button onClick={() => toggleFlag(q.id)}
                  className={`inline-flex items-center gap-[6px] text-[12px] font-semibold px-2.5 py-[5px] rounded border cursor-pointer transition-all flex-none ${
                    flagged[q.id]
                      ? 'bg-ds-amber-tint border-ds-amber text-ds-amber'
                      : 'bg-transparent border-line-2 text-muted hover:border-ds-amber hover:text-ds-amber'
                  }`}>
                  <IcFlag /> Belgilash
                </button>
              </div>

              <p className="font-serif text-[15.5px] sm:text-[17px] leading-[1.35] text-ink mb-1 break-words"><MathText text={q.text} /></p>
              {q.imageUrl && (
                <img src={q.imageUrl} alt="Savol rasmi" className="mt-2.5 max-w-full rounded border border-line" />
              )}

              <div className="flex flex-col gap-2 mt-3.5">
                {q.options.map((opt, oi) => {
                  const chosen = answers[q.id] === opt.id;
                  return (
                    <label key={opt.id}
                      className={`flex items-center gap-2.5 sm:gap-3 px-3 py-2.5 border rounded-md cursor-pointer transition-all ${
                        chosen
                          ? 'border-bordo bg-bordo-tint'
                          : 'border-line-2 hover:border-bordo hover:bg-bordo-tint'
                      }`}>
                      <input type="radio" name={`q-${q.id}`} className="sr-only"
                        checked={chosen}
                        onChange={() => selectAnswer(q.id, opt.id)} />
                      <span className={`w-6 h-6 sm:w-[26px] sm:h-[26px] rounded-md border grid place-items-center font-bold font-serif text-[12.5px] sm:text-[13px] flex-none transition-all ${
                        chosen ? 'bg-bordo border-bordo text-white' : 'border-line-2 text-ink-2'
                      }`}>
                        {KEYS[oi] ?? oi + 1}
                      </span>
                      <span className="flex-1 min-w-0 text-[13.5px] sm:text-[14.5px] text-ink break-words"><MathText text={opt.text} /></span>
                    </label>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Savollar oxirida — yakunlash (pastga yopishib turadi, scroll'da tepaga chiqib ketmaydi) */}
          <div className="sticky bottom-3 sm:bottom-4 mt-1 z-10">
            <button onClick={() => setShowModal(true)}
              className="w-full flex items-center justify-center font-semibold text-[15px] px-5 py-[14px] rounded-xl bg-bordo text-white hover:bg-bordo-700 border-none cursor-pointer transition-colors shadow-lg">
              Testni yakunlash
            </button>
          </div>
        </div>

        {/* Navigator — sticky bilan joyida qotib turadi (sahifa scroll bo'lganda ham), bosilganda savolga olib boradi */}
        <aside className="bg-surface border border-line rounded-xl p-4 sm:p-[22px] mb-6 lg:my-7 lg:sticky lg:top-[84px] lg:self-start lg:max-h-[calc(100vh-100px)] lg:overflow-y-auto">
          {/* Ishtirokchi ma'lumotlari */}
          {me && (
            <div className="mb-4 pb-4 border-b border-line">
              <div className="text-[11px] tracking-[.08em] uppercase text-muted font-bold mb-2">Ishtirokchi</div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-bordo text-white flex items-center justify-center font-bold font-serif text-[15px] flex-none">{meInitials || '·'}</div>
                <div className="min-w-0">
                  <div className="font-semibold text-ink text-[14px] truncate">{me.firstName} {me.lastName}</div>
                  <div className="text-[12px] text-muted truncate">{meMeta || me.email}</div>
                </div>
              </div>
              <div className="mt-3 text-[12px]">
                <div className="flex justify-between gap-2"><span className="text-muted flex-none">Olimpiada</span><span className="text-ink font-semibold text-right truncate">{session.olympiad?.title ?? '—'}</span></div>
              </div>
            </div>
          )}

          <h4 className="text-[13px] tracking-[.04em] uppercase text-muted font-bold mb-4">Savollar xaritasi</h4>

          <div className="grid grid-cols-5 sm:grid-cols-6 gap-2">
            {questions.map((qq, i) => {
              const isAnswered = answers[qq.id] != null;
              const isFlagged = !!flagged[qq.id];
              let cls = 'aspect-square rounded-[4px] border-[1.5px] text-[13px] font-bold font-mono cursor-pointer grid place-items-center transition-all ';
              if (isAnswered) cls += 'bg-bordo border-bordo text-white ';
              else if (isFlagged) cls += 'bg-ds-amber-tint border-ds-amber text-ds-amber ';
              else cls += 'border-line-2 bg-surface text-ink-2 hover:border-bordo ';
              return <button key={qq.id} onClick={() => scrollToQ(i)} className={cls}>{i + 1}</button>;
            })}
          </div>

          <div className="mt-[18px] flex flex-col gap-2 text-[12.5px] text-ink-2">
            <div className="flex items-center gap-[9px]">
              <span className="w-[15px] h-[15px] rounded-[4px] flex-none bg-bordo border border-bordo" />Javob berilgan
            </div>
            <div className="flex items-center gap-[9px]">
              <span className="w-[15px] h-[15px] rounded-[4px] flex-none bg-ds-amber-tint border border-ds-amber" />Belgilangan
            </div>
            <div className="flex items-center gap-[9px]">
              <span className="w-[15px] h-[15px] rounded-[4px] flex-none border-[1.5px] border-line-2 bg-surface" />Javob berilmagan
            </div>
          </div>

          <div className="mt-[18px] pt-4 border-t border-line text-[13px]">
            <div className="flex justify-between gap-[10px] py-[3px] text-ink-2">
              <span>Javob berilgan</span><b className="text-ink">{answered} / {total}</b>
            </div>
            <div className="flex justify-between gap-[10px] py-[3px] text-ink-2">
              <span>Belgilangan</span><b className="text-ink">{flaggedCount}</b>
            </div>
          </div>

          <button onClick={() => setShowModal(true)}
            className="mt-[18px] w-full hidden lg:flex items-center justify-center font-semibold text-[14px] px-5 py-[10px] rounded bg-bordo text-white hover:bg-bordo-700 border-none cursor-pointer transition-colors">
            Testni yakunlash
          </button>
        </aside>
      </div>

      {/* Admin stop banner */}
      {adminStopReason && (
        <div className="fixed top-[68px] left-0 right-0 z-40 bg-ds-red text-white py-3 px-4 sm:px-6 text-center text-[13px] sm:text-[14px] font-semibold">
          Administrator imtihonni to&apos;xtatdi: {adminStopReason}
        </div>
      )}

      {/* Bottom toast */}
      <div
        className="fixed bottom-6 left-1/2 z-50 bg-ink text-white px-4 sm:px-5 py-[13px] rounded flex items-center gap-2 sm:gap-[10px] text-[13px] sm:text-[14px] shadow-lg max-w-[calc(100vw-24px)] sm:max-w-[90vw] transition-transform duration-300"
        style={{ transform: showToast ? 'translateX(-50%) translateY(0)' : 'translateX(-50%) translateY(120px)' }}>
        <span className="text-ds-amber flex-none"><IcWarning /></span>
        <span>{toastMsg}</span>
      </div>

      {/* Finish modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => !finishing && setShowModal(false)}>
          <div className="bg-surface rounded-xl p-6 sm:p-8 w-full max-w-[420px] shadow-lg" onClick={e => e.stopPropagation()}>
            <h3 className="text-[20px] font-serif font-semibold text-ink mb-2">Testni yakunlaysizmi?</h3>
            <p className="text-[14px] text-muted mb-[18px]">
              Yakunlangach javoblarni o&apos;zgartirib bo&apos;lmaydi.
            </p>

            <div className="bg-parchment rounded-lg px-4 py-[14px] mb-[18px]">
              <div className="flex justify-between text-[14px] py-1">
                <span className="text-muted">Javob berilgan</span><b className="text-ink">{answered} / {total}</b>
              </div>
              <div className="flex justify-between text-[14px] py-1">
                <span className="text-muted">Javobsiz</span><b className={unanswered > 0 ? 'text-ds-amber' : 'text-ink'}>{unanswered}</b>
              </div>
              <div className="flex justify-between text-[14px] py-1">
                <span className="text-muted">Qolgan vaqt</span><b className="text-ink font-mono">{fmt(timeLeftSec)}</b>
              </div>
            </div>

            <div className="flex gap-[10px]">
              <button onClick={() => setShowModal(false)} disabled={finishing}
                className="flex-1 font-semibold text-[14px] px-5 py-[10px] rounded border border-line-2 bg-transparent text-ink hover:bg-parchment-2 border-none cursor-pointer transition-colors disabled:opacity-50">
                Davom etish
              </button>
              <button onClick={handleFinish} disabled={finishing}
                className="flex-1 flex items-center justify-center font-semibold text-[14px] px-5 py-[10px] rounded bg-bordo text-white hover:bg-bordo-700 border-none cursor-pointer transition-colors disabled:opacity-50">
                {finishing ? <span className="inline-flex items-center gap-2"><Spinner size={16} /> Yuborilmoqda...</span> : 'Yakunlash'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
