import type { MetadataRoute } from 'next';

const SITE = 'https://intellectolympiad.uz';
const API = process.env.NEXT_PUBLIC_API_URL || 'https://api.intellectolympiad.uz/api/v1';

// Har soatda qayta hisoblanadi (yangi olimpiada/yangilik qo'shilsa sitemap yangilanadi)
export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const now = new Date();

  // Indekslanadigan statik sahifalar (kabinet/test/natija — shaxsiy, kiritilmaydi)
  const staticRoutes: MetadataRoute.Sitemap = [
    { url: `${SITE}/`, lastModified: now, changeFrequency: 'daily', priority: 1 },
    { url: `${SITE}/news`, lastModified: now, changeFrequency: 'daily', priority: 0.8 },
    { url: `${SITE}/faq`, lastModified: now, changeFrequency: 'monthly', priority: 0.6 },
    { url: `${SITE}/contact`, lastModified: now, changeFrequency: 'monthly', priority: 0.5 },
    { url: `${SITE}/verify`, lastModified: now, changeFrequency: 'monthly', priority: 0.6 },
    { url: `${SITE}/register`, lastModified: now, changeFrequency: 'monthly', priority: 0.7 },
    { url: `${SITE}/privacy`, lastModified: now, changeFrequency: 'yearly', priority: 0.3 },
    { url: `${SITE}/terms`, lastModified: now, changeFrequency: 'yearly', priority: 0.3 },
  ];

  // Dinamik: olimpiadalar + yangiliklar (API ishlamasa — faqat statik qaytadi)
  const dynamic: MetadataRoute.Sitemap = [];
  try {
    const [olyRes, newsRes] = await Promise.all([
      fetch(`${API}/olympiads`, { next: { revalidate: 3600 } }),
      fetch(`${API}/news`, { next: { revalidate: 3600 } }),
    ]);
    if (olyRes.ok) {
      const olys = await olyRes.json();
      for (const o of Array.isArray(olys) ? olys : []) {
        if (!o?.id) continue;
        dynamic.push({
          url: `${SITE}/olimpiada/${o.id}`,
          lastModified: o.updatedAt ? new Date(o.updatedAt) : now,
          changeFrequency: 'weekly',
          priority: 0.8,
        });
      }
    }
    if (newsRes.ok) {
      const news = (await newsRes.json())?.data ?? [];
      for (const n of Array.isArray(news) ? news : []) {
        const slug = n?.slug ?? n?.id;
        if (!slug) continue;
        dynamic.push({
          url: `${SITE}/news/${slug}`,
          lastModified: n.updatedAt ? new Date(n.updatedAt) : now,
          changeFrequency: 'weekly',
          priority: 0.6,
        });
      }
    }
  } catch {
    /* API vaqtincha ishlamasa — statik sitemap yetarli */
  }

  return [...staticRoutes, ...dynamic];
}
