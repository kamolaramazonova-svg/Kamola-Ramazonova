export const metadata = { title: 'Maxfiylik siyosati — Intellect Olympiad' };

export default function PrivacyPage() {
  return (
    <main className="min-h-screen bg-parchment-2 py-16">
      <div className="max-w-[760px] mx-auto px-6">
        <a href="/" className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-ink-2 bg-surface border border-line-2 rounded-lg px-3 py-2 hover:border-bordo hover:text-bordo transition-colors"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>Bosh sahifa</a>
        <h1 className="font-serif text-3xl font-semibold mt-4 mb-2">Maxfiylik siyosati</h1>
        <p className="text-muted text-[13px] mb-8">Oxirgi yangilanish: 2026-yil</p>

        <div className="space-y-6 text-ink-2 text-[14.5px] leading-relaxed">
          <section>
            <h2 className="font-serif text-[18px] font-semibold text-ink mb-2">1. To‘planadigan ma‘lumotlar</h2>
            <p>Ro‘yxatdan o‘tishda ism, familiya, email, telefon, sinf, maktab va viloyat ma‘lumotlari to‘planadi. Identifikatsiya uchun kiritiladigan pasport/JSHSHIR ma‘lumotlari shifrlangan holda (AES-256) saqlanadi va ochiq ko‘rinishda saqlanmaydi.</p>
          </section>
          <section>
            <h2 className="font-serif text-[18px] font-semibold text-ink mb-2">2. Ma‘lumotlardan foydalanish</h2>
            <p>Ma‘lumotlar faqat olimpiadada ishtirok etish, natijalarni baholash, sertifikat berish va siz bilan bog‘lanish maqsadida ishlatiladi. Uchinchi tomonlarga sotilmaydi.</p>
          </section>
          <section>
            <h2 className="font-serif text-[18px] font-semibold text-ink mb-2">3. Xavfsizlik</h2>
            <p>Parollar argon2id algoritmi bilan hashlanadi, maxfiy ma‘lumotlar shifrlanadi, ulanish HTTPS orqali himoyalanadi. Maxfiy ma‘lumotlar jurnalga yozilmaydi.</p>
          </section>
          <section>
            <h2 className="font-serif text-[18px] font-semibold text-ink mb-2">4. Sizning huquqlaringiz</h2>
            <p>Siz o‘z ma‘lumotlaringizni ko‘rish, tahrirlash yoki o‘chirishni so‘rashga haqlisiz. Buning uchun <a href="/contact" className="text-bordo hover:underline">biz bilan bog‘laning</a>.</p>
          </section>
        </div>
      </div>
    </main>
  );
}
