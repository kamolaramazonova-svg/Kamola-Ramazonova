'use client';
import { useState, FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { auth } from '@/lib/api';
import { saveSession } from '@/lib/auth';
import SocialAuth from '@/components/SocialAuth';
import { Spinner } from '@/components/Spinner';
import { useLocale, LOCALES, LOCALE_LABEL, LOCALE_FULL } from '@/lib/locale';

const DIAMOND_ASIDE = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='60' height='60'%3E%3Cpath d='M30 0L60 30L30 60L0 30Z' fill='none' stroke='%23ffffff' stroke-opacity='0.05' stroke-width='1'/%3E%3C/svg%3E")`;

const IcShieldFeat = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#9a7b3f" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ width: 18, height: 18 }}>
    <path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z" />
  </svg>
);
const IcLineChart = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#9a7b3f" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ width: 18, height: 18 }}>
    <path d="M3 3v18h18" /><path d="M7 14l4-4 3 3 5-6" />
  </svg>
);
const IcClock = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#9a7b3f" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ width: 18, height: 18 }}>
    <circle cx="12" cy="12" r="10" /><path d="M12 6v6l4 2" />
  </svg>
);
const IcEye = ({ open }: { open: boolean }) => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z" />
    <circle cx="12" cy="12" r="3" />
    {!open && <line x1="2" y1="2" x2="22" y2="22" />}
  </svg>
);

const FEATURES = [
  { Icon: IcShieldFeat, text: "Sertifikatlaringiz xavfsiz saqlanadi" },
  { Icon: IcLineChart, text: "Natija va tahlillaringizni kuzating" },
  { Icon: IcClock, text: "Bo'lajak olimpiadalardan xabardor bo'ling" },
];

const INPUT_CLS = "w-full font-sans text-[15px] text-ink px-[13px] py-[11px] border border-line-2 rounded bg-surface transition-colors focus:outline-none focus:border-bordo focus:shadow-[0_0_0_3px_#e3f1f9]";

export default function LoginPage() {
  const router = useRouter();
  const [tab, setTab] = useState<'login' | 'signup'>('login');
  const [locale, setLocale] = useLocale();
  const [showPw, setShowPw] = useState(false);
  const [showPw2, setShowPw2] = useState(false);

  // Login state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPw, setLoginPw] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);
  const [loginError, setLoginError] = useState('');

  // Signup state
  const [signupFirst, setSignupFirst] = useState('');
  const [signupLast, setSignupLast] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPw, setSignupPw] = useState('');
  const [signupLoading, setSignupLoading] = useState(false);
  const [signupError, setSignupError] = useState('');
  const [agree, setAgree] = useState(true);

  async function handleLogin(e: FormEvent) {
    e.preventDefault();
    setLoginError('');
    setLoginLoading(true);
    try {
      const res = await auth.login(loginEmail, loginPw);
      saveSession(res.accessToken, res.user);
      const next = new URLSearchParams(window.location.search).get('next');
      const isAdmin = res.user.role === 'SUPERADMIN' || res.user.role === 'ADMIN';
      if (isAdmin) {
        // Admin panel alohida ilova (admin.intellectolympiad.uz) — to'liq URL'ga o'tamiz (/admin web'da yo'q).
        window.location.href = process.env.NEXT_PUBLIC_ADMIN_URL || 'https://admin.intellectolympiad.uz';
        return;
      }
      router.push(next || '/cabinet');
    } catch (err: unknown) {
      setLoginError(err instanceof Error ? err.message : "Kirish amalga oshmadi");
    } finally {
      setLoginLoading(false);
    }
  }

  async function handleSignup(e: FormEvent) {
    e.preventDefault();
    if (!agree) { setSignupError("Foydalanish shartlariga rozilik bering"); return; }
    setSignupError('');
    setSignupLoading(true);
    try {
      const res = await auth.register({
        email: signupEmail,
        password: signupPw,
        firstName: signupFirst,
        lastName: signupLast,
      });
      saveSession(res.accessToken, res.user);
      const next = new URLSearchParams(window.location.search).get('next');
      router.push(next || '/cabinet');
    } catch (err: unknown) {
      setSignupError(err instanceof Error ? err.message : "Ro'yxatdan o'tish amalga oshmadi");
    } finally {
      setSignupLoading(false);
    }
  }

  const title = tab === 'login' ? 'Xush kelibsiz' : 'Hisob yarating';
  const lead = tab === 'login'
    ? "Hisobingizga kirish uchun ma'lumotlarni kiriting."
    : "Bir necha qadamda ro'yxatdan o'ting.";

  return (
    <div className="min-h-screen lg:grid bg-parchment" style={{ gridTemplateColumns: '1.1fr 1fr' }}>
      {/* Left aside */}
      <aside className="hidden lg:flex flex-col justify-between text-white relative overflow-hidden"
        style={{ background: '#0b3b5a', padding: '44px 52px' }}>
        <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: DIAMOND_ASIDE }} />
        <a href="/" className="relative flex items-center gap-3 flex-none">
          <img src="/logo-mark-light.svg" alt="Intellect Olympiad" className="w-11 h-11 flex-none" />
          <div className="flex flex-col leading-[1.05]">
            <b className="font-serif font-semibold text-base text-white">Intellect Olympiad</b>
            <small className="font-semibold" style={{ fontSize: 10.5, letterSpacing: '.14em', textTransform: 'uppercase', color: '#b6c7d6' }}>Onlayn Olimpiada</small>
          </div>
        </a>
        <div className="relative">
          <h2 className="font-serif font-semibold text-white" style={{ fontSize: 34, lineHeight: 1.15 }}>
            Bilimingiz —<br />kelajagingiz poydevori
          </h2>
          <p className="mt-4 leading-relaxed" style={{ color: 'rgba(255,255,255,.82)', fontSize: 16, maxWidth: '38ch' }}>
            Hisobingizga kiring va onlayn olimpiadalar, natijalar hamda sertifikatlaringizni bir joyda boshqaring.
          </p>
          <div className="flex flex-col gap-[14px] mt-[30px]">
            {FEATURES.map((f, i) => (
              <div key={i} className="flex items-center gap-[13px]" style={{ fontSize: 15, color: 'rgba(255,255,255,.92)' }}>
                <span className="flex-none flex items-center justify-center rounded-lg"
                  style={{
                    width: 38,
                    height: 38,
                    background: 'rgba(8,119,181,.07)',
                    border: '1px solid rgba(154,123,63,.32)',
                  }}>
                  <f.Icon />
                </span>
                {f.text}
              </div>
            ))}
          </div>
        </div>
        <div className="relative font-serif italic" style={{ borderLeft: '2px solid #9a7b3f', paddingLeft: 16, fontSize: 16, color: 'rgba(255,255,255,.9)' }}>
          &ldquo;Adolatli baholash — har bir o&apos;quvchi uchun teng imkoniyat.&rdquo;
        </div>
      </aside>

      {/* Right form */}
      <main className="flex flex-col items-center justify-center p-6 sm:p-10 min-h-screen">
        <div className="w-full max-w-[400px] flex items-center justify-between gap-2 mb-6">
          <a href="/" className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-ink-2 bg-surface border border-line-2 rounded-lg px-3 py-2 hover:border-bordo hover:text-bordo transition-colors flex-none">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="flex-none"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>
            Bosh sahifa
          </a>
          <div className="flex items-center gap-[2px] bg-parchment-2 border border-line rounded p-[3px] flex-none">
            {LOCALES.map(l => (
              <button key={l} type="button" title={LOCALE_FULL[l]} aria-label={`Til: ${LOCALE_FULL[l]}`} onClick={() => setLocale(l)}
                className={`text-[11px] font-semibold px-[7px] py-[3px] rounded-sm cursor-pointer border-none transition-colors ${
                  locale === l ? 'bg-surface text-ink shadow-sm' : 'bg-transparent text-muted hover:text-ink'
                }`}>
                {LOCALE_LABEL[l]}
              </button>
            ))}
          </div>
        </div>

        <div className="w-full max-w-[400px]">
          <h1 className="font-serif font-semibold mb-[6px] text-[24px] sm:text-[28px]">{title}</h1>
          <p className="text-muted mb-7" style={{ fontSize: 15 }}>{lead}</p>

          <div className="flex bg-parchment-2 border border-line rounded p-1 mb-[26px]">
            {(['login', 'signup'] as const).map(t => (
              <button key={t} onClick={() => t === 'signup' ? router.push('/register') : setTab(t)}
                className={`flex-1 py-[9px] text-[13px] sm:text-[14px] font-semibold rounded-sm cursor-pointer border-none transition-all ${
                  tab === t ? 'bg-surface text-bordo shadow-sm' : 'bg-transparent text-muted hover:text-ink'
                }`}>
                {t === 'login' ? 'Kirish' : "Ro'yxatdan o'tish"}
              </button>
            ))}
          </div>

          {/* Telegram (primary) + Google */}
          <SocialAuth />
          <div className="flex items-center gap-3 my-6">
            <span className="flex-1 h-px bg-line" />
            <span className="text-[12px] text-muted font-semibold whitespace-nowrap">yoki email orqali</span>
            <span className="flex-1 h-px bg-line" />
          </div>

          {/* LOGIN */}
          {tab === 'login' && (
            <form onSubmit={handleLogin} className="space-y-[18px]">
              {loginError && (
                <div className="text-[13.5px] text-red-700 bg-red-50 border border-red-200 rounded px-3 py-2">
                  {loginError}
                </div>
              )}
              <div>
                <label className="block text-[13px] font-semibold text-ink mb-[6px]" htmlFor="login-email">Email</label>
                <input id="login-email" type="email" required placeholder="email@example.com"
                  value={loginEmail} onChange={e => setLoginEmail(e.target.value)}
                  className={INPUT_CLS} />
              </div>
              <div>
                <label className="block text-[13px] font-semibold text-ink mb-[6px]" htmlFor="login-pw">Parol</label>
                <div className="relative">
                  <input id="login-pw" type={showPw ? 'text' : 'password'} required placeholder="••••••••"
                    value={loginPw} onChange={e => setLoginPw(e.target.value)}
                    className={INPUT_CLS + ' pr-11'} />
                  <button type="button" onClick={() => setShowPw(v => !v)}
                    className={`absolute right-[10px] top-1/2 -translate-y-1/2 border-none bg-transparent cursor-pointer p-1 flex items-center transition-colors ${showPw ? 'text-bordo' : 'text-muted hover:text-ink'}`}>
                    <IcEye open={showPw} />
                  </button>
                </div>
              </div>
              <button type="submit" disabled={loginLoading}
                className="w-full flex items-center justify-center font-semibold text-[15px] px-5 py-[12px] rounded bg-bordo text-white hover:bg-[#066291] transition-colors disabled:opacity-60 disabled:cursor-not-allowed">
                {loginLoading ? <><Spinner size={17} /> Kirilmoqda...</> : 'Kirish'}
              </button>
              <p className="text-center text-[14px] text-muted pt-1">
                Hisobingiz yo&apos;qmi?{' '}
                <button type="button" onClick={() => router.push('/register')}
                  className="text-bordo font-semibold hover:text-[#066291] bg-transparent border-none cursor-pointer">
                  Ro&apos;yxatdan o&apos;ting
                </button>
              </p>
            </form>
          )}

          {/* SIGNUP */}
          {tab === 'signup' && (
            <form onSubmit={handleSignup} className="space-y-[18px]">
              {signupError && (
                <div className="text-[13.5px] text-red-700 bg-red-50 border border-red-200 rounded px-3 py-2">
                  {signupError}
                </div>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[13px] font-semibold text-ink mb-[6px]" htmlFor="signup-first">Ism</label>
                  <input id="signup-first" type="text" required placeholder="Ali"
                    value={signupFirst} onChange={e => setSignupFirst(e.target.value)}
                    className={INPUT_CLS} />
                </div>
                <div>
                  <label className="block text-[13px] font-semibold text-ink mb-[6px]" htmlFor="signup-last">Familiya</label>
                  <input id="signup-last" type="text" required placeholder="Valiyev"
                    value={signupLast} onChange={e => setSignupLast(e.target.value)}
                    className={INPUT_CLS} />
                </div>
              </div>
              <div>
                <label className="block text-[13px] font-semibold text-ink mb-[6px]" htmlFor="signup-email">Email</label>
                <input id="signup-email" type="email" required placeholder="email@example.com"
                  value={signupEmail} onChange={e => setSignupEmail(e.target.value)}
                  className={INPUT_CLS} />
              </div>
              <div>
                <label className="block text-[13px] font-semibold text-ink mb-[6px]" htmlFor="signup-pw">Parol yarating</label>
                <div className="relative">
                  <input id="signup-pw" type={showPw2 ? 'text' : 'password'} required placeholder="••••••••"
                    value={signupPw} onChange={e => setSignupPw(e.target.value)}
                    className={INPUT_CLS + ' pr-11'} />
                  <button type="button" onClick={() => setShowPw2(v => !v)}
                    className={`absolute right-[10px] top-1/2 -translate-y-1/2 border-none bg-transparent cursor-pointer p-1 flex items-center transition-colors ${showPw2 ? 'text-bordo' : 'text-muted hover:text-ink'}`}>
                    <IcEye open={showPw2} />
                  </button>
                </div>
              </div>
              <label className="flex items-center gap-2 cursor-pointer text-ink-2" style={{ fontSize: 13.5 }}>
                <input type="checkbox" checked={agree} onChange={e => setAgree(e.target.checked)}
                  className="w-4 h-4" style={{ accentColor: '#0877B5' }} />
                <span>Men{' '}
                  <a href="/terms" target="_blank" className="text-bordo font-semibold hover:text-[#066291]">foydalanish shartlari</a>
                  {' '}ga roziman
                </span>
              </label>
              <button type="submit" disabled={signupLoading}
                className="w-full flex items-center justify-center font-semibold text-[15px] px-5 py-[12px] rounded bg-bordo text-white hover:bg-[#066291] transition-colors disabled:opacity-60 disabled:cursor-not-allowed">
                {signupLoading ? "Ro'yxatdan o'tilmoqda..." : "Hisob yaratish"}
              </button>
              <p className="text-center text-[14px] text-muted">
                Hisobingiz bormi?{' '}
                <button type="button" onClick={() => setTab('login')}
                  className="text-bordo font-semibold hover:text-[#066291] bg-transparent border-none cursor-pointer">
                  Kiring
                </button>
              </p>
            </form>
          )}
        </div>
      </main>
    </div>
  );
}
