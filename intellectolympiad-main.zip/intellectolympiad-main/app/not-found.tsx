import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-parchment p-6">
      <div className="max-w-[440px] w-full bg-surface border border-line rounded-2xl p-8 sm:p-10 text-center shadow-sm anim-fade-up">
        {/* Animated compass icon */}
        <div className="relative w-[88px] h-[88px] mx-auto mb-6">
          <span className="absolute inset-0 rounded-full anim-ring bg-bordo/15" />
          <span className="absolute inset-0 rounded-full anim-ring bg-bordo/10" style={{ animationDelay: '.7s' }} />
          <div className="relative w-[88px] h-[88px] rounded-full flex items-center justify-center anim-pop bg-bordo-tint text-bordo">
            <svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10" />
              <polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76" />
            </svg>
          </div>
        </div>

        <div className="font-serif text-[64px] sm:text-[72px] font-bold leading-none text-bordo mb-1 anim-pop" style={{ animationDelay: '.1s' }}>
          404
        </div>

        <h1 className="font-serif text-[21px] font-semibold mb-2 anim-fade-up" style={{ animationDelay: '.16s' }}>
          Sahifa topilmadi
        </h1>
        <p className="text-[14px] text-muted mb-7 leading-relaxed anim-fade-up" style={{ animationDelay: '.22s' }}>
          Siz qidirgan sahifa mavjud emas yoki ko&apos;chirilgan.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 justify-center anim-fade-up" style={{ animationDelay: '.28s' }}>
          <Link href="/"
            className="inline-flex items-center justify-center font-semibold text-[14px] px-6 py-[11px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors">
            Bosh sahifa
          </Link>
        </div>

        <div className="mt-8 pt-6 border-t border-line flex items-center justify-center gap-2 text-muted anim-fade-up" style={{ animationDelay: '.34s' }}>
          <img src="/logo-mark.svg" alt="IO" className="w-5 h-5 opacity-60" />
          <span className="font-serif text-[12px] tracking-[.04em]">Intellect Olympiad</span>
        </div>
        <a href="https://www.soliyev.uz/" target="_blank" rel="noreferrer"
          className="block mt-3 text-[11px] text-muted hover:text-bordo hover:underline anim-fade-up" style={{ animationDelay: '.4s' }}>
          Ishlab chiquvchi · soliyev.uz
        </a>
      </div>
    </div>
  );
}
