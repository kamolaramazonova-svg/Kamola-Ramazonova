import type { Metadata, Viewport } from 'next';
import { Public_Sans, Source_Serif_4, IBM_Plex_Mono } from 'next/font/google';
import './globals.css';
import AutoTranslate from '@/components/AutoTranslate';
import DevCredit from '@/components/DevCredit';

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  // Foydalanuvchi zoom qila olishi kerak (qulaylik) — maksimal cheklov yo'q
  viewportFit: 'cover',
};

const publicSans = Public_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  style: ['normal', 'italic'],
  display: 'swap',
  variable: '--font-sans',
  preload: true,
});

const sourceSerif = Source_Serif_4({
  subsets: ['latin'],
  weight: ['600', '700'],
  style: ['normal', 'italic'],
  display: 'swap',
  variable: '--font-serif',
  preload: true,
});

const ibmPlexMono = IBM_Plex_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  display: 'swap',
  variable: '--font-mono',
  preload: false,
});

export const metadata: Metadata = {
  title: {
    default: 'Intellect Olympiad — Onlayn Olimpiada Platformasi',
    template: '%s | Intellect Olympiad',
  },
  description: "«SIFAT TA'LIM XIZMATI» MChJ tomonidan tashkil etilgan onlayn olimpiada platformasi. O'quvchilar uchun fan olimpiadalari, raqamli sertifikat va bilim bellashuvi.",
  metadataBase: new URL('https://intellectolympiad.uz'),
  applicationName: 'Intellect Olympiad',
  keywords: [
    // ── Asosiy (uz-Latn) ──
    'olimpiada', 'onlayn olimpiada', 'olimpiada 2026', 'fan olimpiadasi', 'fanlar olimpiadasi',
    "o'quvchilar olimpiadasi", 'maktab olimpiadasi', 'maktab o‘quvchilari olimpiadasi',
    'olimpiadalar', 'onlayn test', 'test topshirish', 'bilim bellashuvi', 'bilim sinovi',
    'intellektual bellashuv', 'intellektual olimpiada',
    // ── Keng tarqalgan xato/variant yozilishlar (uz-Latn) ──
    'olimpiyada', 'onlayn olimpiyada', 'olympiada', 'olympiad', 'olimpada', 'olimpiyoda',
    'alimpiada', 'olimpiad', 'olimpiyada 2026', 'olimpyada', 'olimpioda', 'olempiada',
    // ── Fan bo'yicha ──
    'matematika olimpiadasi', 'fizika olimpiadasi', 'biologiya olimpiadasi', 'kimyo olimpiadasi',
    'ingliz tili olimpiadasi', 'tarix olimpiadasi', 'ona tili olimpiadasi', 'informatika olimpiadasi',
    // ── Sertifikat ──
    'onlayn sertifikat', 'raqamli sertifikat', 'sertifikat olish', 'sertifikat tekshirish',
    // ── Brend / tashkilot ──
    'Intellect Olympiad', 'intellekt olimpiada', "Sifat Ta'lim", "Sifat Ta'lim Xizmati",
    'O‘zbekiston olimpiada', 'olympiad uzbekistan', 'olimpiada uzbekistan',
    // ── Kirill (uz-Cyrl) ──
    'олимпиада', 'онлайн олимпиада', 'фан олимпиадаси', 'мактаб олимпиадаси',
    'ўқувчилар олимпиадаси', 'онлайн сертификат', 'сертификат', 'олимпиада 2026',
    // ── Ruscha ──
    'олимпиада онлайн', 'школьная олимпиада', 'олимпиада узбекистан', 'онлайн олимпиада для школьников',
    'олимпиада по математике', 'олимпиада по физике', 'сертификат онлайн', 'олимпиада 2026 узбекистан',
  ],
  authors: [{ name: "SIFAT TA'LIM XIZMATI MChJ" }],
  creator: "SIFAT TA'LIM XIZMATI MChJ",
  publisher: "SIFAT TA'LIM XIZMATI MChJ",
  category: 'education',
  alternates: { canonical: '/' },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large', 'max-snippet': -1, 'max-video-preview': -1 },
  },
  openGraph: {
    title: 'Intellect Olympiad — Onlayn Olimpiada Platformasi',
    description: "«SIFAT TA'LIM XIZMATI» MChJ — o'quvchilar uchun onlayn fan olimpiadalari va raqamli sertifikat.",
    url: 'https://intellectolympiad.uz',
    siteName: 'Intellect Olympiad',
    locale: 'uz_UZ',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Intellect Olympiad — Onlayn Olimpiada Platformasi',
    description: "O'quvchilar uchun onlayn fan olimpiadalari va raqamli sertifikat.",
  },
  icons: {
    icon: [
      { url: '/favicon.svg', type: 'image/svg+xml' },
    ],
    shortcut: '/favicon.svg',
    apple: '/app-icon.svg',
  },
  // Qidiruv tizimlari tasdiqlash (HTML meta-teg). Maxfiy emas — sahifada ochiq turadi.
  verification: {
    google: process.env.NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION || 'UrnFIt8OlsH-IbKFno4Q966D6qOr-TgArKOlSbujozg',
    yandex: process.env.NEXT_PUBLIC_YANDEX_VERIFICATION || '870c0ee0d91e59a9',
  },
};

// ── Structured data (JSON-LD) — Google "knowledge panel" + boy natijalar uchun ──
const ORG_JSONLD = {
  '@context': 'https://schema.org',
  '@graph': [
    {
      '@type': 'EducationalOrganization',
      '@id': 'https://intellectolympiad.uz/#organization',
      name: 'Intellect Olympiad',
      legalName: "SIFAT TA'LIM XIZMATI MChJ",
      url: 'https://intellectolympiad.uz',
      logo: 'https://intellectolympiad.uz/logo-mark.svg',
      description: "O'quvchilar uchun onlayn fan olimpiadalari va raqamli sertifikat platformasi.",
      areaServed: 'UZ',
      contactPoint: {
        '@type': 'ContactPoint',
        telephone: '+998900362121',
        contactType: 'customer support',
        availableLanguage: ['uz', 'ru', 'en'],
      },
    },
    {
      '@type': 'WebSite',
      '@id': 'https://intellectolympiad.uz/#website',
      url: 'https://intellectolympiad.uz',
      name: 'Intellect Olympiad',
      inLanguage: 'uz',
      publisher: { '@id': 'https://intellectolympiad.uz/#organization' },
    },
  ],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="uz" className={`${publicSans.variable} ${sourceSerif.variable} ${ibmPlexMono.variable}`}>
      <body className="bg-parchment text-ink antialiased font-sans">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(ORG_JSONLD) }}
        />
        <AutoTranslate />
        {children}
        <DevCredit />
      </body>
    </html>
  );
}
