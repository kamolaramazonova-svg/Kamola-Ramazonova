import { ImageResponse } from 'next/og';

// Ijtimoiy tarmoqlarda ulashilganda ko'rinadigan rasm (Telegram/Facebook/Twitter).
// Binar fayl shart emas — runtime'da brendli rasm chiziladi.
export const alt = 'Intellect Olympiad — Onlayn Olimpiada Platformasi';
export const size = { width: 1200, height: 630 };
export const contentType = 'image/png';

export default function OgImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'flex-start',
          justifyContent: 'center',
          padding: '80px',
          background: 'linear-gradient(135deg, #0b3b5a 0%, #0877B5 60%, #066291 100%)',
          color: '#ffffff',
          fontFamily: 'sans-serif',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '96px',
            height: '96px',
            borderRadius: '999px',
            background: '#ffffff',
            color: '#0877B5',
            fontSize: '44px',
            fontWeight: 800,
            marginBottom: '36px',
          }}
        >
          IO
        </div>
        <div style={{ fontSize: '68px', fontWeight: 800, lineHeight: 1.05, letterSpacing: '-1px' }}>
          Intellect Olympiad
        </div>
        <div style={{ fontSize: '34px', marginTop: '20px', color: '#e7c98f', fontWeight: 600 }}>
          Onlayn Olimpiada Platformasi
        </div>
        <div style={{ fontSize: '26px', marginTop: '28px', color: 'rgba(255,255,255,0.82)' }}>
          O&apos;quvchilar uchun bilim bellashuvi · raqamli sertifikat · intellectolympiad.uz
        </div>
      </div>
    ),
    { ...size },
  );
}
