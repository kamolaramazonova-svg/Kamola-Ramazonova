'use client';
import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { news as newsApi, type NewsItem } from '@/lib/api';
import { useLocale, fmtDate } from '@/lib/locale';

const BADGE: Record<string, { l: string; c: string }> = {
  OFFICIAL: { l: "Rasmiy ma'lumot", c: 'bg-bordo-tint text-bordo' },
  NEWS: { l: 'Yangilik', c: 'bg-ds-info-tint text-ds-info' },
  ANNOUNCEMENT: { l: "E'lon", c: 'bg-ds-amber-tint text-ds-amber' },
  RESULTS: { l: 'Natija', c: 'bg-ds-green-tint text-ds-green' },
};
const fmt = (iso: string | null) => fmtDate(iso);

export default function NewsDetailPage() {
  const params = useParams();
  const slug = String(params?.slug ?? '');
  const [item, setItem] = useState<NewsItem | null>(null);
  const [state, setState] = useState<'loading' | 'ok' | 'notfound'>('loading');
  const [locale] = useLocale();

  useEffect(() => {
    if (!slug) return;
    newsApi.bySlug(slug, locale)
      .then(n => { setItem(n); setState('ok'); })
      .catch(() => setState('notfound'));
  }, [slug, locale]);

  return (
    <div className="min-h-screen bg-parchment">
      <header className="bg-surface border-b border-line">
        <div className="max-w-wrap mx-auto px-6 flex items-center justify-between min-h-[64px] gap-4">
          <a href="/" className="flex items-center gap-3 flex-none">
            <img src="/logo-mark.svg" alt="Intellect Olympiad" className="w-10 h-10 flex-none" />
            <b className="font-serif font-semibold text-sm text-ink">Intellect Olympiad</b>
          </a>
          <a href="/news" className="text-[13.5px] font-semibold text-bordo hover:underline">← Yangiliklar</a>
        </div>
      </header>

      <main className="max-w-[760px] mx-auto px-6 py-12">
        {state === 'loading' ? (
          <div className="min-h-[60vh] flex items-center justify-center">
            <div className="text-center anim-fade-up">
              <div className="anim-float mb-4 inline-block">
                <img src="/logo-mark.svg" alt="IO" className="w-14 h-14" />
              </div>
              <div className="text-muted text-[14px] timer-pulse">Yuklanmoqda…</div>
            </div>
          </div>
        ) : state === 'notfound' || !item ? (
          <div className="min-h-[60vh] flex items-center justify-center">
            <div className="max-w-[420px] w-full bg-surface border border-line rounded-2xl p-8 text-center shadow-sm anim-fade-up">
              <div className="w-16 h-16 rounded-full bg-parchment-2 text-muted flex items-center justify-center mx-auto mb-4 anim-pop">
                <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6" /></svg>
              </div>
              <h1 className="font-serif text-[21px] font-semibold mb-2">Yangilik topilmadi</h1>
              <p className="text-[13.5px] text-muted mb-5">Bunday yangilik mavjud emas yoki o‘chirilgan.</p>
              <a href="/news" className="inline-block font-semibold text-[14px] px-6 py-[11px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors">Yangiliklar</a>
            </div>
          </div>
        ) : (
          <article>
            <span className={`inline-block text-[12px] font-bold px-3 py-1 rounded-full ${BADGE[item.category]?.c ?? 'bg-bordo-tint text-bordo'}`}>{BADGE[item.category]?.l ?? item.category}</span>
            <h1 className="font-serif text-[clamp(26px,4vw,38px)] font-semibold leading-tight mt-4 mb-3">{item.title}</h1>
            <div className="flex items-center gap-3 text-[13px] text-muted mb-6">
              <span>Intellect Olympiad</span>
              <span className="w-[3px] h-[3px] rounded-full bg-line-2 inline-block" />
              <span>{fmt(item.publishedAt ?? item.createdAt)}</span>
            </div>
            {item.imageUrl && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={item.imageUrl} alt={item.title} className="w-full rounded-lg border border-line mb-6" />
            )}
            {item.summary && <p className="text-[17px] text-ink-2 leading-relaxed font-medium mb-5">{item.summary}</p>}
            <div className="text-[15.5px] text-ink-2 leading-[1.8]">
              {/* [[IMG:url]] belgilari matnning aynan o'z joyida rasm bo'lib chiqadi */}
              {item.body.split(/\[\[IMG:([^\]]+)\]\]/g).map((part, i) =>
                i % 2 === 1
                  ? (/^(https?:\/\/|\/)/i.test(part.trim())
                      // eslint-disable-next-line @next/next/no-img-element
                      ? <img key={i} src={part.trim()} alt="" loading="lazy" className="w-full rounded-lg border border-line my-5" />
                      : null)
                  : <span key={i} className="whitespace-pre-line">{part}</span>
              )}
            </div>
          </article>
        )}
      </main>
    </div>
  );
}
