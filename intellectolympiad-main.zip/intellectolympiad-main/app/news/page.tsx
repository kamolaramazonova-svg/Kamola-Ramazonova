'use client';
import { useState, useEffect } from 'react';
import { news as newsApi, type NewsItem } from '@/lib/api';
import { useLocale, localeMonth } from '@/lib/locale';

const DIAMOND = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='60' height='60'%3E%3Cpath d='M30 0L60 30L30 60L0 30Z' fill='none' stroke='%230877B5' stroke-opacity='0.03' stroke-width='1'/%3E%3C/svg%3E")`;
const DIAMOND_WHITE = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='44' height='44'%3E%3Cpath d='M22 0L44 22L22 44L0 22Z' fill='none' stroke='%23ffffff' stroke-opacity='0.07' stroke-width='1'/%3E%3C/svg%3E")`;

// UI label → backend enum (NewsCategory). 'Barchasi' = no filter.
const CATS: { label: string; value?: string }[] = [
  { label: 'Barchasi' },
  { label: "Rasmiy ma'lumot", value: 'OFFICIAL' },
  { label: 'Yangiliklar', value: 'NEWS' },
  { label: "E'lonlar", value: 'ANNOUNCEMENT' },
  { label: 'Natijalar', value: 'RESULTS' },
];

const BADGE: Record<string, { l: string; c: string }> = {
  OFFICIAL: { l: "Rasmiy ma'lumot", c: 'bg-bordo-tint text-bordo' },
  NEWS: { l: 'Yangilik', c: 'bg-ds-info-tint text-ds-info' },
  ANNOUNCEMENT: { l: "E'lon", c: 'bg-ds-amber-tint text-ds-amber' },
  RESULTS: { l: 'Natija', c: 'bg-ds-green-tint text-ds-green' },
};

function dparts(iso: string | null) {
  const d = new Date(iso ?? Date.now());
  return { day: String(d.getDate()).padStart(2, '0'), month: localeMonth(d.getMonth()), year: String(d.getFullYear()) };
}

export default function NewsPage() {
  const [activeCat, setActiveCat] = useState('Barchasi');
  const [items, setItems] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [locale] = useLocale();

  useEffect(() => {
    const value = CATS.find(c => c.label === activeCat)?.value;
    setLoading(true);
    setError(false);
    newsApi.list({ ...(value ? { category: value } : {}), lang: locale })
      .then(res => setItems(res.data ?? []))
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, [activeCat, locale]);

  const featured = items.find(n => n.isFeatured) ?? items[0] ?? null;
  const rest = featured ? items.filter(n => n.id !== featured.id) : items;

  return (
    <div className="min-h-screen bg-parchment">
      {/* Header */}
      <header className="bg-surface border-b border-line">
        <div className="max-w-wrap mx-auto px-6 flex items-center justify-between min-h-[64px] gap-4">
          <a href="/" className="flex items-center gap-2 sm:gap-3 flex-none">
            <img src="/logo-mark.svg" alt="Intellect Olympiad" className="w-10 h-10 flex-none" />
            <div className="hidden sm:flex flex-col leading-[1.05]">
              <b className="font-serif font-semibold text-sm text-ink">Intellect Olympiad</b>
              <small className="text-muted" style={{ fontSize: 10.5, letterSpacing: '.12em', textTransform: 'uppercase' }}>Olimpiada xizmati</small>
            </div>
          </a>

          {/* Bosh sahifaga qaytish — mobilda (desktopda nav'da bor) */}
          <a href="/" className="md:hidden inline-flex items-center gap-1.5 text-[13px] font-semibold text-ink-2 bg-surface border border-line-2 rounded-lg px-3 py-2 hover:border-bordo hover:text-bordo transition-colors flex-none mr-auto">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="flex-none"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>
            Bosh sahifa
          </a>

          <nav className="hidden md:flex items-center gap-5 text-[13.5px] font-semibold">
            <a href="/" className="text-ink-2 hover:text-ink transition-colors">Bosh sahifa</a>
            <a href="/news" className="text-bordo">Yangiliklar</a>
            <a href="/verify" className="text-ink-2 hover:text-ink transition-colors">Sertifikat</a>
          </nav>
          <div className="flex items-center gap-2">
            <a href="/login" className="text-[13px] text-ink-2 hover:text-ink hidden md:block transition-colors">Kirish</a>
            <a href="/register" className="font-semibold text-[13px] px-4 py-[7px] rounded bg-bordo text-white hover:bg-bordo-700 transition-colors">
              Ro&apos;yxatdan o&apos;tish
            </a>
          </div>
        </div>
      </header>

      {/* Page head */}
      <section className="relative overflow-hidden border-b border-line py-[44px] pb-[38px] px-6"
        style={{ background: 'linear-gradient(180deg, #ffffff, #f2f5f8)' }}>
        <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: DIAMOND }} />
        <div className="relative max-w-wrap mx-auto">
          <span className="text-[11px] tracking-[.14em] uppercase text-bordo font-bold">Matbuot markazi</span>
          <h1 className="font-serif font-semibold text-ink mt-[10px]" style={{ fontSize: 'clamp(22px,5vw,40px)' }}>
            Yangiliklar va rasmiy ma&apos;lumot
          </h1>
          <p className="text-ink-2 mt-[10px] text-[16px]" style={{ maxWidth: '58ch' }}>
            Olimpiadalar jadvali, rasmiy e&apos;lonlar, natijalar va platforma yangiliklaridan birinchi bo&apos;lib xabardor bo&apos;ling.
          </p>
          <div className="flex gap-2 flex-wrap mt-[26px]">
            {CATS.map(c => (
              <button key={c.label} onClick={() => setActiveCat(c.label)}
                className={`text-[12px] sm:text-[13.5px] font-semibold px-3 sm:px-4 py-2 rounded-full border cursor-pointer transition-all whitespace-nowrap ${
                  activeCat === c.label
                    ? 'bg-bordo border-bordo text-white'
                    : 'bg-surface border-line-2 text-ink-2 hover:border-bordo hover:text-bordo'
                }`}>
                {c.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Body */}
      <section className="py-[44px] pb-[64px] px-6">
        <div className="max-w-wrap mx-auto grid lg:grid-cols-[1fr_320px] gap-9 items-start">
          {/* Main */}
          <div>
            {loading ? (
              <div className="flex flex-col gap-4">
                {[0, 1, 2, 3].map(i => (
                  <div key={i} className="h-[112px] bg-surface border border-line rounded-lg animate-pulse" />
                ))}
              </div>
            ) : error ? (
              <div className="bg-surface border border-line rounded-lg p-10 text-center">
                <p className="text-ink-2 text-[15px]">Yangiliklarni yuklashda xatolik yuz berdi.</p>
                <button onClick={() => setActiveCat(c => c)} className="mt-4 font-semibold text-[14px] px-5 py-[9px] rounded bg-bordo text-white hover:bg-bordo-700 transition-colors">
                  Qayta urinish
                </button>
              </div>
            ) : items.length === 0 ? (
              <div className="bg-surface border border-line rounded-lg p-12 text-center text-muted text-[15px]">
                Bu turkumda hozircha yangilik yo&apos;q.
              </div>
            ) : (
              <>
                {/* Featured */}
                {featured && (
                  <a href={`/news/${featured.slug}`}
                    className="grid md:grid-cols-[1.1fr_1fr] border border-line rounded-lg overflow-hidden bg-surface mb-[30px] shadow-sm hover:border-bordo hover:shadow transition-all">
                    <div className="relative bg-bordo-900 min-h-[160px] sm:min-h-[240px] grid place-items-center overflow-hidden">
                      <div className="absolute inset-0" style={{ backgroundImage: DIAMOND_WHITE }} />
                      {featured.imageUrl ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={featured.imageUrl} alt={featured.title} className="absolute inset-0 w-full h-full object-cover" />
                      ) : (
                        <div className="relative w-[92px] h-[92px] rounded-full bg-bordo grid place-items-center"
                          style={{ boxShadow: 'inset 0 0 0 3px #0877B5, inset 0 0 0 7px #fff, inset 0 0 0 9px rgba(154,123,63,.6)' }}>
                          <span className="text-white font-serif font-bold text-[36px]">IO</span>
                        </div>
                      )}
                    </div>
                    <div className="p-5 sm:p-[30px_32px] flex flex-col justify-center">
                      <span className={`self-start text-[12px] font-bold px-3 py-1 rounded-full ${BADGE[featured.category]?.c ?? 'bg-bordo-tint text-bordo'}`}>{BADGE[featured.category]?.l ?? featured.category}</span>
                      <h2 className="font-serif text-[25px] font-semibold leading-[1.2] text-ink mt-3 mb-[10px]">{featured.title}</h2>
                      <p className="text-ink-2 text-[15px] line-clamp-2">{featured.summary}</p>
                      <div className="flex items-center gap-3 mt-4 text-[12.5px] text-muted">
                        <span>Intellect Olympiad</span>
                        <span className="w-[3px] h-[3px] rounded-full bg-line-2 inline-block" />
                        <span>{(() => { const d = dparts(featured.publishedAt ?? featured.createdAt); return `${d.day}-${d.month}, ${d.year}`; })()}</span>
                      </div>
                    </div>
                  </a>
                )}

                {/* List */}
                <div className="flex flex-col gap-4">
                  {rest.map(n => {
                    const d = dparts(n.publishedAt ?? n.createdAt);
                    const b = BADGE[n.category] ?? { l: n.category, c: 'bg-parchment-2 text-muted' };
                    return (
                      <a key={n.id} href={`/news/${n.slug}`}
                        className="grid grid-cols-[64px_1fr] sm:grid-cols-[92px_1fr] gap-3 sm:gap-5 p-3 sm:p-5 bg-surface border border-line rounded-lg transition-all hover:border-bordo hover:shadow-sm hover:-translate-y-px">
                        <div className="border-r border-line pr-4 self-center text-center">
                          <b className="font-serif text-[30px] font-bold text-bordo block leading-none">{d.day}</b>
                          <span className="text-[12px] text-muted uppercase tracking-[.06em]">{d.month}</span>
                          <small className="text-[11px] text-line-2 block mt-[2px]">{d.year}</small>
                        </div>
                        <div>
                          <span className={`inline-block text-[11.5px] font-bold px-2 py-[3px] rounded-full mb-2 ${b.c}`}>{b.l}</span>
                          <h3 className="font-serif text-[18px] font-semibold leading-[1.3] text-ink mt-2 mb-[6px]">{n.title}</h3>
                          <p className="text-[14px] text-ink-2 line-clamp-2">{n.summary}</p>
                        </div>
                      </a>
                    );
                  })}
                </div>
              </>
            )}
          </div>

          {/* Aside */}
          <aside className="flex flex-col gap-[22px] lg:sticky lg:top-[92px]">
            <div className="bg-surface border border-line rounded-lg p-[22px]">
              <h4 className="text-[13px] font-sans tracking-[.04em] uppercase text-muted font-bold mb-4">Tezkor havolalar</h4>
              {[
                { l: 'Olimpiadalar', h: '/#olimpiadalar' },
                { l: 'Hakamlar hay‘ati', h: '/#jury' },
                { l: 'Sertifikat tekshirish', h: '/verify' },
                { l: 'Ko‘p so‘raladigan savollar', h: '/faq' },
              ].map((x, i) => (
                <a key={i} href={x.h} className="flex items-center justify-between py-[11px] border-b border-line last:border-0 text-[13.5px] text-ink hover:text-bordo transition-colors">
                  {x.l}<span className="text-muted">→</span>
                </a>
              ))}
            </div>

            <div className="rounded-lg p-6 text-white" style={{ background: 'linear-gradient(135deg, #0b3b5a, #0877B5)' }}>
              <div className="flex items-center gap-2.5 mb-2">
                <span className="w-9 h-9 rounded-lg bg-white/12 border border-white/20 flex items-center justify-center flex-none">
                  <svg viewBox="0 0 24 24" fill="currentColor" className="text-white" style={{ width: 19, height: 19 }}><path d="M21.94 4.6 18.9 19.3c-.23 1.02-.84 1.27-1.7.79l-4.7-3.46-2.27 2.18c-.25.25-.46.46-.94.46l.33-4.78L18.6 6.1c.38-.34-.08-.53-.6-.19L7.3 12.78l-4.65-1.45c-1.01-.32-1.03-1.01.21-1.5l18.2-7.01c.84-.31 1.58.2 1.31 1.78z"/></svg>
                </span>
                <b className="font-serif text-[16px] block">Telegramda kuzating</b>
              </div>
              <p className="text-[13px] mb-4" style={{ color: 'rgba(255,255,255,.82)' }}>
                Yangi olimpiadalar va rasmiy e&apos;lonlardan birinchi bo&apos;lib xabardor bo&apos;ling. Botni oching va <b className="text-white">/start</b> bosing.
              </p>
              <a href={`https://t.me/${process.env.NEXT_PUBLIC_TELEGRAM_BOT || 'Intellect_Olympiad_bot'}?start=news`} target="_blank" rel="noreferrer"
                className="w-full flex items-center justify-center gap-2 font-semibold text-[14px] px-5 py-[11px] rounded bg-white text-bordo hover:bg-parchment-2 transition-colors border-none cursor-pointer">
                <svg viewBox="0 0 24 24" fill="currentColor" style={{ width: 17, height: 17 }}><path d="M21.94 4.6 18.9 19.3c-.23 1.02-.84 1.27-1.7.79l-4.7-3.46-2.27 2.18c-.25.25-.46.46-.94.46l.33-4.78L18.6 6.1c.38-.34-.08-.53-.6-.19L7.3 12.78l-4.65-1.45c-1.01-.32-1.03-1.01.21-1.5l18.2-7.01c.84-.31 1.58.2 1.31 1.78z"/></svg>
                Botni ochib /start bosing
              </a>
            </div>
          </aside>
        </div>
      </section>
    </div>
  );
}
