'use client';
import { useState, useEffect } from 'react';
import { olympiads as olympiadApi, content as contentApi, news as newsApi, BASE as API_BASE, type Olympiad, type NewsItem, type Partner } from '@/lib/api';
import LandingRatings from '@/components/LandingRatings';
import { LoadingRow } from '@/components/Spinner';
import ScrollReveal from '@/components/ScrollReveal';
import TiltCard from '@/components/TiltCard';
import { useLocale, LOCALES, LOCALE_LABEL, LOCALE_FULL, fmtDate } from '@/lib/locale';

const OLYMPIAD_STATUS_META: Record<string, { label: string; cls: string }> = {
  UPCOMING: { label: 'Tez kunda', cls: 'bg-ds-amber-tint text-ds-amber border border-ds-amber/30' },
  ACTIVE: { label: 'Faol', cls: 'bg-ds-green-tint text-ds-green border border-ds-green/30' },
};

// Sana — joriy tilga mos (fmtDate getLocale() o'qiydi; sahifa til o'zgarsa qayta render bo'ladi).
const fmtUzDateTime = (s: string) => fmtDate(s, { time: true });
const fmtUzDate = (s: string | null) => fmtDate(s);
function fmtUzPrice(n: number) {
  return new Intl.NumberFormat('uz-UZ').format(n);
}

// Animated counter — counts from 0 → target with ease-out, staggered delay,
// color flip on completion, gold-glow during animation, tabular-nums to prevent jitter.
function AnimatedStat({ to, suffix, label, delay = 0 }: { to: number; suffix: string; label: string; delay?: number }) {
  const [val, setVal] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    let frame: number;
    const start = performance.now() + delay;
    const duration = 2200;
    const tick = (now: number) => {
      if (now < start) { frame = requestAnimationFrame(tick); return; }
      const t = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - t, 3);
      setVal(Math.round(to * eased));
      if (t < 1) frame = requestAnimationFrame(tick);
      else setDone(true);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [to, delay]);

  return (
    <div>
      <b className="font-serif text-[26px] lg:text-[28px] font-semibold block leading-none text-ink transition-all duration-500"
         style={{
           fontVariantNumeric: 'tabular-nums',
           textShadow: done ? 'none' : '0 0 12px rgba(31,27,25,0.18)',
           letterSpacing: done ? '0' : '0.4px',
         }}>
        {val}<span style={{ marginLeft: 2 }}>{suffix}</span>
      </b>
      <span className="text-[12px] lg:text-[13px] text-muted font-medium">{label}</span>
    </div>
  );
}

// News kategoriya nishonlari (yangiliklar sahifasi bilan bir xil)
const NEWS_BADGE: Record<string, { l: string; c: string }> = {
  OFFICIAL: { l: "Rasmiy ma'lumot", c: 'bg-bordo-tint text-bordo' },
  NEWS: { l: 'Yangilik', c: 'bg-ds-info-tint text-ds-info' },
  ANNOUNCEMENT: { l: "E'lon", c: 'bg-ds-amber-tint text-ds-amber' },
  RESULTS: { l: 'Natija', c: 'bg-ds-green-tint text-ds-green' },
};
function fmtNewsDate(iso: string | null) {
  return fmtUzDate(iso);
}

const SUBJECTS = [
  'Matematika', 'Fizika', 'Kimyo', 'Biologiya', 'Informatika',
  'Ingliz tili', 'Tarix', 'Geografiya',
];

// Sovrinlar — har g'olib/ishtirokchi oladigan mukofot turlari (daraja/tier emas)
const REWARDS: { title: string; desc: string; icon: JSX.Element }[] = [
  { title: 'Rasmiy sertifikat', desc: 'QR-kodli, doimiy tasdiqlangan — istalgan vaqtda tekshirsa bo\'ladi', icon: <><circle cx="12" cy="8" r="6"/><path d="M15.5 13.5 17 22l-5-3-5 3 1.5-8.5"/></> },
  { title: 'Pul mukofoti', desc: 'G\'oliblar uchun pul mukofotlari va mukofot jamg\'armasi', icon: <><rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 12h.01M18 12h.01"/></> },
  { title: 'Universitetga yo\'l', desc: 'Eng yaxshilarga hamkor universitetlarga imtiyozli, imtihonsiz yo\'l', icon: <><path d="M22 10 12 5 2 10l10 5 10-5z"/><path d="M6 12v5c0 1 2.7 2.5 6 2.5s6-1.5 6-2.5v-5"/></> },
  { title: 'Maxsus sovg\'alar', desc: 'Qimmatbaho sovrinlar, esdalik sovg\'alar va rasmiy tan olinish', icon: <><polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/></> },
];

const FAQS = [
  { q: 'Olimpiadada qanday qatnashaman?', a: "Ro'yxatdan o'ting, shaxsiy kabinetdan olimpiadani tanlang va to'lovni amalga oshiring. To'lov tasdiqlangach joyingiz band qilinadi va imtihon kuni testga kirasiz." },
  { q: "To'lovni qanday amalga oshiraman?", a: "Kabinetda olimpiadani tanlaganingizda to'lov rekvizitlari (hisob raqami) ko'rsatiladi. To'lovni amalga oshirib, chek (skrinshot)ni yuklaysiz — administrator tekshirib tasdiqlaydi." },
  { q: 'Sertifikat qanday beriladi va haqiqiyligini qanday tekshiraman?', a: "Imtihon tugagach natija avtomatik hisoblanadi va QR-kodli rasmiy sertifikat beriladi. Uni «Sertifikat tekshirish» bo'limida IO-2026-XXXXXXX kodi yoki QR orqali istalgan vaqtda tasdiqlash mumkin." },
  { q: 'Olimpiada qanday o\'tadi?', a: "Olimpiada onlayn test ko'rinishida o'tkaziladi: belgilangan vaqtda kabinetdan testga kirib, savollarga javob berasiz. Natija avtomatik hisoblanadi va o'tganlarga QR-kodli sertifikat beriladi." },
  { q: 'Ustozlar dasturi nima va qanday ishlaydi?', a: "Ustoz referal havolasini tarqatadi — o'quvchi shu havola orqali ro'yxatdan o'tsa, ball ustozga yoziladi: har bir o'quvchi uchun +5, o'quvchi 1-o'rin +30, 2-o'rin +20, 3-o'rin +10. Reyting e'lon qilinadi va eng faol ustozlar pul mukofot hamda sovg'alar bilan taqdirlanadi." },
  { q: 'Imtihon davomida adolat qanday ta\'minlanadi?', a: "Test serverda himoyalangan: vaqt server tomonda hisoblanadi, savollar aralashtiriladi, bitta qurilma va bitta urinish qoidasi hamda real vaqt monitoringi qo'llaniladi." },
];

const STEPS = [
  { n: '01', t: "Ro'yxatdan o'ting", d: "Bir daqiqada hisob yarating va o'zingizga mos fanni tanlang." },
  { n: '02', t: "Joyingizni band qiling", d: "Qulay to'lov qiling va chekni yuklang — joyingiz kafolatlanadi." },
  { n: '03', t: 'Testni topshiring', d: "Belgilangan kunda kiring — adolatli, himoyalangan va shaffof imtihon." },
  { n: '04', t: 'Sertifikatga ega bo\'ling', d: "Natijani darhol biling va QR bilan tasdiqlangan sertifikatni qo'lga kiriting." },
];

// Lucide-style SVG icons — currentColor, strokeWidth 1.5
const IconShield = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
  </svg>
);
const IconBarChart = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>
  </svg>
);
const IconAward = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/>
  </svg>
);
const IconZap = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
  </svg>
);
const IconMonitor = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>
  </svg>
);
const IconUsers = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
  </svg>
);

const FEATS = [
  { Icon: IconShield, t: 'Xavfsiz platforma', d: "Ko'p qatlamli himoya va real vaqt monitoring." },
  { Icon: IconBarChart, t: 'Batafsil tahlil', d: "Har bir savol bo'yicha to'liq natija va AI tavsiyalari." },
  { Icon: IconAward, t: 'Rasmiy sertifikat', d: "QR-kod orqali tekshiriluvchi raqamli sertifikat." },
  { Icon: IconZap, t: 'Tez natija', d: "Imtihon tugagandan so'ng darhol avtomatik hisoblash." },
  { Icon: IconMonitor, t: 'Har qanday qurilma', d: "Kompyuter, planshet yoki telefonda ishlaydigan interfeys." },
  { Icon: IconUsers, t: 'Ekspert hakamlar', d: "Har bir fan bo'yicha tajribali mutaxassislar hay'ati." },
];

// Subject / service icons
const IconMessageSquare = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
  </svg>
);
const IconScroll = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>
  </svg>
);

// Quick-access services — the genuinely useful actions previously buried in the footer.
const SERVICES = [
  { Icon: IconAward,         t: 'Sertifikat tekshirish', d: 'IO-2026-XXXXXXX kodi yoki QR orqali sertifikat haqiqiyligini bir lahzada tasdiqlang.', cta: 'Tekshirish',          href: '/verify' },
  { Icon: IconBarChart,      t: 'Reyting va natijalar',  d: "Ishtirokchilar, maktablar va viloyatlar bo'yicha yillik reytingni jonli kuzating.",       cta: "Reytingni ko'rish",   href: '/#reyting' },
  { Icon: IconUsers,         t: 'Ustozlar dasturi',      d: "Referal havola orqali o'quvchilaringizni olib keling, ball to'plang va pul mukofot yutib oling.", cta: "Ustoz bo'lish",  href: '/register?ustoz=1' },
  { Icon: IconMonitor,       t: 'Shaxsiy kabinet',       d: "To'lovlar, imtihonlar va sertifikatlaringiz — barchasi yagona shaxsiy panelda.",          cta: 'Kabinetga kirish',    href: '/cabinet' },
  { Icon: IconScroll,        t: 'Yangiliklar',           d: "Olimpiada e'lonlari, natijalar va rasmiy xabarlardan birinchi bo'lib xabardor bo'ling.",  cta: "O'qish",              href: '/news' },
  { Icon: IconMessageSquare, t: "Bog'lanish va yordam",  d: "Savollaringiz bormi? Biz bilan bog'laning yoki ko'p so'raladigan savollar bo'limini oching.", cta: "Bog'lanish",       href: '/contact' },
];

const IconBookOpen = () => (
  <svg width="25" height="25" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>
  </svg>
);
const IconBuilding = () => (
  <svg width="25" height="25" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/>
  </svg>
);
const IconGlobe2 = () => (
  <svg width="25" height="25" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
  </svg>
);

const IconCheck = ({ size = 18, cls = '' }: { size?: number; cls?: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={cls}>
    <polyline points="20 6 9 17 4 12"/>
  </svg>
);

// Diamond SVG pattern for backgrounds
const DIAMOND_PATTERN = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='56' height='56'%3E%3Cpath d='M28 0L56 28L28 56L0 28Z' fill='none' stroke='%230877B5' stroke-opacity='0.10' stroke-width='1'/%3E%3C/svg%3E")`;
const DIAMOND_PATTERN_WHITE = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='60' height='60'%3E%3Cpath d='M30 0L60 30L30 60L0 30Z' fill='none' stroke='%23ffffff' stroke-opacity='0.07' stroke-width='1'/%3E%3C/svg%3E")`;

export default function HomePage() {
  const [locale, setLocale] = useLocale();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false); // header til dropdown (mobil)
  const [heroSlide, setHeroSlide] = useState(0);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  // Live olympiads (announced ahead of time + currently active)
  const [olys, setOlys] = useState<Olympiad[]>([]);
  const [olysLoading, setOlysLoading] = useState(true);
  const [showAllOlys, setShowAllOlys] = useState(false);

  // Hero namuna sertifikati — DOIM qat'iy demo (portfolio). Haqiqiy sertifikatlarni
  // ko'rsatmaymiz (ular o'quvchilarniki — landing namuna bo'lib qolsin).

  // Latest news for the landing strip (re-fetches when the language changes)
  const [latestNews, setLatestNews] = useState<NewsItem[]>([]);
  useEffect(() => { newsApi.list({ limit: 3, lang: locale }).then(r => setLatestNews(r.data)).catch(() => {}); }, [locale]);

  const [partners, setPartners] = useState<Partner[]>([]);
  useEffect(() => { contentApi.partners().then(setPartners).catch(() => {}); }, []);
  const cHolder = 'Dostonbek Solijonov';
  const cSubject = 'Matematika';
  const cScore = 92;
  const cCode = 'IO-2026-0048213';
  const cSig = 'A7F3-9C21-E80B';
  const cDate = fmtUzDate('2026-06-04');
  // Asosiy sahifa DEMO sertifikati — QR portfolioga (soliyev.uz). Rasmiy sertifikat
  // va tekshirish sahifasi QR'i esa standart (intellectolympiad tekshirish) bo'ladi.
  const cQr = `${API_BASE}/certificates/${encodeURIComponent(cCode)}/qr?to=portfolio`;

  // Hero carousel auto-rotate. Depends on heroSlide so a manual click restarts the
  // 4.5s cycle (no instant jump), and pauses while the user hovers/focuses the hero.
  const [heroPaused, setHeroPaused] = useState(false);
  useEffect(() => {
    if (heroPaused) return;
    const timer = setInterval(() => setHeroSlide(i => (i + 1) % 3), 4500);
    return () => clearInterval(timer);
  }, [heroSlide, heroPaused]);

  // Fetch published olympiads for the landing list (re-fetches on language change)
  useEffect(() => {
    const now = Date.now();
    olympiadApi.list(undefined, locale).then(list => {
      // Only olympiads whose date hasn't arrived yet (become inactive once startsAt is reached),
      // sorted by date: nearest day first → farthest day last
      const live = list
        .filter(o => (o.status === 'UPCOMING' || o.status === 'ACTIVE') && new Date(o.startsAt).getTime() > now)
        .sort((a, b) => new Date(a.startsAt).getTime() - new Date(b.startsAt).getTime());
      setOlys(live);
    }).catch(() => {}).finally(() => setOlysLoading(false));
  }, [locale]);

  const navLinks = [
    { href: '#olimpiadalar', label: 'Olimpiadalar' },
    { href: '#reyting', label: 'Reyting' },
    { href: '#sovrinlar', label: 'Sovrinlar' },
    { href: '/news', label: 'Yangiliklar' },
  ];

  return (
    <div className="bg-parchment text-ink antialiased">
      <ScrollReveal />
      {/* Gov topbar */}
      <div className="bg-[#0a2a40] text-[#9fbdd2] text-[11px] font-semibold py-[7px]">
        <div className="max-w-wrap mx-auto px-6 flex items-center justify-between gap-3">
          <span className="truncate">Intellect Olympiad — &laquo;SIFAT TA&apos;LIM XIZMATI&raquo; MChJ tomonidan tashkil etiladi</span>
          <a href="tel:+998900362121" className="flex items-center gap-1.5 flex-none text-white hover:text-gold transition-colors" aria-label="Qo'llab-quvvatlash">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 12a9 9 0 0 1 18 0"/><path d="M21 12v3a3 3 0 0 1-3 3h-1"/><rect x="2" y="12" width="4" height="6" rx="1.5"/><rect x="18" y="12" width="4" height="6" rx="1.5"/><path d="M12 18h2"/></svg>
            <span className="hidden sm:inline">Yordam:</span> +998 90 036 21 21
          </a>
        </div>
      </div>

      {/* Header */}
      <header className="bg-surface border-b border-line sticky top-0 z-50 shadow-sm">
        <div className="max-w-wrap mx-auto px-4 sm:px-6 flex items-center justify-between gap-2 sm:gap-4 min-h-[64px] sm:min-h-[68px]">
          <a href="/" className="flex items-center gap-3 flex-none">
            <img src="/logo-mark.svg" alt="Intellect Olympiad" className="w-11 h-11 flex-none" />
            <div className="flex flex-col leading-[1.05]">
              <b className="font-serif font-semibold text-base text-ink">Intellect Olympiad</b>
              <small className="text-[10.5px] tracking-[.14em] uppercase text-muted font-semibold">Onlayn Olimpiada</small>
            </div>
          </a>

          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map(l => (
              <a key={l.href} href={l.href}
                className="text-[14px] font-medium text-ink-2 px-3 py-2 rounded hover:bg-parchment-2 transition-colors">
                {l.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <div data-notranslate className="hidden md:flex items-center gap-[2px] bg-parchment-2 border border-line rounded p-[3px]">
              {LOCALES.map(l => (
                <button key={l} type="button"
                  title={LOCALE_FULL[l]}
                  aria-label={`Til: ${LOCALE_FULL[l]}`}
                  onClick={() => setLocale(l)}
                  className={`text-[11px] font-semibold px-[9px] py-[3px] rounded-sm border-none transition-colors cursor-pointer hover:text-ink focus-visible:ring-2 focus-visible:ring-bordo ${
                    locale === l ? 'bg-surface text-ink shadow-sm' : 'bg-transparent text-muted'
                  }`}>
                  {LOCALE_LABEL[l]}
                </button>
              ))}
            </div>
            <a href="/login"
              className="hidden md:inline-flex items-center justify-center font-semibold text-[15px] px-5 py-[9px] rounded border border-line-2 bg-transparent text-ink hover:bg-parchment-2 transition-colors whitespace-nowrap">
              Kirish
            </a>
            <a href="/register"
              className="cta-primary hidden sm:inline-flex items-center justify-center font-semibold text-[15px] px-5 py-[9px] rounded-lg text-white whitespace-nowrap">
              Ro&apos;yxatdan o&apos;tish
            </a>
            {/* Til dropdown — mobilda header'da (bossa select chiqadi) */}
            <div className="relative md:hidden flex-none" data-notranslate>
              <button type="button" onClick={() => setLangOpen(v => !v)} aria-label="Til tanlash" aria-expanded={langOpen}
                className="flex items-center gap-1 px-2.5 py-2 rounded-lg border border-line-2 bg-surface text-ink text-[13px] font-semibold hover:border-bordo transition-colors cursor-pointer">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" className="text-bordo flex-none"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                {LOCALE_LABEL[locale]}
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className={`text-muted flex-none transition-transform ${langOpen ? 'rotate-180' : ''}`}><path d="M6 9l6 6 6-6"/></svg>
              </button>
              {langOpen && (
                <>
                  <div className="fixed inset-0 z-[60]" onClick={() => setLangOpen(false)} />
                  <div className="absolute right-0 mt-2 w-[180px] bg-surface border border-line rounded-xl shadow-xl z-[70] overflow-hidden py-1 anim-fade-up">
                    {LOCALES.map(l => (
                      <button key={l} type="button" onClick={() => { setLocale(l); setLangOpen(false); }}
                        className={`w-full text-left px-4 py-2.5 text-[14px] font-medium flex items-center justify-between gap-2 border-none cursor-pointer transition-colors ${locale === l ? 'bg-bordo-tint text-bordo' : 'bg-transparent text-ink hover:bg-parchment-2'}`}>
                        <span>{LOCALE_FULL[l]}</span>
                        {locale === l && <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="flex-none"><polyline points="20 6 9 17 4 12"/></svg>}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>

            <button onClick={() => setMobileOpen(true)} aria-label="Menyu"
              className="lg:hidden flex flex-col gap-[5px] p-2 cursor-pointer bg-transparent border-none flex-none">
              <span className="block w-5 h-[2px] bg-ink rounded" />
              <span className="block w-5 h-[2px] bg-ink rounded" />
              <span className="block w-5 h-[2px] bg-ink rounded" />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="fixed inset-0 z-[100] flex">
          <div className="absolute inset-0 bg-black/40" onClick={() => setMobileOpen(false)} />
          <div className="relative ml-auto w-[88vw] max-w-[300px] bg-surface h-full flex flex-col shadow-lg">
            <div className="flex items-center justify-between p-5 border-b border-line">
              <span className="font-serif font-semibold">Menyu</span>
              <button onClick={() => setMobileOpen(false)} className="text-2xl bg-transparent border-none cursor-pointer text-ink leading-none">&times;</button>
            </div>
            <nav className="flex flex-col gap-1 p-4">
              {navLinks.map(l => (
                <a key={l.href} href={l.href} onClick={() => setMobileOpen(false)}
                  className="text-[15px] font-medium text-ink-2 px-3 py-[10px] rounded hover:bg-parchment-2 transition-colors">
                  {l.label}
                </a>
              ))}
            </nav>
            <div className="p-4 mt-auto border-t border-line flex flex-col gap-2">
              <a href="/login" className="flex items-center justify-center font-semibold text-[15px] px-5 py-[11px] rounded border border-line-2 text-ink hover:bg-parchment-2 transition-colors">Kirish</a>
              <a href="/register" className="cta-primary flex items-center justify-center font-semibold text-[15px] px-5 py-[11px] rounded-lg text-white">Ro&apos;yxatdan o&apos;tish</a>
            </div>
          </div>
        </div>
      )}

      {/* Hero + Marquee wrapper — desktopda birinchi ekranni to'ldiradi; mobilda tabiiy balandlik */}
      <div className="flex flex-col lg:h-[calc(100vh-95px)]"
        onMouseEnter={() => setHeroPaused(true)} onMouseLeave={() => setHeroPaused(false)}
        onFocusCapture={() => setHeroPaused(true)} onBlurCapture={() => setHeroPaused(false)}>

      {/* Hero — diamond pattern + radial gradient */}
      <section
        className="pt-6 pb-10 lg:pt-4 lg:pb-20 overflow-hidden relative lg:flex-1 lg:min-h-0 flex items-start lg:items-center"
        style={{
          background: `radial-gradient(1100px 460px at 80% -10%, rgba(8,119,181,.10), transparent 60%), linear-gradient(180deg, #eef4fb, #dde9f6)`,
        }}
      >
        {/* Katak (diamond) fon naqshi */}
        <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: DIAMOND_PATTERN }} />
        <div className="max-w-wrap mx-auto px-6 grid lg:grid-cols-[1fr_1fr] gap-8 lg:gap-14 items-center relative z-10 w-full">
          <div className="text-center lg:text-left">
            <div className="hero-rise hero-rise-1 inline-flex items-center gap-2 text-bordo text-[11px] font-bold tracking-[.12em] uppercase mb-5 lg:bg-bordo-tint lg:px-3 lg:py-[5px] lg:rounded-full">
              <span className="w-[7px] h-[7px] rounded-full bg-bordo inline-block animate-pulse" />
              Ro&apos;yxatdan o&apos;tish ochiq
            </div>
            <h1 className="hero-rise hero-rise-2 font-serif text-[clamp(30px,8.5vw,54px)] lg:text-[clamp(26px,7vw,54px)] font-semibold leading-[1.18] lg:leading-[1.2] tracking-[-0.01em] mb-5 text-ink">
              Bilimingizni sinang, <span className="gold-anim">rasmiy sertifikat</span> qo&apos;lga kiriting
            </h1>
            <p className="hero-rise hero-rise-3 text-[15.5px] sm:text-[17px] text-ink-2 leading-[1.65] mb-7 lg:mb-8 max-w-[42ch] sm:max-w-[52ch] mx-auto lg:mx-0">
              Onlayn olimpiada — natijangiz <b className="text-ink">darhol</b> baholanadi, QR bilan tasdiqlangan rasmiy sertifikat, g&apos;oliblarga <b className="text-ink">qimmatbaho sovg&apos;alar</b> va institutga <b className="text-ink">imtihonsiz</b> yo&apos;llanma.
            </p>
            {/* Stats — mobilda 3 nafis karta, desktopda inline (count-up animatsiya bilan) */}
            <div className="hero-rise hero-rise-4 grid grid-cols-3 gap-2.5 mb-6 max-w-[360px] mx-auto lg:max-w-none lg:mx-0 lg:flex lg:gap-8 lg:mb-8">
              {[
                { to: 8, suffix: '', label: "Fan yo'nalishi", delay: 200 },
                { to: 4, suffix: '', label: 'Tilda mavjud', delay: 450 },
                { to: 100, suffix: '%', label: 'Onlayn va shaffof', delay: 700 },
              ].map((s, i) => (
                <div key={i} className="px-1 lg:p-0">
                  <AnimatedStat to={s.to} suffix={s.suffix} label={s.label} delay={s.delay} />
                </div>
              ))}
            </div>
            <div className="hero-rise hero-rise-4 flex flex-col sm:flex-row sm:flex-wrap gap-3 max-w-[360px] mx-auto lg:max-w-none lg:mx-0 sm:justify-center lg:justify-start">
              <a href="/register" className="shimmer cta-primary inline-flex items-center justify-center gap-2 font-semibold text-[16px] px-7 py-[14px] rounded-lg text-white w-full sm:w-auto">
                Olimpiadaga yozilish →
              </a>
              <a href="#about" className="inline-flex items-center justify-center gap-2 font-semibold text-[16px] px-6 py-[14px] rounded-lg border border-line-2 bg-transparent text-ink hover:bg-parchment-2 hover:border-bordo/30 transition-colors w-full sm:w-auto">
                Qanday ishlaydi?
              </a>
            </div>
          </div>

          {/* Hero carousel: Sertifikat → QR tekshiruv → Test interfeysi (auto-rotate 4.5s) */}
          <div className="float-soft relative flex flex-col items-center">
            {/* Slides container — 3D tilt */}
            <TiltCard className="relative w-full max-w-[480px]" style={{ height: 490 }}>

              {/* ─── SLIDE 1: SERTIFIKAT ────────────────────────────────────── */}
              <div className={`absolute inset-0 transition-opacity duration-500 flex items-center justify-center ${heroSlide === 0 ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>

            {/* Cert card — real PDF dizaynga mos: ikkita border, IO emblem, watermark, TASDIQLANGAN, microstrip */}
            <div className="relative w-full max-w-[460px]">
              {/* Outer bordo border + inner gold border */}
              <div className="rounded-lg shadow-xl p-[5px] h-[450px]" style={{ background: '#0b3b5a' }}>
                <div className="rounded p-[14px] relative overflow-hidden h-full flex flex-col justify-center"
                  style={{ background: '#f6f8fb', border: '1px solid #9a7b3f' }}>

                  {/* IO watermark (faded big background) */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
                    <span className="font-serif font-bold leading-none" style={{ fontSize: 220, letterSpacing: -10, color: 'rgba(8,119,181,0.05)' }}>IO</span>
                  </div>

                  {/* TASDIQLANGAN seal — top right */}
                  <div className="absolute top-2 right-2 w-[52px] h-[52px] flex items-center justify-center">
                    <svg width="52" height="52" viewBox="0 0 86 86">
                      <circle cx="43" cy="43" r="42" stroke="#0877B5" strokeWidth="0.6" fill="none" />
                      <circle cx="43" cy="43" r="36" stroke="#9a7b3f" strokeWidth="0.4" strokeDasharray="1 2" fill="none" />
                      <g opacity="0.35">
                        {Array.from({ length: 24 }).map((_, i) => {
                          const a = (i * 15) * (Math.PI / 180);
                          return <path key={i} d={`M${43+Math.cos(a)*28} ${43+Math.sin(a)*28} L${43+Math.cos(a)*36} ${43+Math.sin(a)*36}`} stroke="#9a7b3f" strokeWidth="0.3" />;
                        })}
                      </g>
                      <path d="M43 18 L57 23 L57 41 C57 50 51 56 43 60 C35 56 29 50 29 41 L29 23 Z"
                        fill="none" stroke="#0877B5" strokeWidth="1.6" strokeLinejoin="round" />
                      <path d="M36 40 L41 45 L50 35" fill="none" stroke="#0877B5" strokeWidth="2"
                        strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </div>

                  {/* Content */}
                  <div className="relative">
                    {/* IO Laurel emblem */}
                    <div className="flex justify-center pt-1">
                      <svg width="46" height="46" viewBox="0 0 100 100">
                        <circle cx="50" cy="50" r="46" stroke="#0b3b5a" strokeWidth="2.5" fill="none" />
                        <circle cx="50" cy="50" r="40" stroke="#9a7b3f" strokeWidth="1" strokeDasharray="1.5 3" fill="none" />
                        <path d="M30 76 C21 70 17 60 18 49" stroke="#9a7b3f" strokeWidth="2.2" strokeLinecap="round" fill="none" />
                        <path d="M70 76 C79 70 83 60 82 49" stroke="#9a7b3f" strokeWidth="2.2" strokeLinecap="round" fill="none" />
                        {[
                          [19, 68, -55], [21.4, 59, -47], [23.8, 50, -39], [26.2, 41, -31], [28.6, 32, -23],
                          [81, 68, 55], [78.6, 59, 47], [76.2, 50, 39], [73.8, 41, 31], [71.4, 32, 23],
                        ].map(([cx, cy, rot], i) => (
                          <ellipse key={i} cx={cx} cy={cy} rx="4.2" ry="2.1" fill="#9a7b3f" transform={`rotate(${rot} ${cx} ${cy})`} />
                        ))}
                        <path d="M50 12 L52.6 17.6 L58.7 18.3 L54.2 22.5 L55.4 28.5 L50 25.5 L44.6 28.5 L45.8 22.5 L41.3 18.3 L47.4 17.6 Z" fill="#9a7b3f" />
                        <path d="M27.5 38 H43.5 V42 H38.5 V62 H43.5 V66 H27.5 V62 H32.5 V42 H27.5 Z" fill="#0b3b5a" />
                        <path fillRule="evenodd" d="M46.5 52 a13 14 0 1 0 26 0 a13 14 0 1 0 -26 0 M52.5 52 a7 8 0 1 0 14 0 a7 8 0 1 0 -14 0" fill="#0b3b5a" />
                      </svg>
                    </div>

                    {/* Brand caption */}
                    <div className="text-center font-bold text-gold mt-2" style={{ fontSize: 8, letterSpacing: 4 }}>INTELLECT OLYMPIAD</div>

                    {/* SERTIFIKAT title */}
                    <div className="text-center font-serif font-bold text-bordo mt-1" style={{ fontSize: 28, letterSpacing: 3 }}>SERTIFIKAT</div>

                    {/* Subtitle */}
                    <div className="text-center text-ink-2 mt-1" style={{ fontSize: 9 }}>Ushbu sertifikat quyidagi shaxsga taqdim etiladi</div>

                    {/* Holder name */}
                    <div className="text-center font-serif font-bold text-ink mt-3" style={{ fontSize: 24 }}>{cHolder}</div>

                    {/* Gold underline */}
                    <div className="mx-auto my-2" style={{ width: 70, height: 2, background: '#0877B5' }} />

                    {/* Body */}
                    <div className="text-center text-ink-2 px-8" style={{ fontSize: 10, lineHeight: 1.5 }}>
                      2026-yil <b className="text-ink">{cSubject}</b> onlayn olimpiadasida{' '}
                      <b className="text-ink">{cScore} ball</b> to&apos;plab muvaffaqiyatli ishtirok etgani uchun beriladi.
                    </div>

                    {/* Bottom row: judge | QR | score */}
                    <div className="flex items-end justify-between mt-4 px-2">
                      {/* Judge sig */}
                      <div className="flex-1">
                        <div className="font-serif italic text-ink" style={{ fontSize: 14 }}>Agzamova X. M.</div>
                        <div style={{ width: 60, height: 0.6, background: '#6f7a89' }} className="my-1" />
                        <div className="text-muted" style={{ fontSize: 7, letterSpacing: 0.4 }}>Direktor · {cDate}</div>
                      </div>
                      {/* QR */}
                      <div className="w-[40px] h-[40px] bg-surface border p-[2px] flex-none" style={{ borderColor: '#9a7b3f' }}>
                        {cQr ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={cQr} alt="QR" className="w-full h-full object-contain" />
                        ) : (
                          <svg width="100%" height="100%" viewBox="0 0 56 56" shapeRendering="crispEdges">
                            <rect width="56" height="56" fill="white" />
                            {([[0,0],[0,1],[0,2],[0,3],[0,4],[0,5],[0,6],[1,0],[1,6],[2,0],[2,2],[2,3],[2,4],[2,6],[3,0],[3,2],[3,3],[3,4],[3,6],[4,0],[4,2],[4,3],[4,4],[4,6],[5,0],[5,6],[6,0],[6,1],[6,2],[6,3],[6,4],[6,5],[6,6]] as [number,number][]).map(([r,c],i) => (
                              <rect key={i} x={c*8} y={r*8} width="7" height="7" fill="#1b2129" />
                            ))}
                          </svg>
                        )}
                      </div>
                      {/* Score + code */}
                      <div className="flex-1 text-right">
                        <div>
                          <b className="font-serif font-bold text-ds-green leading-none" style={{ fontSize: 28 }}>{cScore}</b>
                          <span className="font-serif font-semibold text-muted" style={{ fontSize: 13 }}>/100</span>
                        </div>
                        <div className="font-mono text-muted" style={{ fontSize: 8, letterSpacing: 0.4 }}>{cCode}</div>
                      </div>
                    </div>

                    {/* Digital signature badge */}
                    <div className="flex justify-center items-center gap-3 mt-3">
                      <div className="flex items-center gap-[6px] rounded px-2 py-1"
                        style={{ background: '#e7edf3', border: '0.5px solid #c9b890' }}>
                        <span className="w-[5px] h-[5px] rounded-full" style={{ background: '#2e6b4f' }} />
                        <div>
                          <div className="font-bold text-muted" style={{ fontSize: 6, letterSpacing: 0.6 }}>RAQAMLI IMZO</div>
                          <div className="font-mono font-bold text-bordo leading-none" style={{ fontSize: 8.5, letterSpacing: 0.8 }}>{cSig}</div>
                        </div>
                      </div>
                    </div>

                    {/* Microstrip bottom */}
                    <div className="overflow-hidden mt-3" style={{ height: 8 }}>
                      <div className="whitespace-nowrap font-bold" style={{ fontSize: 5, letterSpacing: 1.4, color: '#c9b890' }}>
                        {'INTELLECT OLYMPIAD · RASMIY HUJJAT · TASDIQLANGAN · '.repeat(8)}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
              </div>{/* end slide 1 (sertifikat) */}

              {/* ─── SLIDE 2: QR TEKSHIRUV ──────────────────────────────────── */}
              <div className={`absolute inset-0 transition-opacity duration-500 flex items-center justify-center ${heroSlide === 1 ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
                <div className="w-full max-w-[460px]">
                <div className="bg-surface border border-line rounded-xl shadow-xl overflow-hidden h-[450px] flex flex-col">
                  {/* Verify header */}
                  <div className="px-6 pt-6 pb-4 border-b border-line">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-full bg-ds-green-tint text-ds-green flex items-center justify-center flex-none">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
                      </div>
                      <div>
                        <div className="font-mono text-[10px] tracking-[.18em] uppercase text-ds-green font-bold">Tasdiqlandi</div>
                        <div className="font-serif font-semibold text-[18px] text-ink leading-tight">Sertifikat haqiqiy</div>
                      </div>
                    </div>
                    <div className="font-mono text-[12px] text-muted bg-parchment-2 inline-block px-3 py-1 rounded">{cCode}</div>
                  </div>

                  {/* QR scanner area */}
                  <div className="px-6 py-6 flex items-center gap-5 flex-1">
                    <div className="w-[112px] h-[112px] rounded bg-parchment-2 border-2 border-gold p-3 flex-none relative">
                      {cQr ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={cQr} alt="Sertifikat QR" className="w-full h-full object-contain" />
                      ) : (
                        <svg width="100%" height="100%" viewBox="0 0 56 56" shapeRendering="crispEdges">
                          <rect width="56" height="56" fill="white" />
                          {([[0,0],[0,1],[0,2],[0,3],[0,4],[0,5],[0,6],[1,0],[1,6],[2,0],[2,2],[2,3],[2,4],[2,6],[3,0],[3,2],[3,3],[3,4],[3,6],[4,0],[4,2],[4,3],[4,4],[4,6],[5,0],[5,6],[6,0],[6,1],[6,2],[6,3],[6,4],[6,5],[6,6]] as [number,number][]).map(([r,c],i) => (
                            <rect key={i} x={c*8} y={r*8} width="7" height="7" fill="#1b2129" />
                          ))}
                        </svg>
                      )}
                      {/* Scanning line animation */}
                      {!cQr && <div className="absolute left-2 right-2 h-[2px] bg-bordo opacity-80 timer-pulse" style={{ top: '50%' }} />}
                    </div>
                    <div className="flex-1 space-y-3">
                      <div>
                        <div className="text-[11px] uppercase tracking-[.1em] text-muted font-semibold mb-[2px]">Sertifikat egasi</div>
                        <div className="font-serif font-semibold text-[16px] text-ink">{cHolder}</div>
                      </div>
                      <div>
                        <div className="text-[11px] uppercase tracking-[.1em] text-muted font-semibold mb-[2px]">Fan / Ball</div>
                        <div className="text-[13.5px] text-ink-2">{cSubject} · <b className="text-ds-green">{cScore}/100</b></div>
                      </div>
                      <div>
                        <div className="text-[11px] uppercase tracking-[.1em] text-muted font-semibold mb-[2px]">Berilgan sana</div>
                        <div className="text-[13.5px] text-ink-2 font-mono">{cDate}</div>
                      </div>
                    </div>
                  </div>

                  {/* Signature footer */}
                  <div className="px-6 py-3 bg-parchment-2 border-t border-line flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-[7px] h-[7px] rounded-full bg-ds-green" />
                      <span className="text-[10.5px] font-bold uppercase tracking-[.1em] text-muted">Raqamli imzo</span>
                    </div>
                    <span className="font-mono text-[11px] text-bordo font-semibold">{cSig}</span>
                  </div>
                </div>
                {/* Caption below */}
                <div className="text-center mt-3 text-[12px] text-muted">
                  QR yoki kod orqali <b className="text-ink">intellectolympiad.uz/tekshirish</b>
                </div>
                </div>
              </div>{/* end slide 2 (verify) */}

              {/* ─── SLIDE 3: TEST INTERFEYSI ───────────────────────────────── */}
              <div className={`absolute inset-0 transition-opacity duration-500 flex items-center justify-center ${heroSlide === 2 ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
                <div className="w-full max-w-[460px]">
                <div className="bg-surface border border-line rounded-xl shadow-xl overflow-hidden h-[450px] flex flex-col">
                  {/* Exam top bar with timer */}
                  <div className="px-5 py-3 bg-bordo-900 text-white flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                      <span className="font-mono font-bold text-[16px]">01:23:45</span>
                    </div>
                    <div className="text-[12px] text-[#9fbdd2]">Matematika · 12 / 45 savol</div>
                  </div>

                  {/* Progress bar */}
                  <div className="h-[3px] bg-parchment-2 relative">
                    <div className="absolute inset-y-0 left-0 bg-bordo rounded-r" style={{ width: '27%' }} />
                  </div>

                  {/* Question */}
                  <div className="px-6 py-5 flex-1 flex flex-col justify-center">
                    <div className="text-[11px] uppercase tracking-[.12em] text-muted font-bold mb-2">12-savol · 3 ball</div>
                    <div className="font-serif text-[17px] text-ink mb-5 leading-snug">
                      Kvadrat tenglama: x² − 5x + 6 = 0. Ildizlar yig&apos;indisi nechaga teng?
                    </div>

                    {/* Options */}
                    <div className="space-y-2">
                      {[
                        { l: 'A', t: '−5' },
                        { l: 'B', t: '5', selected: true },
                        { l: 'C', t: '6' },
                        { l: 'D', t: '−6' },
                      ].map(o => (
                        <div key={o.l} className={`flex items-center gap-3 px-4 py-[10px] rounded border transition-colors cursor-default ${
                          o.selected ? 'border-bordo bg-bordo-tint' : 'border-line bg-parchment-2 hover:bg-parchment'
                        }`}>
                          <span className={`w-7 h-7 rounded-full flex items-center justify-center font-semibold text-[13px] flex-none ${
                            o.selected ? 'bg-bordo text-white' : 'bg-surface text-muted border border-line'
                          }`}>{o.l}</span>
                          <span className="text-[14px] text-ink font-mono">{o.t}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Footer with nav */}
                  <div className="px-5 py-3 bg-parchment-2 border-t border-line flex items-center justify-between">
                    <div className="flex items-center gap-2 text-[11px] text-muted">
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z"/></svg>
                      Anti-cheat: faol
                    </div>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <span key={i} className={`w-[7px] h-[7px] rounded-full ${i < 2 ? 'bg-bordo' : i < 4 ? 'bg-bordo' : 'bg-line'}`} />
                      ))}
                    </div>
                  </div>
                </div>
                <div className="text-center mt-3 text-[12px] text-muted">
                  Server-side timer · <b className="text-ink">anti-cheat</b> bilan
                </div>
                </div>
              </div>{/* end slide 3 (exam) */}

            </TiltCard>{/* end slides container */}

            {/* Indicator dots */}
            <div className="flex items-center gap-2 mt-4">
              {(['Sertifikat', 'QR tekshiruv', 'Test'] as const).map((label, i) => (
                <button key={i} type="button" onClick={() => setHeroSlide(i)}
                  aria-label={`${label} slaydini ko‘rsatish`} aria-current={heroSlide === i ? 'true' : undefined}
                  className={`flex items-center gap-[6px] px-3 py-[6px] rounded-full transition-all border-none cursor-pointer text-[11.5px] font-semibold ${
                    heroSlide === i
                      ? 'bg-bordo text-white shadow-sm'
                      : 'bg-parchment-2 text-muted hover:text-ink'
                  }`}>
                  <span className={`w-[6px] h-[6px] rounded-full ${heroSlide === i ? 'bg-white' : 'bg-line-2'}`} />
                  {label}
                </button>
              ))}
            </div>

          </div>
        </div>
      </section>

      {/* Marquee — dark ink bg (gov topbar bilan bir xil, qizil kamroq) */}
      <div className="py-4 overflow-hidden flex-none" style={{ background: '#0a2a40' }}>
        <div className="flex whitespace-nowrap marquee-track">
          {[...SUBJECTS, ...SUBJECTS].map((s, i) => (
            <span key={i} className="inline-flex items-center gap-3 font-serif text-[17px] font-medium text-[rgba(255,255,255,.72)] px-[24px]">
              <span className="text-gold text-[9px]">◆</span>{s}
            </span>
          ))}
        </div>
      </div>

      </div>{/* /flex wrapper */}

      {/* Live olympiads — announced ahead of time, multiple, each with its own price + slots */}
      <section id="olimpiadalar" data-reveal className="py-12 sm:py-20 bg-parchment-2 scroll-mt-20">
        <div className="max-w-wrap mx-auto px-6">
          <div className="text-center mb-12">
            <div className="text-[11px] tracking-[.14em] uppercase text-muted font-bold mb-3">Ochiq olimpiadalar</div>
            <h2 className="font-serif text-3xl font-semibold">E&apos;lon qilingan olimpiadalar</h2>
            <p className="text-muted text-[15px] mt-3">Sizga mos olimpiadani tanlang — joylar cheklangan, kechikmang</p>
          </div>

          {olysLoading ? (
            <LoadingRow />
          ) : olys.length === 0 ? (
            <div className="text-center text-muted text-[15px] py-12 bg-surface border border-line rounded-xl">
              Hozircha e&apos;lon qilingan olimpiada yo&apos;q. Tez orada qaytib keling.
            </div>
          ) : (() => {
            const visibleOlys = showAllOlys ? olys : olys.slice(0, 6);
            const n = visibleOlys.length;
            return (
            <>
            <div
              className={n === 1
                ? 'grid grid-cols-1 max-w-[440px] mx-auto'
                : 'grid grid-cols-2 md:grid-cols-3 gap-3 sm:gap-5 mx-auto max-w-[1120px]'}
            >
              {visibleOlys.map(o => {
                const meta = OLYMPIAD_STATUS_META[o.status] ?? { label: o.status, cls: 'bg-parchment-2 text-muted border border-line-2' };
                const full = o.slotsLeft != null && o.slotsLeft <= 0;
                return (
                  <a key={o.id} href={`/olimpiada/${o.id}`} className="group bg-surface border border-line rounded-2xl p-3.5 sm:p-6 shadow-sm hover:shadow-lg hover:-translate-y-[2px] hover:border-gold/50 transition-all duration-200 flex flex-col">
                    {/* Badge'lar qatori */}
                    <div className="flex items-center gap-1 sm:gap-1.5 mb-2.5 flex-wrap">
                      <span className={`inline-flex text-[9.5px] sm:text-[11px] font-bold px-1.5 sm:px-2 py-[3px] rounded-full whitespace-nowrap ${meta.cls}`}>{meta.label}</span>
                    </div>
                    <h3 className="font-serif text-[15px] sm:text-[19px] font-semibold leading-tight text-ink group-hover:text-bordo transition-colors mb-3 line-clamp-2">{o.title}</h3>

                    {/* Batafsil — faqat sm+ da (mobilda ixcham) */}
                    <div className="hidden sm:block">
                      {o.description && (
                        <p className="text-[14px] text-ink-2 leading-relaxed line-clamp-2 mb-3">{o.description}</p>
                      )}
                      {o.audience && (
                        <div className="flex items-start gap-1.5 mb-4 text-[12.5px] text-ink-2">
                          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className="text-bordo flex-none mt-[1px]"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                          <span><b className="text-ink">Kimlar uchun:</b> {o.audience}</span>
                        </div>
                      )}
                      <div className="grid grid-cols-2 gap-y-3 gap-x-4 text-[13px] mb-5">
                        <div><span className="text-muted block">Boshlanish</span><span className="font-semibold text-ink">{fmtUzDateTime(o.startsAt)}</span></div>
                        <div><span className="text-muted block">Davomiyligi</span><span className="font-semibold text-ink">{o.durationMin} daqiqa</span></div>
                        <div><span className="text-muted block">Fanlar</span><span className="font-semibold text-ink">{o.subjects?.length ?? 0} ta</span></div>
                        <div><span className="text-muted block">Joylar</span><span className="font-semibold text-ink">{o.totalSlots == null ? 'Cheksiz' : `${o.slotsLeft ?? o.totalSlots} ta qoldi`}</span></div>
                      </div>
                    </div>

                    {/* Mobil: joylar qatori (ixcham) */}
                    <div className={`sm:hidden flex items-center gap-1.5 text-[11.5px] mb-3 ${full ? 'text-ds-red font-semibold' : 'text-muted'}`}>
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="flex-none"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
                      {full ? 'Joylar to\'lgan' : (o.totalSlots == null ? 'Cheksiz joy' : `${o.slotsLeft ?? o.totalSlots} ta joy qoldi`)}
                    </div>

                    <div className="mt-auto pt-3 sm:pt-4 border-t border-line flex items-center justify-between gap-2">
                      <div className="leading-none">
                        <span className="font-serif text-[18px] sm:text-[22px] font-bold text-bordo">{fmtUzPrice(o.priceUzs)}</span>
                        <span className="text-[11px] sm:text-[13px] text-muted"> so&apos;m</span>
                      </div>
                      <span className="inline-flex items-center gap-1 font-semibold text-[12.5px] sm:text-[14px] text-bordo whitespace-nowrap">
                        Batafsil
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="flex-none transition-transform group-hover:translate-x-0.5"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
                      </span>
                    </div>
                  </a>
                );
              })}
            </div>
            {olys.length > 6 && (
              <div className="text-center mt-10">
                <button
                  onClick={() => setShowAllOlys(v => !v)}
                  className="inline-flex items-center gap-2 font-semibold text-[14px] px-6 py-[11px] rounded-full border border-bordo text-bordo hover:bg-bordo hover:text-white transition-colors"
                >
                  {showAllOlys ? 'Kamroq ko‘rsatish' : `Barchasi (${olys.length})`}
                  <span className={showAllOlys ? 'rotate-180 transition-transform' : 'transition-transform'}>↓</span>
                </button>
              </div>
            )}
            </>
            );
          })()}
        </div>
      </section>

      {/* Quick services — key functions surfaced from the footer */}
      <section id="xizmatlar" className="py-10 sm:py-16 bg-parchment border-t border-line">
        <div className="max-w-wrap mx-auto px-6">
          <div className="text-center max-w-[640px] mx-auto mb-10" data-reveal>
            <div className="text-[11px] tracking-[.14em] uppercase text-muted font-bold mb-3">Xizmatlar</div>
            <h2 className="font-serif text-[clamp(24px,3.4vw,34px)] font-semibold mb-3">Barcha imkoniyatlar — bir joyda</h2>
            <p className="text-[15px] text-ink-2 leading-relaxed">
              Sertifikat tekshirishdan ustozlar dasturigacha — platformaning asosiy xizmatlariga to&apos;g&apos;ridan-to&apos;g&apos;ri shu yerdan kiring.
            </p>
          </div>
          {/* Bento grid — keng (featured) va kichik kartalar bir-birini to'ldiradi */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4" data-reveal>
            {SERVICES.map((s, idx) => {
              const wide = idx === 0 || idx === 5;       // 1- va 6-karta keng (col-span-2)
              const featured = idx === 0;                // 1-karta bordo featured
              return (
                <a key={s.href} href={s.href}
                  className={`group rounded-2xl transition-all duration-200 hover:-translate-y-[3px] overflow-hidden ${wide ? 'col-span-2' : 'col-span-1'} ${
                    featured
                      ? 'p-5 sm:p-7 text-white shadow-md hover:shadow-xl flex flex-row items-center gap-4 sm:gap-6 relative'
                      : `bg-surface border border-line shadow-sm hover:shadow-md hover:border-gold/60 p-5 ${wide ? 'flex flex-row items-center gap-4' : 'flex flex-col'}`
                  }`}
                  style={featured ? { background: 'linear-gradient(135deg, #0877B5 0%, #0b3b5a 100%)' } : undefined}>
                  {featured && <div className="absolute inset-0 pointer-events-none opacity-[0.5]" style={{ backgroundImage: DIAMOND_PATTERN_WHITE }} />}
                  <div className={`rounded-xl flex items-center justify-center flex-none relative ${
                    featured ? 'w-14 h-14 sm:w-16 sm:h-16 bg-white/15 text-white' : `${wide ? 'w-12 h-12' : 'w-12 h-12 mb-4'} bg-bordo-tint text-bordo group-hover:bg-bordo group-hover:text-white transition-colors`
                  }`}>
                    <s.Icon />
                  </div>
                  <div className={`relative ${wide ? 'flex-1 min-w-0' : 'flex flex-col flex-1'}`}>
                    <div className={`font-serif text-[15.5px] sm:text-[18px] font-semibold mb-1 ${featured ? 'text-white' : ''}`}>{s.t}</div>
                    <p className={`text-[11.5px] sm:text-[13.5px] leading-snug sm:leading-relaxed ${featured ? 'text-white/80' : 'text-ink-2'} ${wide ? '' : 'flex-1'}`}>{s.d}</p>
                    <span className={`mt-3 inline-flex items-center gap-1.5 font-semibold text-[13px] group-hover:gap-2.5 transition-all ${featured ? 'text-gold-tint' : 'text-bordo'}`}>
                      {s.cta}
                      <span aria-hidden>→</span>
                    </span>
                  </div>
                </a>
              );
            })}
          </div>
        </div>
      </section>

      {/* Steps */}
      <section id="about" data-reveal className="py-12 sm:py-20 scroll-mt-24">
        <div className="max-w-wrap mx-auto px-6">
          <div className="text-center mb-12">
            <div className="text-[11px] tracking-[.14em] uppercase text-muted font-bold mb-3">Qanday ishlaydi</div>
            <h2 className="font-serif text-3xl font-semibold">4 qadamda olimpiadaga ishtirok eting</h2>
          </div>
          {/* Mobilda timeline (bog'langan chiziq), desktopda 4-ustun */}
          <div className="flex flex-col lg:grid lg:grid-cols-4 lg:gap-0 max-w-[560px] lg:max-w-none mx-auto">
            {STEPS.map((s, i) => (
              <div key={i} className={`relative flex gap-4 lg:block lg:gap-0 lg:px-7 ${i < STEPS.length - 1 ? 'pb-8 lg:pb-0 lg:border-r border-line' : ''}`}>
                {i < STEPS.length - 1 && <span className="lg:hidden absolute left-[25px] top-[56px] bottom-0 w-[2px] bg-line" aria-hidden />}
                <div className="w-[50px] h-[50px] lg:w-[52px] lg:h-[52px] rounded-full border-[1.5px] border-bordo text-bordo flex items-center justify-center font-serif text-[20px] lg:text-[22px] font-bold bg-bordo-tint flex-none relative z-10 lg:mb-5">
                  {s.n}
                </div>
                <div className="pt-1.5 lg:pt-0">
                  <h3 className="font-serif text-[17px] lg:text-[18px] font-semibold mb-1.5 lg:mb-2">{s.t}</h3>
                  <p className="text-[13.5px] lg:text-[14.5px] text-ink-2 leading-relaxed">{s.d}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Jonli reyting — ijtimoiy isbot + gamifikatsiya (yuqorida) */}
      <LandingRatings />

      {/* Sovrinlar — mukofotlar */}
      <section id="sovrinlar" data-reveal className="py-12 sm:py-20 bg-parchment scroll-mt-24">
        <div className="max-w-wrap mx-auto px-6">
          <div className="text-center mb-12">
            <div className="text-[11px] tracking-[.14em] uppercase text-muted font-bold mb-3">Sovrinlar</div>
            <h2 className="font-serif text-3xl font-semibold">G&apos;oliblar uchun mukofotlar</h2>
            <p className="text-muted text-[15px] mt-3 max-w-[560px] mx-auto">Eng yuqori natijaga erishganlar rasmiy sertifikat, pul mukofoti va qimmatbaho sovrinlar bilan taqdirlanadi.</p>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-5 max-w-[1000px] mx-auto items-stretch">
            {REWARDS.map((r, i) => (
              <div key={i} className="bg-surface border border-line rounded-2xl p-3 sm:p-6 shadow-sm hover:shadow-md hover:border-gold/50 transition-all text-center flex flex-col items-center">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center mb-3.5 bg-bordo-tint text-bordo flex-none">
                  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">{r.icon}</svg>
                </div>
                <h3 className="font-serif text-[15.5px] sm:text-[17px] font-semibold mb-1.5 leading-tight">{r.title}</h3>
                <p className="text-[11.5px] sm:text-[13px] text-ink-2 leading-snug sm:leading-relaxed">{r.desc}</p>
              </div>
            ))}
          </div>
          <p className="text-center text-[13.5px] text-muted mt-8 max-w-[680px] mx-auto">Har bir ishtirokchi rasmiy <b className="text-ink-2">QR-kodli sertifikat</b> oladi. Aniq sovrinlar va mukofot jamg&apos;armasi har olimpiada uchun alohida e&apos;lon qilinadi.</p>
        </div>
      </section>

      {/* Universitetga imtihonsiz yo'l — alohida bo'lim */}
      <section data-reveal className="py-12 sm:py-20 text-white relative overflow-hidden" style={{ background: '#0b3b5a' }}>
        <div className="max-w-wrap mx-auto px-6 relative">
          <div className="text-center max-w-[660px] mx-auto mb-12">
            <div className="inline-flex items-center gap-3 text-[11px] tracking-[.2em] uppercase text-gold font-bold mb-4">
              <span className="w-8 h-px bg-bordo/40" /> Imtiyoz <span className="w-8 h-px bg-bordo/40" />
            </div>
            <h2 className="font-serif text-[clamp(28px,3.8vw,42px)] font-semibold leading-[1.12]">Sovg&apos;alar va institutga yo&apos;llanma</h2>
            <p className="text-[16.5px] text-white/80 mt-4 leading-relaxed">
              Ro&apos;yxatdan o&apos;ting va olimpiadada qatnashing — g&apos;oliblar <b className="text-white">qimmatbaho sovg&apos;alar</b> bilan taqdirlanadi hamda hamkor institut/universitetlarga <b className="text-white">imtihonsiz yo&apos;llanma</b> qo&apos;lga kiritadi.
            </p>
          </div>

          <div className="flex flex-col md:flex-row md:items-stretch justify-center gap-3 md:gap-4 max-w-[960px] mx-auto">
            {[
              { step: 'Ro\'yxat', title: 'Ro\'yxatdan o\'tish', desc: 'Bir necha daqiqada ro\'yxatdan o\'tib, olimpiadaga yoziling.', icon: <><rect x="2" y="3" width="20" height="14" rx="2" /><path d="M8 21h8M12 17v4" /></> },
              { step: 'Test', title: 'Onlayn test', desc: 'Belgilangan vaqtda vaqt cheklangan testni topshiring va ball to\'plang.', icon: <path d="M3 21h18M5 21V7l8-4 8 4v14M9 9h.01M13 9h.01M9 13h.01M13 13h.01M9 17h.01M13 17h.01" /> },
              { step: "G'olib", title: 'Sovg\'a va yo\'llanma', desc: 'G\'oliblar qimmatbaho sovg\'alar va hamkor institutlarga imtihonsiz yo\'llanma qo\'lga kiritadi.', icon: <><path d="M22 10 12 5 2 10l10 5 10-5z" /><path d="M6 12v5c0 1 2.7 2.5 6 2.5s6-1.5 6-2.5v-5" /><path d="M22 10v6" /></> },
            ].map((s, i) => (
              <div key={i} className="flex-1 flex items-center md:flex-col md:text-center gap-4 md:gap-0 bg-white/[.06] border border-white/[.12] rounded-2xl p-6 backdrop-blur-sm relative">
                <div className="w-14 h-14 md:mx-auto md:mb-4 rounded-full bg-bordo/15 border border-gold/40 flex items-center justify-center flex-none">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#9a7b3f" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{s.icon}</svg>
                </div>
                <div>
                  <div className="text-gold font-bold text-[11px] uppercase tracking-[.1em]">{s.step}</div>
                  <h3 className="font-serif text-[19px] font-semibold mt-[2px]">{s.title}</h3>
                  <p className="text-[13.5px] text-white/70 mt-2 leading-relaxed">{s.desc}</p>
                </div>
                {i < 2 && (
                  <svg className="hidden md:block absolute -right-[18px] top-1/2 -translate-y-1/2 z-10" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#9a7b3f" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 6l6 6-6 6" /></svg>
                )}
              </div>
            ))}
          </div>

          {partners.length > 0 ? (
            <div className="mt-12">
              <p className="text-center text-[12px] tracking-[.16em] uppercase text-gold/80 font-bold mb-6">Hamkor universitetlar</p>
              <div className="flex flex-wrap items-center justify-center gap-3 max-w-[960px] mx-auto">
                {partners.map((p) => {
                  const inner = (
                    <span className="inline-flex items-center gap-2.5 bg-white/[.07] border border-white/[.14] rounded-xl px-5 py-3 hover:bg-white/[.12] transition-colors">
                      {p.logoUrl ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={p.logoUrl} alt={p.name} className="h-7 w-auto object-contain" />
                      ) : null}
                      <span className="font-serif text-[14.5px] font-semibold text-white/90">{p.name}</span>
                    </span>
                  );
                  return p.website
                    ? <a key={p.id} href={p.website} target="_blank" rel="noreferrer">{inner}</a>
                    : <span key={p.id}>{inner}</span>;
                })}
              </div>
            </div>
          ) : (
            <p className="text-center text-[13.5px] text-white/55 mt-8">Hamkor universitetlar ro&apos;yxati va imtiyoz shartlari har olimpiada uchun alohida e&apos;lon qilinadi.</p>
          )}
        </div>
      </section>

      {/* Yangiliklar — so'nggi xabarlar */}
      {latestNews.length > 0 && (
        <section id="yangiliklar" data-reveal className="py-10 sm:py-16 bg-parchment-2 scroll-mt-24">
          <div className="max-w-wrap mx-auto px-6">
            <div className="flex items-end justify-between gap-4 mb-8 flex-wrap">
              <div>
                <div className="text-[11px] tracking-[.14em] uppercase text-muted font-bold mb-2">Xabarlar</div>
                <h2 className="font-serif text-[clamp(24px,3.4vw,34px)] font-semibold">So&apos;nggi yangiliklar</h2>
              </div>
              <a href="/news" className="inline-flex items-center gap-2 font-semibold text-[14px] px-5 py-[10px] rounded-full border border-bordo text-bordo hover:bg-bordo hover:text-white transition-colors">
                Barchasini ko&apos;rish
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
              </a>
            </div>
            {/* Mobilda yonma-yon swipe (scroll), sm+ da grid */}
            <div className="flex sm:grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 overflow-x-auto sm:overflow-visible snap-x snap-mandatory no-scrollbar -mx-6 px-6 sm:mx-0 sm:px-0 pb-1 sm:pb-0">
              {latestNews.map(n => {
                const badge = NEWS_BADGE[n.category] ?? NEWS_BADGE.NEWS;
                return (
                  <a key={n.id} href={`/news/${n.slug}`} className="group bg-surface border border-line rounded-xl overflow-hidden shadow-sm hover:shadow-md hover:border-gold/60 sm:hover:-translate-y-[3px] transition-all duration-200 flex flex-col shrink-0 w-[265px] sm:w-auto snap-start">
                    <div className="aspect-[16/9] overflow-hidden relative">
                      {n.imageUrl ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={n.imageUrl} alt={n.title} className="absolute inset-0 w-full h-full object-cover group-hover:scale-[1.04] transition-transform duration-300" />
                      ) : (
                        <div className="absolute inset-0 flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #e3f1f9 0%, #c8e4f3 100%)' }}>
                          <svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" className="text-bordo/35"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                        </div>
                      )}
                      <span className={`absolute top-2.5 left-2.5 text-[10.5px] font-bold px-2 py-[3px] rounded shadow-sm ${badge.c}`}>{badge.l}</span>
                    </div>
                    <div className="p-4 flex flex-col flex-1">
                      <span className="text-[11.5px] text-muted mb-1.5">{fmtNewsDate(n.publishedAt ?? n.createdAt)}</span>
                      <h3 className="font-serif text-[15.5px] sm:text-[16.5px] font-semibold text-ink leading-snug line-clamp-2 group-hover:text-bordo transition-colors">{n.title}</h3>
                      {n.summary && <p className="text-[12.5px] sm:text-[13px] text-ink-2 leading-relaxed line-clamp-2 mt-1">{n.summary}</p>}
                    </div>
                  </a>
                );
              })}
            </div>
            {/* Mobil: swipe maslahati */}
            <div className="sm:hidden flex items-center gap-1.5 text-[11.5px] text-muted mt-3">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
              Yonga suring
            </div>
          </div>
        </section>
      )}

      {/* Features */}
      <section data-reveal className="py-12 sm:py-20 bg-parchment-2">
        <div className="max-w-wrap mx-auto px-6">
          <div className="text-center mb-12">
            <div className="text-[11px] tracking-[.14em] uppercase text-muted font-bold mb-3">Afzalliklar</div>
            <h2 className="font-serif text-3xl font-semibold">Nima uchun Intellect Olympiad?</h2>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-[22px]">
            {FEATS.map(({ Icon, t, d }, i) => (
              <div key={i} className="bg-surface border border-line rounded-xl p-3.5 sm:p-7 shadow-sm hover:shadow hover:border-gold/50 transition-all">
                <div className="w-11 h-11 sm:w-[46px] sm:h-[46px] rounded-[10px] bg-bordo-tint text-bordo flex items-center justify-center mb-3 sm:mb-5">
                  <Icon />
                </div>
                <h3 className="font-serif text-[15px] sm:text-[18.5px] font-semibold mb-1.5 sm:mb-2 leading-tight">{t}</h3>
                <p className="text-[11.5px] sm:text-[14.5px] text-ink-2 leading-snug sm:leading-relaxed">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Eligibility */}
      <section className="py-12 sm:py-20">
        <div className="max-w-wrap mx-auto px-6">
          <div className="text-center mb-8 sm:mb-12">
            <div className="text-[11px] tracking-[.14em] uppercase text-muted font-bold mb-3">Ishtirokchilar</div>
            <h2 className="font-serif text-3xl font-semibold">Kim ishtirok eta oladi?</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-[18px] max-w-[920px] mx-auto">
            {[
              { Icon: IconBookOpen, title: "Maktab o'quvchilari", desc: "O'zbekistoning istalgan maktabida o'qiyotgan o'quvchilar." },
              { Icon: IconBuilding, title: 'Litseylar va kollejlar', desc: "Akademik litseylar va kasb-hunar kollejlari talabalari." },
              { Icon: IconGlobe2, title: "Chet eldagi vatandoshlar", desc: "Xorijda yashayotgan o'zbek o'quvchilari ham ishtirok eta oladi." },
            ].map(({ Icon, title, desc }, i) => (
              <div key={i} className="bg-surface border border-line rounded-xl p-4 sm:p-6 shadow-sm hover:border-gold/50 transition-colors flex items-center gap-4 text-left sm:flex-col sm:text-center sm:gap-0">
                <div className="w-12 h-12 sm:w-[50px] sm:h-[50px] rounded-[12px] bg-bordo-tint text-bordo flex items-center justify-center flex-none sm:mx-auto sm:mb-4">
                  <Icon />
                </div>
                <div className="min-w-0">
                  <h3 className="font-serif text-[15.5px] sm:text-[17px] font-semibold mb-0.5 sm:mb-2 leading-tight">{title}</h3>
                  <p className="text-[12.5px] sm:text-[14px] text-ink-2 leading-relaxed">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Partnership — 2-column card */}
      <section className="py-10 sm:py-16 bg-parchment-2">
        <div className="max-w-wrap mx-auto px-6">
          <div className="grid lg:grid-cols-[1.1fr_1fr] rounded-lg overflow-hidden border border-line bg-surface shadow-sm">
            {/* Info side — hamkor jalb qilish */}
            <div className="p-6 sm:p-[40px_42px]">
              <div className="text-[11px] tracking-[.14em] uppercase text-muted font-bold mb-3">Hamkorlik</div>
              <h2 className="font-serif text-[26px] sm:text-[28px] font-semibold mb-3">Biz bilan hamkor bo&apos;ling</h2>
              <p className="text-[15px] text-ink-2 leading-relaxed max-w-full sm:max-w-[44ch]">
                Iqtidorli yoshlarni qo&apos;llab-quvvatlang va brendingizni minglab o&apos;quvchi, ota-ona va ustozga tanishtiring. Universitetlar, kompaniyalar, homiylar va ta&apos;lim muassasalari uchun ochiq.
              </p>
              <ul className="flex flex-col gap-3 mt-6 mb-7">
                {[
                  "Iqtidorli o'quvchilar va g'oliblar bazasiga kirish",
                  "Brendingiz — sertifikat, sahifa va tadbirlarda",
                  "Sovrin va maxsus nominatsiyalar homiyligi",
                  "Ta'limga hissa va ijtimoiy mas'uliyat (CSR)",
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-[11px] text-[14.5px] text-ink-2">
                    <IconCheck size={19} cls="text-ds-green flex-none mt-[1px]" />{item}
                  </li>
                ))}
              </ul>
              <a href="/contact" className="inline-flex items-center gap-2 font-semibold text-[15px] px-6 py-[13px] rounded bg-bordo text-white hover:bg-bordo-700 transition-colors">
                Hamkor bo&apos;lish
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
              </a>
            </div>
            {/* Bordo side — kim hamkor bo'la oladi */}
            <div
              className="p-6 sm:p-[40px_38px] flex flex-col justify-center relative overflow-hidden"
              style={{ background: '#0877B5' }}
            >
              <div className="relative">
                <h3 className="text-white font-serif text-[21px] font-semibold">Kim hamkor bo&apos;la oladi?</h3>
                <p className="text-white/85 text-[14px] mt-[10px] mb-[22px]">
                  Turli yo&apos;nalishdagi tashkilotlar uchun
                </p>
                <div className="flex flex-col gap-2.5">
                  {[
                    { t: 'Universitetlar', d: "G'oliblarni imtihonsiz qabul qiling, kelajak talabalarni erta toping." },
                    { t: 'Kompaniyalar va homiylar', d: "Sovrinlar va maxsus nominatsiyalar homiysi bo'ling." },
                    { t: 'Maktab va litseylar', d: "O'quvchilaringizni jamoaviy ulang va reytingda ko'rining." },
                    { t: 'OAV va ta\'lim loyihalari', d: 'Axborot va kontent hamkorligi.' },
                  ].map((s, i) => (
                    <div key={i} className="flex items-start gap-3 bg-white/[.07] border border-white/15 rounded-lg p-3">
                      <span className="w-2 h-2 rounded-full bg-bordo flex-none mt-[7px]" />
                      <div>
                        <div className="font-semibold text-[14px] text-white">{s.t}</div>
                        <div className="text-[12.5px] text-white/70 mt-[2px] leading-relaxed">{s.d}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ — ko'p so'raladigan savollar */}
      <section id="faq" data-reveal className="py-12 sm:py-20 bg-parchment-2 scroll-mt-24">
        <div className="max-w-[800px] mx-auto px-6">
          <div className="text-center mb-10">
            <div className="text-[11px] tracking-[.14em] uppercase text-muted font-bold mb-3">Yordam</div>
            <h2 className="font-serif text-[clamp(24px,3.4vw,34px)] font-semibold">Ko&apos;p so&apos;raladigan savollar</h2>
            <p className="text-[15px] text-ink-2 mt-2">Eng ko&apos;p beriladigan savollarga javoblar — bir joyda.</p>
          </div>
          <div className="flex flex-col gap-3">
            {FAQS.map((f, i) => {
              const open = openFaq === i;
              return (
                <div key={i} className="bg-surface border border-line rounded-xl overflow-hidden shadow-sm">
                  <button
                    type="button"
                    onClick={() => setOpenFaq(open ? null : i)}
                    className="w-full flex items-center justify-between gap-4 text-left px-5 py-4 cursor-pointer"
                  >
                    <span className="font-semibold text-[15px] text-ink">{f.q}</span>
                    <span className={`flex-none w-7 h-7 rounded-full bg-bordo-tint text-bordo flex items-center justify-center transition-transform duration-200 ${open ? 'rotate-45' : ''}`}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    </span>
                  </button>
                  <div className="grid transition-all duration-200" style={{ gridTemplateRows: open ? '1fr' : '0fr' }}>
                    <div className="overflow-hidden">
                      <p className="px-5 pb-4 text-[14px] text-ink-2 leading-relaxed">{f.a}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="text-center mt-8 text-[14px] text-ink-2">
            Savolingizga javob topmadingizmi?{' '}
            <a href="/contact" className="font-semibold text-bordo hover:underline">Biz bilan bog&apos;laning →</a>
          </div>
        </div>
      </section>

      {/* CTA band — diamond pattern */}
      <section
        data-reveal
        className="py-12 sm:py-20 text-white text-center relative overflow-hidden"
        style={{ background: '#0877B5' }}
      >
        <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: DIAMOND_PATTERN_WHITE }} />
        <div className="max-w-wrap mx-auto px-6 relative">
          <div className="text-[11px] tracking-[.14em] uppercase text-[#9db3c6] font-bold mb-4">Navbat sizniki</div>
          <h2 className="font-serif text-[clamp(28px,4vw,40px)] font-semibold mb-4 text-white">Kelajagingiz bugundan boshlanadi</h2>
          <p className="text-[17px] text-[rgba(255,255,255,.85)] mb-7 max-w-[54ch] mx-auto">
            Bilimingizni isbotlang, rasmiy sertifikat va universitetga yo&apos;lni qo&apos;lga kiriting. Joylar cheklangan — bugun ro&apos;yxatdan o&apos;ting.
          </p>
          <a href="/register" className="inline-flex items-center gap-2 font-semibold text-[16px] px-7 py-[14px] rounded bg-white text-bordo hover:bg-bordo-tint transition-colors">
            Hoziroq ro&apos;yxatdan o&apos;tish →
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-bordo-900 text-[#cfdde8]">
        <div className="max-w-wrap mx-auto px-6 py-10 sm:py-11 grid grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_auto] gap-x-6 sm:gap-x-10 gap-y-8">
          {/* Brend (+ mobilda guvohnoma tepa-o'ngda, matn bilan to'g'risida) */}
          <div className="col-span-2 lg:col-span-1 flex justify-between gap-4 lg:block">
            <div className="min-w-0">
              <div className="flex items-center gap-3 mb-4">
                <img src="/logo-mark-light.svg" alt="Intellect Olympiad" className="w-11 h-11 flex-none" />
                <div className="flex flex-col leading-[1.05]">
                  <b className="font-serif font-semibold text-base text-white">Intellect Olympiad</b>
                  <small className="text-[10.5px] tracking-[.14em] uppercase text-[#9db3c6] font-semibold">Onlayn Olimpiada</small>
                </div>
              </div>
              <p className="text-[12px] sm:text-[13px] text-[#9db3c6] leading-relaxed mb-3">
                &laquo;SIFAT TA&apos;LIM XIZMATI&raquo; MChJ tomonidan tashkil etilgan rasmiy onlayn olimpiada platformasi.
              </p>
              <div className="text-[12px] sm:text-[12.5px] text-[#b6c7d6] leading-relaxed space-y-1">
                <div>Toshkent sh., Uchtepa t., Degrez MFY, Beshqayrag&apos;och ko&apos;chasi, 12A-uy</div>
                <div>+998 90 036 21 21 · +998 90 068 44 20</div>
              </div>
            </div>
            {/* Guvohnoma — mobilda tepa-o'ngda (matn bilan bir tomonda) */}
            <a href="/litsenziya.pdf" target="_blank" rel="noreferrer" className="group lg:hidden flex flex-col items-center gap-1.5 w-[104px] flex-none self-start" title="Guvohnomani ochish">
              <span className="block w-full rounded-lg overflow-hidden border border-white/15 bg-white shadow-md group-hover:border-gold transition-colors">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src="/litsenziya.png?v=2" alt="Davlat ro'yxatidan o'tganlik guvohnomasi" className="w-full block" />
              </span>
              <span className="text-[11.5px] text-[#b6c7d6] group-hover:text-white transition-colors">Guvohnoma</span>
            </a>
          </div>
          {[
            { title: 'Platforma', links: [['Olimpiadalar', '#olimpiadalar'], ['Reyting', '#reyting'], ['Yangiliklar', '/news'], ["Bog'lanish", '/contact']] },
            { title: 'Hisobim', links: [["Ro'yxatdan o'tish", '/register'], ['Kirish', '/login'], ['Shaxsiy kabinet', '/cabinet'], ['Sertifikat tekshirish', '/verify']] },
          ].map((col, i) => (
            <div key={i}>
              <div className="text-[11px] tracking-[.14em] uppercase text-[#9db3c6] font-bold mb-4">{col.title}</div>
              <ul className="space-y-2">
                {col.links.map(([l, h], li) => (
                  <li key={li}><a href={h} className="text-[13px] text-[#b6c7d6] hover:text-white transition-colors">{l}</a></li>
                ))}
              </ul>
            </div>
          ))}
          {/* Guvohnoma — desktopda 4-ustun (o'ng) */}
          <a href="/litsenziya.pdf" target="_blank" rel="noreferrer" className="group hidden lg:flex flex-col items-center gap-1.5 w-[124px] flex-none justify-self-end" title="Guvohnomani ochish">
            <span className="block w-full rounded-lg overflow-hidden border border-white/15 bg-white shadow-md group-hover:border-gold transition-colors">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/litsenziya.png?v=2" alt="Davlat ro'yxatidan o'tganlik guvohnomasi" className="w-full block" />
            </span>
            <span className="text-[11.5px] text-[#b6c7d6] group-hover:text-white transition-colors">Guvohnoma</span>
          </a>
        </div>
        <div className="border-t border-white/10 py-5">
          <div className="max-w-wrap mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-[12px] text-[#6f8497]">
            <span>© 2026 Intellect Olympiad. Barcha huquqlar himoyalangan.</span>
            <div className="flex items-center gap-4">
              <a href="#faq" className="hover:text-white transition-colors">Savol-javob</a>
              <a href="/privacy" className="hover:text-white transition-colors">Maxfiylik</a>
              <a href="/terms" className="hover:text-white transition-colors">Shartlar</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
