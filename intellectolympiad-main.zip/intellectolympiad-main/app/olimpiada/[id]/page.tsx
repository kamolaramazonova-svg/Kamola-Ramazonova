'use client';
import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { olympiads as olympiadApi, content as contentApi, type Olympiad, type AssignedJudge, type OlympiadStats } from '@/lib/api';
import { getToken } from '@/lib/auth';
import { LoadingRow } from '@/components/Spinner';
import { useLocale, LOCALES, LOCALE_LABEL, LOCALE_FULL, fmtDate } from '@/lib/locale';

const STATUS_META: Record<string, { label: string; cls: string }> = {
  UPCOMING: { label: 'Tez kunda', cls: 'bg-ds-amber-tint text-ds-amber border border-ds-amber/30' },
  ACTIVE: { label: 'Faol', cls: 'bg-ds-green-tint text-ds-green border border-ds-green/30' },
  FINISHED: { label: 'Yakunlangan', cls: 'bg-parchment-2 text-muted border border-line-2' },
};

const fmtDateTime = (s: string) => fmtDate(s, { time: true });
const fmtPrice = (n: number) => new Intl.NumberFormat('uz-UZ').format(n);

function StatCard({ value, label, accent }: { value: number; label: string; accent?: 'bordo' | 'green' | 'gold' }) {
  const col = accent === 'green' ? 'text-ds-green' : accent === 'gold' ? 'text-gold' : 'text-bordo';
  return (
    <div className="bg-surface border border-line rounded-xl px-4 py-5 shadow-sm text-center">
      <div className={`font-serif text-[30px] font-bold leading-none ${col}`} style={{ fontVariantNumeric: 'tabular-nums' }}>{new Intl.NumberFormat('uz-UZ').format(value)}</div>
      <div className="text-[12.5px] text-muted font-medium mt-1.5">{label}</div>
    </div>
  );
}

export default function OlympiadDetailPage() {
  const params = useParams<{ id: string }>();
  const id = params?.id as string;
  const [locale, setLocale] = useLocale();
  const [oly, setOly] = useState<Olympiad | null>(null);
  const [judges, setJudges] = useState<AssignedJudge[]>([]);
  const [stats, setStats] = useState<OlympiadStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!id) return;
    let alive = true;
    setLoading(true);
    Promise.all([
      olympiadApi.byId(id),
      contentApi.olympiadJudges(id).catch(() => [] as AssignedJudge[]),
      olympiadApi.stats(id).catch(() => null),
    ])
      .then(([o, j, s]) => { if (!alive) return; setOly(o); setJudges(j); setStats(s); })
      .catch(() => { if (alive) setError('Olimpiada topilmadi yoki yuklab bo\'lmadi'); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
  }, [id, locale]);

  const reserveHref = oly ? (getToken() ? `/cabinet?olympiad=${oly.id}` : `/login?next=${encodeURIComponent(`/cabinet?olympiad=${oly.id}`)}`) : '#';
  const full = oly?.slotsLeft != null && oly.slotsLeft <= 0;
  const meta = oly ? (STATUS_META[oly.status] ?? { label: oly.status, cls: 'bg-parchment-2 text-muted border border-line-2' }) : null;
  const maxRegion = stats?.byRegion?.length ? Math.max(...stats.byRegion.map(r => r.count)) : 0;

  return (
    <div className="min-h-screen bg-parchment">
      {/* Header */}
      <header className="bg-surface border-b border-line sticky top-0 z-20">
        <div className="max-w-wrap mx-auto px-4 sm:px-6 flex items-center gap-3 min-h-[60px]">
          <a href="/" className="flex items-center gap-2 sm:gap-3 flex-none">
            <img src="/logo-mark.svg" alt="Intellect Olympiad" className="w-9 h-9 flex-none" />
            <b className="font-serif font-semibold text-[15px] text-ink hidden sm:inline">Intellect Olympiad</b>
          </a>
          <a href="/#olimpiadalar" className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-ink-2 bg-surface border border-line-2 rounded-lg px-3 py-2 hover:border-bordo hover:text-bordo transition-colors flex-none">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="flex-none"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>
            <span className="hidden sm:inline">Olimpiadalar</span>
          </a>
          <div className="ml-auto flex items-center gap-[2px] bg-parchment-2 border border-line rounded p-[3px] flex-none">
            {LOCALES.map(l => (
              <button key={l} type="button" title={LOCALE_FULL[l]} aria-label={`Til: ${LOCALE_FULL[l]}`} onClick={() => setLocale(l)}
                className={`text-[11px] font-semibold px-[7px] py-[3px] rounded-sm cursor-pointer border-none transition-colors ${locale === l ? 'bg-surface text-ink shadow-sm' : 'bg-transparent text-muted hover:text-ink'}`}>
                {LOCALE_LABEL[l]}
              </button>
            ))}
          </div>
        </div>
      </header>

      {loading ? (
        <div className="max-w-wrap mx-auto px-6 py-24"><LoadingRow /></div>
      ) : error || !oly ? (
        <div className="max-w-wrap mx-auto px-6 py-24 text-center">
          <div className="font-serif text-2xl font-semibold mb-2">Xatolik</div>
          <p className="text-muted mb-6">{error || 'Olimpiada topilmadi'}</p>
          <a href="/#olimpiadalar" className="inline-flex font-semibold text-[15px] px-6 py-[11px] rounded bg-bordo text-white hover:bg-bordo-700 transition-colors">Olimpiadalarga qaytish</a>
        </div>
      ) : (
        <>
          {/* Hero — olimpiada asosiy ma'lumoti */}
          <section className="py-8 sm:py-12 border-b border-line" style={{ background: 'radial-gradient(900px 360px at 85% -20%, rgba(8,119,181,.07), transparent 60%), linear-gradient(180deg,#f2f5f8,#e7edf3)' }}>
            <div className="max-w-wrap mx-auto px-6 grid lg:grid-cols-[1fr_320px] gap-8 items-start">
              <div>
                <div className="flex items-center gap-2 flex-wrap mb-3">
                  {meta && <span className={`text-[11px] font-bold px-[10px] py-[4px] rounded-full ${meta.cls}`}>{meta.label}</span>}
                  <span className="text-[12px] text-muted">{oly.year}-yil</span>
                </div>
                <h1 className="font-serif text-[clamp(26px,5vw,40px)] font-semibold leading-[1.15] text-ink mb-3">{oly.title}</h1>
                {oly.description && <p className="text-[15px] sm:text-[16px] text-ink-2 leading-relaxed max-w-[60ch] mb-5">{oly.description}</p>}
                {oly.audience && (
                  <div className="flex items-start gap-2 text-[14px] text-ink-2 mb-5">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className="text-bordo flex-none mt-[2px]"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    <span><b className="text-ink">Kimlar uchun:</b> {oly.audience}</span>
                  </div>
                )}

                {/* Key facts */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-6 gap-y-4 bg-surface/60 border border-line rounded-xl p-5 max-w-[640px]">
                  {[
                    ['Boshlanish', fmtDateTime(oly.startsAt)],
                    ['Davomiyligi', `${oly.durationMin} daqiqa`],
                    ['Fanlar', `${oly.subjects?.length ?? 0} ta`],
                    ['Maksimal ball', `${oly.maxScore}`],
                    ['O\'tish balli', `${oly.passScore}`],
                    ['Joylar', oly.totalSlots == null ? 'Cheksiz' : `${oly.slotsLeft ?? oly.totalSlots} ta qoldi`],
                  ].map(([k, v]) => (
                    <div key={k}>
                      <div className="text-[12px] text-muted mb-[2px]">{k}</div>
                      <div className="font-semibold text-ink text-[14px]">{v}</div>
                    </div>
                  ))}
                </div>

                {/* Subjects */}
                {oly.subjects?.length > 0 && (
                  <div className="mt-5 flex flex-wrap gap-2">
                    {oly.subjects.map(s => (
                      <span key={s.id} className="text-[13px] font-medium px-3 py-1.5 rounded-full bg-bordo-tint text-bordo">{s.subject?.name}</span>
                    ))}
                  </div>
                )}

              </div>

              {/* Reserve card */}
              <div className="bg-surface border border-line rounded-2xl shadow-md p-6 lg:sticky lg:top-[76px]">
                <div className="text-[12px] text-muted mb-1">Ishtirok narxi</div>
                <div className="mb-4">
                  <span className="font-serif text-[34px] font-bold text-bordo">{fmtPrice(oly.priceUzs)}</span>
                  <span className="text-[15px] text-muted"> so&apos;m</span>
                </div>
                {full ? (
                  <span className="block text-center font-semibold text-[15px] px-5 py-[13px] rounded-lg bg-parchment-2 text-muted border border-line-2 cursor-not-allowed">Joylar to&apos;lgan</span>
                ) : (
                  <a href={reserveHref} className="shimmer block text-center font-semibold text-[15px] px-5 py-[13px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors">
                    Band qilish →
                  </a>
                )}
                <div className="text-[12px] text-muted mt-3 leading-relaxed text-center">To&apos;lov tasdiqlangach joyingiz band qilinadi.</div>
                <div className="border-t border-line mt-5 pt-4 space-y-2 text-[13px]">
                  <div className="flex items-center justify-between"><span className="text-muted">Holati</span><span className="font-semibold text-ink">{meta?.label}</span></div>
                  {stats && <div className="flex items-center justify-between"><span className="text-muted">Ishtirokchilar</span><span className="font-semibold text-ink">{new Intl.NumberFormat('uz-UZ').format(stats.totalRegistrations)}</span></div>}
                </div>
              </div>
            </div>
          </section>

          {/* Hakamlar — shu olimpiadaga biriktirilgan */}
          <section className="py-10 sm:py-14 bg-parchment-2">
            <div className="max-w-wrap mx-auto px-6">
              <div className="text-[11px] tracking-[.14em] uppercase text-muted font-bold mb-2">Hakamlar hay&apos;ati</div>
              <h2 className="font-serif text-[clamp(22px,3vw,30px)] font-semibold mb-7">Ushbu olimpiada hakamlari</h2>
              {judges.length === 0 ? (
                <div className="text-muted text-[14.5px] bg-surface border border-line rounded-xl px-5 py-8 text-center">Hakamlar hali tayinlanmagan.</div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                  {judges.map(j => (
                    <div key={j.id} className="bg-surface border border-line rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow flex flex-col items-center text-center">
                      <div className="w-16 h-16 rounded-full overflow-hidden bg-bordo flex items-center justify-center text-white font-serif font-bold text-[19px] flex-none mb-3 border-2 border-gold/40">
                        {j.avatarUrl ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={j.avatarUrl} alt={`${j.firstName} ${j.lastName}`} className="w-full h-full object-cover" />
                        ) : j.initials}
                      </div>
                      <div className="font-serif font-semibold text-[15.5px] text-ink leading-tight">{j.firstName} {j.lastName}</div>
                      {j.title && <div className="text-[12.5px] text-bordo font-medium mt-0.5">{j.title}</div>}
                      {j.institution && <div className="text-[12px] text-muted mt-1 leading-snug">{j.institution}</div>}
                      {j.subject && <span className="mt-2 text-[11px] font-semibold px-2 py-[3px] rounded-full bg-gold-tint text-[#7a5a25]">{j.subject}</span>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>

          {/* Statistika — viloyatlar + ishtirok */}
          <section className="py-10 sm:py-14">
            <div className="max-w-wrap mx-auto px-6">
              <div className="text-[11px] tracking-[.14em] uppercase text-muted font-bold mb-2">Statistika</div>
              <h2 className="font-serif text-[clamp(22px,3vw,30px)] font-semibold mb-7">Ishtirok ko&apos;rsatkichlari</h2>

              {stats && stats.totalRegistrations > 0 ? (
                <>
                  <div className="grid grid-cols-3 gap-3 sm:gap-4 max-w-[640px] mb-9">
                    <StatCard value={stats.totalRegistrations} label="Ro'yxatdan o'tgan" accent="bordo" />
                    <StatCard value={stats.confirmedCount} label="Joy band qilgan" accent="green" />
                    <StatCard value={stats.examTaken} label="Test topshirgan" accent="gold" />
                  </div>

                  {stats.byRegion.length > 0 && (
                    <div className="bg-surface border border-line rounded-2xl p-5 sm:p-7 max-w-[760px]">
                      <h3 className="font-serif text-[18px] font-semibold mb-1">Viloyatlar bo&apos;yicha</h3>
                      <p className="text-[13px] text-muted mb-5">Qaysi hududdan qancha ishtirokchi ro&apos;yxatdan o&apos;tgani</p>
                      <div className="space-y-3">
                        {stats.byRegion.map(r => (
                          <div key={r.region} className="flex items-center gap-3">
                            <div className="w-[120px] sm:w-[150px] text-[13.5px] text-ink font-medium flex-none truncate">{r.region}</div>
                            <div className="flex-1 h-[22px] rounded-full bg-parchment-2 overflow-hidden relative">
                              <div className="h-full rounded-full bg-gradient-to-r from-bordo to-[#066291] transition-all" style={{ width: `${maxRegion ? Math.max(8, (r.count / maxRegion) * 100) : 0}%` }} />
                            </div>
                            <div className="w-[42px] text-right font-semibold text-[14px] text-ink flex-none" style={{ fontVariantNumeric: 'tabular-nums' }}>{r.count}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              ) : (
                <div className="text-muted text-[14.5px] bg-surface border border-line rounded-xl px-5 py-8 text-center max-w-[640px]">Hali ishtirokchilar yo&apos;q — birinchi bo&apos;lib ro&apos;yxatdan o&apos;ting!</div>
              )}
            </div>
          </section>

          {/* CTA */}
          <section className="py-12 text-center text-white" style={{ background: '#0b3b5a' }}>
            <div className="max-w-wrap mx-auto px-6">
              <h2 className="font-serif text-[clamp(22px,3.5vw,32px)] font-semibold mb-3">Ishtirok etishga tayyormisiz?</h2>
              <p className="text-[15px] text-[#cfdde8] mb-6 max-w-[520px] mx-auto">Joyingizni band qiling va bilimingizni sinab ko&apos;ring.</p>
              {!full && (
                <a href={reserveHref} className="inline-flex font-semibold text-[15px] px-7 py-[13px] rounded-lg bg-white text-bordo hover:bg-parchment-2 transition-colors">Band qilish →</a>
              )}
            </div>
          </section>
        </>
      )}
    </div>
  );
}
