'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { payments, olympiads as olympiadApi, results as resultsApi, certificates as certApi, ratings as ratingsApi, gamification as gamApi, users as usersApi, userMe, auth as authApi, notificationsApi, BASE as API_BASE, type Olympiad, type Payment, type MyResultRow, type MyCertificate, type MyRank, type Gamification, type NotificationItem } from '@/lib/api';
import { getToken, getUser, clearSession, saveSession } from '@/lib/auth';
import { useLocale, LOCALES, LOCALE_LABEL, LOCALE_FULL, fmtDate } from '@/lib/locale';
import DashboardStats from '@/components/DashboardStats';
import { Spinner } from '@/components/Spinner';
import TeacherPanel from '@/components/TeacherPanel';

type CabinetTab = 'dashboard' | 'olimpiadalar' | 'tolov' | 'natijalar' | 'sertifikatlar' | 'ustoz';
type PayStatus = 'none' | 'pending' | 'uploaded' | 'confirmed' | 'rejected';

const Ic = {
  Grid: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></svg>,
  Check: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>,
  Award: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="8" r="6"/><path d="M9 13l-1 8 4-2 4 2-1-8"/></svg>,
  CreditCard: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>,
  Chart: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 3v18h18"/><path d="M7 14l4-4 3 3 5-6"/></svg>,
  QR: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>,
  Door: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg>,
  Clock: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>,
  Upload: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>,
  Copy: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>,
  CheckSmall: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>,
  Hourglass: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M5 22h14"/><path d="M5 2h14"/><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"/><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"/></svg>,
  CheckCircle: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>,
  Alert: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>,
  Back: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>,
  Users: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>,
  Home: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M9 21v-6h6v6"/></svg>,
  Trophy: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M6 4h12v4a6 6 0 0 1-12 0z"/><path d="M6 6H3v1a3 3 0 0 0 3 3M18 6h3v1a3 3 0 0 1-3 3"/><path d="M9 18h6M10 14v4M14 14v4M8 21h8"/></svg>,
  ArrowRight: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>,
  Bell: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>,
};

const NOTIF_ICON: Record<string, React.ReactNode> = {
  payment: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>,
  result: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 3v18h18"/><path d="M7 14l4-4 3 3 5-6"/></svg>,
  certificate: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="8" r="6"/><path d="M9 13l-1 8 4-2 4 2-1-8"/></svg>,
  exam: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>,
  info: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>,
};
function fmtAgo(s: string) {
  const diff = Date.now() - new Date(s).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'hozir';
  if (m < 60) return `${m} daq oldin`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} soat oldin`;
  return `${Math.floor(h / 24)} kun oldin`;
}

const NAV: { id: CabinetTab; label: string; icon: React.ReactNode }[] = [
  { id: 'dashboard',    label: 'Bosh sahifa',     icon: Ic.Home },
  { id: 'olimpiadalar', label: 'Olimpiadalar',  icon: Ic.Grid },
  { id: 'tolov',        label: "To'lov",         icon: Ic.CreditCard },
  { id: 'natijalar',    label: 'Natijalarim',     icon: Ic.Chart },
  { id: 'sertifikatlar',label: 'Sertifikatlarim', icon: Ic.Award },
];

// To'lov rekvizitlari — "SIFAT TA'LIM XIZMATI" MChJ
const PAY_ORG = '"SIFAT TA’LIM XIZMATI" MChJ';
const PAY_ACCOUNT = '20208000605616986001';
const PAY_BANK = 'ASIA ALLIANCE BANK ATB, Toshkent';
const PAY_MFO = '01095';
const PAY_STIR = '310241724';

const STATUS: Record<PayStatus, { label: string; cls: string; dot: string }> = {
  none:      { label: "To'lanmagan",     cls: 'bg-parchment-2 text-muted border border-line-2', dot: 'bg-muted' },
  pending:   { label: "To'lov kutilmoqda", cls: 'bg-ds-amber-tint text-ds-amber', dot: 'bg-ds-amber' },
  uploaded:  { label: 'Tekshirilmoqda',  cls: 'bg-ds-info-tint text-ds-info', dot: 'bg-ds-info' },
  confirmed: { label: 'Tasdiqlangan',    cls: 'bg-ds-green-tint text-ds-green', dot: 'bg-ds-green' },
  rejected:  { label: 'Rad etilgan',     cls: 'bg-ds-red-tint text-ds-red', dot: 'bg-ds-red' },
};

function pad(n: number) { return String(n).padStart(2, '0'); }
function fmtPrice(n: number) { return new Intl.NumberFormat('uz-UZ').format(n); }
// Sana — joriy tilga mos (kabinet useLocale ishlatadi, til o'zgarsa qayta render bo'ladi).
const fmtDateTime = (s: string) => fmtDate(s, { time: true });

export default function CabinetPage() {
  const router = useRouter();
  const currentUser = getUser();
  const isTeacher = currentUser?.role === 'TEACHER';
  const [tab, setTab] = useState<CabinetTab>(isTeacher ? 'ustoz' : 'dashboard');
  // Hydration: server'da localStorage yo'q (getUser=null), shuning uchun rolga bog'liq
  // UI faqat client mount bo'lgach chiziladi — aks holda server/client mos kelmaydi.
  const [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);
  const [locale, setLocale] = useLocale();
  const [moreOpen, setMoreOpen] = useState(false); // mobil "Barchasi" pastki menyu

  // Teachers see a dedicated referral nav; students get the olympiad flow.
  const navItems = isTeacher
    ? [
        { id: 'ustoz' as CabinetTab, label: 'Ustozlar dasturi', icon: Ic.Users },
        { id: 'sertifikatlar' as CabinetTab, label: 'Sertifikatlarim', icon: Ic.Award },
      ]
    : NAV;

  const [olys, setOlys] = useState<Olympiad[]>([]);
  const [olysLoading, setOlysLoading] = useState(true);
  // payments keyed by olympiadId
  const [payByOly, setPayByOly] = useState<Record<string, Payment>>({});

  const [olyFilter, setOlyFilter] = useState<'all' | 'open' | 'pending' | 'joined' | 'participated'>('all');
  const [gam, setGam] = useState<Gamification | null>(null);
  const [inviteCopied, setInviteCopied] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [profileForm, setProfileForm] = useState({ firstName: '', lastName: '', phone: '', region: '', school: '' });
  const [profileSaving, setProfileSaving] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(currentUser?.avatarUrl ?? null);
  const [avatarBusy, setAvatarBusy] = useState(false);
  const [pwForm, setPwForm] = useState({ current: '', next: '' });
  const [pwBusy, setPwBusy] = useState(false);
  const [pwMsg, setPwMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [tgLinked, setTgLinked] = useState<boolean>(!!currentUser?.telegramId);
  const [tgBusy, setTgBusy] = useState(false);
  const [tgHint, setTgHint] = useState(false); // "Botda /start bosing" ko'rsatmasi
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const [notifs, setNotifs] = useState<NotificationItem[]>([]);
  const [notifUnread, setNotifUnread] = useState(0);
  const [notifOpen, setNotifOpen] = useState(false);
  const [myResults, setMyResults] = useState<MyResultRow[]>([]);
  const [myCerts, setMyCerts] = useState<MyCertificate[]>([]);
  const [myRank, setMyRank] = useState<MyRank | null>(null);
  const [resultsLoaded, setResultsLoaded] = useState(false);
  const [certsLoaded, setCertsLoaded] = useState(false);

  // Active payment flow target
  const [selected, setSelected] = useState<Olympiad | null>(null);
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [copied, setCopied] = useState(false);
  // To'lov usuli yo'riqnomasi: mobil ilova (default — eng ko'p ishlatiladi) yoki bank kassasi
  const [payMethod, setPayMethod] = useState<'mobile' | 'bank'>('mobile');
  const [payLoading, setPayLoading] = useState(false);
  const [payError, setPayError] = useState('');
  const [cd, setCd] = useState({ d: 0, h: 0, m: 0, s: 0 });
  const fileRef = useRef<HTMLInputElement>(null);

  const statusOf = useCallback((olyId: string): PayStatus => {
    const p = payByOly[olyId];
    if (!p) return 'none';
    if (p.status === 'CONFIRMED') return 'confirmed';
    if (p.status === 'FAILED') return 'rejected';
    return p.receiptUrl ? 'uploaded' : 'pending';
  }, [payByOly]);

  const refreshPayments = useCallback(() => {
    const token = getToken();
    if (!token) return;
    payments.myPayments(token).then(ps => {
      const map: Record<string, Payment> = {};
      ps.forEach(p => { const id = p.registration?.olympiad?.id; if (id) map[id] = p; });
      setPayByOly(map);
    }).catch(() => {});
  }, []);

  // Load olympiads + payments
  useEffect(() => {
    const token = getToken();
    if (!token) { router.push('/login'); return; }
    olympiadApi.list().then(raw => {
      const list = [...raw].sort((a, b) => new Date(a.examStart).getTime() - new Date(b.examStart).getTime());
      setOlys(list);
      const preId = new URLSearchParams(window.location.search).get('olympiad');
      const match = preId ? list.find(o => o.id === preId) : null;
      if (match) { setSelected(match); setTab('tolov'); }
    }).catch(() => {}).finally(() => setOlysLoading(false));
    refreshPayments();
    resultsApi.my(token).then(r => setMyResults(r)).catch(() => {}).finally(() => setResultsLoaded(true));
    certApi.my(token).then(c => setMyCerts(c)).catch(() => {}).finally(() => setCertsLoaded(true));
    ratingsApi.me(token).then(setMyRank).catch(() => {});
    gamApi.me(token).then(setGam).catch(() => {});
    notificationsApi.list(token).then(r => { setNotifs(r.items); setNotifUnread(r.unread); }).catch(() => {});
  }, [router, refreshPayments]);

  // Til o'zgarganda olimpiada nomlarini qayta yuklaymiz (x-locale sarlavhasi yangi tilni yuboradi)
  const localeInit = useRef(true);
  useEffect(() => {
    if (localeInit.current) { localeInit.current = false; return; }
    olympiadApi.list().then(raw => {
      setOlys([...raw].sort((a, b) => new Date(a.examStart).getTime() - new Date(b.examStart).getTime()));
    }).catch(() => {});
  }, [locale]);

  const toggleNotif = () => {
    const opening = !notifOpen;
    setNotifOpen(opening);
    if (opening && notifUnread > 0) {
      const token = getToken();
      if (token) notificationsApi.readAll(token).catch(() => {});
      setNotifUnread(0);
      setNotifs(prev => prev.map(n => ({ ...n, isRead: true })));
    }
  };
  const onNotifClick = (n: NotificationItem) => {
    setNotifOpen(false);
    if (n.link?.startsWith('/')) router.push(n.link);
  };

  const copyInvite = () => {
    if (!gam?.inviteUrl) return;
    navigator.clipboard?.writeText(gam.inviteUrl).then(() => {
      setInviteCopied(true);
      setTimeout(() => setInviteCopied(false), 1800);
    }).catch(() => {});
  };

  const openProfile = () => {
    setProfileForm({
      firstName: currentUser?.firstName ?? '',
      lastName: currentUser?.lastName ?? '',
      phone: currentUser?.phone ?? '',
      region: currentUser?.region ?? '',
      school: currentUser?.school ?? '',
    });
    setProfileOpen(true);
  };
  const saveProfile = async () => {
    const token = getToken(); if (!token) return;
    setProfileSaving(true);
    try {
      const updated = await usersApi.updateProfile(token, {
        firstName: profileForm.firstName.trim(),
        lastName: profileForm.lastName.trim(),
        phone: profileForm.phone.trim() || undefined,
        region: profileForm.region.trim() || undefined,
        school: profileForm.school.trim() || undefined,
      });
      saveSession(token, { ...updated, avatarUrl });   // localStorage'dagi userni yangilaymiz
      setProfileOpen(false);
      router.refresh();
    } catch (err: unknown) {
      alert(err instanceof Error ? err.message : 'Saqlashda xatolik');
    } finally { setProfileSaving(false); }
  };

  const uploadAvatar = async (file: File) => {
    const token = getToken(); if (!token) return;
    setAvatarBusy(true);
    try {
      const updated = await usersApi.uploadAvatar(token, file);
      setAvatarUrl(updated.avatarUrl);
      saveSession(token, updated);
    } catch (err: unknown) {
      alert(err instanceof Error ? err.message : 'Avatar yuklash xatosi');
    } finally { setAvatarBusy(false); }
  };

  const changePassword = async () => {
    const token = getToken(); if (!token) return;
    if (!pwForm.current || !pwForm.next) { setPwMsg({ ok: false, text: 'Ikkala maydonni to\'ldiring' }); return; }
    setPwBusy(true); setPwMsg(null);
    try {
      await usersApi.changePassword(token, pwForm.current, pwForm.next);
      setPwForm({ current: '', next: '' });
      setPwMsg({ ok: true, text: 'Parol o\'zgartirildi' });
    } catch (err: unknown) {
      setPwMsg({ ok: false, text: err instanceof Error ? err.message : 'Xatolik' });
    } finally { setPwBusy(false); }
  };

  // ── Telegram bog'lash ──────────────────────────────────────────────────────
  // Ulanish tokenini olib botni ochamiz; foydalanuvchi /start bosgach chatId
  // bog'lanadi va natija/sertifikat/yangilik xabarlari Telegram'ga keladi.
  const connectTelegram = async () => {
    const token = getToken(); if (!token) return;
    setTgBusy(true);
    try {
      const { deepLink } = await userMe.getTelegramLinkToken(token);
      window.open(deepLink, '_blank', 'noopener');
      setTgHint(true); // botda /start bosishni eslatamiz + "tekshirish" tugmasi
    } catch (err: unknown) {
      alert(err instanceof Error ? err.message : 'Havola olishda xatolik');
    } finally { setTgBusy(false); }
  };

  const refreshTgStatus = async () => {
    const token = getToken(); if (!token) return;
    setTgBusy(true);
    try {
      const me = await authApi.me(token);
      setTgLinked(!!me.telegramId);
      if (me.telegramId) { setTgHint(false); saveSession(token, me); }
    } catch { /* jim */ } finally { setTgBusy(false); }
  };

  const disconnectTelegramFn = async () => {
    const token = getToken(); if (!token) return;
    setTgBusy(true);
    try {
      await userMe.disconnectTelegram(token);
      setTgLinked(false); setTgHint(false);
    } catch (err: unknown) {
      alert(err instanceof Error ? err.message : 'Uzishda xatolik');
    } finally { setTgBusy(false); }
  };

  // Poll while any payment is pending/uploaded
  useEffect(() => {
    const waiting = Object.values(payByOly).some(p => p.status === 'PENDING');
    if (!waiting) return;
    const id = setInterval(refreshPayments, 20000);
    window.addEventListener('focus', refreshPayments);
    return () => { clearInterval(id); window.removeEventListener('focus', refreshPayments); };
  }, [payByOly, refreshPayments]);

  // Countdown to the selected olympiad
  useEffect(() => {
    const target = selected ? new Date(selected.examStart).getTime() : 0;
    const tick = () => {
      if (!target) { setCd({ d: 0, h: 0, m: 0, s: 0 }); return; }
      let diff = Math.max(0, Math.floor((target - Date.now()) / 1000));
      const d = Math.floor(diff / 86400); diff -= d * 86400;
      const h = Math.floor(diff / 3600); diff -= h * 3600;
      const m = Math.floor(diff / 60); const s = diff - m * 60;
      setCd({ d, h, m, s });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [selected]);

  const openOlympiad = (o: Olympiad) => {
    setSelected(o);
    setReceiptFile(null);
    setPayError('');
    setTab('tolov');
  };

  const requestPaymentCode = async () => {
    if (!selected) return;
    const token = getToken();
    if (!token) { router.push('/login'); return; }
    setPayLoading(true); setPayError('');
    try {
      await payments.create(token, selected.id, selected.price);
      refreshPayments();
    } catch (err: unknown) {
      setPayError(err instanceof Error ? err.message : "Xatolik yuz berdi");
    } finally { setPayLoading(false); }
  };

  // Click orqali to'lash — payment yaratadi va my.click.uz sahifasiga yo'naltiradi.
  const payClick = async () => {
    if (!selected) return;
    const token = getToken();
    if (!token) { router.push('/login'); return; }
    setPayLoading(true); setPayError('');
    try {
      const { url } = await payments.clickStart(token, selected.id, selected.price);
      window.location.href = url; // Click to'lov sahifasi
    } catch (err: unknown) {
      setPayError(err instanceof Error ? err.message : "Click to'lovini boshlab bo'lmadi");
      setPayLoading(false);
    }
  };

  const submitReceipt = async () => {
    const p = selected ? payByOly[selected.id] : null;
    if (!receiptFile || !p) return;
    const token = getToken();
    if (!token) { router.push('/login'); return; }
    setPayLoading(true); setPayError('');
    try {
      await payments.uploadReceiptFile(token, p.id, receiptFile);
      setReceiptFile(null);
      refreshPayments();
    } catch (err: unknown) {
      setPayError(err instanceof Error ? err.message : "Yuklash amalga oshmadi");
    } finally { setPayLoading(false); }
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleLogout = () => { clearSession(); router.push('/login'); };

  const userInitials = currentUser ? `${currentUser.firstName[0] ?? ''}${currentUser.lastName[0] ?? ''}` : 'IO';
  const userName = currentUser ? `${currentUser.firstName} ${currentUser.lastName}` : 'Foydalanuvchi';

  // counts for summary
  const paidCount = Object.values(payByOly).filter(p => p.status === 'CONFIRMED').length;
  const pendingCount = Object.values(payByOly).filter(p => p.status === 'PENDING').length;
  const selPayment = selected ? payByOly[selected.id] : null;
  const selStatus: PayStatus = selected ? statusOf(selected.id) : 'none';

  // Olympiads the student actually sat (has any exam session)
  const participatedSet = new Set(myResults.map(r => r.olympiadId));
  // Ro'yxatda faqat kelayotgan/faol olimpiadalar; o'tib ketganlar (FINISHED/CANCELLED)
  // ko'rinmaydi — qatnashganlari "Qatnashganlarim" (arxiv) tabida saqlanadi.
  const liveOlys = olys.filter(o => o.status === 'UPCOMING' || o.status === 'ACTIVE');
  const matchesFilter = (olyId: string): boolean => {
    if (olyFilter === 'all') return true;
    const st = statusOf(olyId);
    if (olyFilter === 'open') return st === 'none' || st === 'rejected';
    if (olyFilter === 'pending') return st === 'pending' || st === 'uploaded';
    if (olyFilter === 'joined') return st === 'confirmed';
    return true;
  };
  const filteredOlys = olyFilter === 'participated'
    ? olys.filter(o => participatedSet.has(o.id))            // arxiv — o'tganlar ham
    : liveOlys.filter(o => matchesFilter(o.id));             // faqat kelayotgan/faol

  // ── Dashboard hisob-kitoblari ──────────────────────────────────────────────
  const finishedCount = myResults.filter(r => r.status === 'FINISHED' || r.status === 'TIMED_OUT').length;
  const dashActiveOly = olys.find(o => o.status === 'ACTIVE' && statusOf(o.id) === 'confirmed');
  const dashUpcomingOly = olys
    .filter(o => o.status === 'UPCOMING' && statusOf(o.id) === 'confirmed')
    .sort((a, b) => +new Date(a.examStart) - +new Date(b.examStart))[0];
  const recentResults = myResults.slice(0, 3);
  const recentCerts = myCerts.slice(0, 3);
  const FILTERS: { id: typeof olyFilter; label: string; count: number }[] = [
    { id: 'all',          label: 'Barchasi',        count: liveOlys.length },
    { id: 'open',         label: 'Ochiq',            count: liveOlys.filter(o => ['none', 'rejected'].includes(statusOf(o.id))).length },
    { id: 'pending',      label: 'Kutilmoqda',       count: liveOlys.filter(o => ['pending', 'uploaded'].includes(statusOf(o.id))).length },
    { id: 'joined',       label: 'Yozilganlarim',    count: liveOlys.filter(o => statusOf(o.id) === 'confirmed').length },
    { id: 'participated', label: 'Arxiv (qatnashganlarim)',  count: olys.filter(o => participatedSet.has(o.id)).length },
  ];

  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#eaf2fb' }}>
        <Spinner size={28} />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen lg:h-screen lg:overflow-hidden" style={{ backgroundColor: '#eaf2fb' }}>
      {/* Sidebar */}
      <aside className="hidden lg:flex flex-col w-[230px] flex-none border-r border-line lg:h-screen lg:overflow-y-auto"
        style={{ backgroundColor: '#eef4fb', backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='44' height='44'%3E%3Cpath d='M22 0L44 22L22 44L0 22Z' fill='none' stroke='%230877B5' stroke-opacity='0.07' stroke-width='1'/%3E%3C/svg%3E")` }}>
        <div className="px-5 py-5 border-b border-line">
          <a href="/" className="flex items-center gap-3">
            <img src="/logo-mark.svg" alt="Intellect Olympiad" className="w-9 h-9 flex-none" />
            <div className="flex flex-col leading-[1.05]">
              <b className="font-serif font-semibold text-sm text-ink">Intellect Olympiad</b>
              <small className="text-muted" style={{ fontSize: 10, letterSpacing: '.12em', textTransform: 'uppercase' }}>Kabinet</small>
            </div>
          </a>
        </div>
        <nav className="flex-1 py-4 px-3 flex flex-col gap-[2px]">
          {navItems.map(({ id, label, icon }) => (
            <button key={id} type="button" onClick={() => setTab(id)}
              className={`flex items-center gap-3 px-3 py-[9px] rounded text-[13.5px] font-semibold transition-colors w-full text-left border-none cursor-pointer relative ${
                tab === id ? 'bg-bordo-tint text-bordo' : 'text-ink-2 hover:bg-parchment hover:text-ink bg-transparent'
              }`}>
              <span className="w-4 h-4 flex-none">{icon}</span>
              {label}
              {id === 'tolov' && pendingCount > 0 && <span className="ml-auto w-2 h-2 rounded-full bg-ds-amber" />}
            </button>
          ))}
          <div className="text-[11px] tracking-[.1em] uppercase text-muted font-bold px-3 py-2 mt-3">Boshqa</div>
          <a href="/verify" className="flex items-center gap-3 px-3 py-[9px] rounded text-[13.5px] font-semibold text-ink-2 hover:bg-parchment hover:text-ink transition-colors">
            <span className="w-4 h-4 flex-none">{Ic.QR}</span>Sertifikat tekshirish
          </a>
          <button type="button" onClick={handleLogout}
            className="flex items-center gap-3 px-3 py-[9px] rounded text-[13.5px] font-semibold text-ink-2 hover:bg-parchment hover:text-ink transition-colors w-full text-left border-none bg-transparent cursor-pointer">
            <span className="w-4 h-4 flex-none">{Ic.Door}</span>Chiqish
          </button>
        </nav>
      </aside>

      {/* Main */}
      <main className="flex-1 flex flex-col min-w-0 lg:h-screen lg:overflow-hidden">
        {/* Topbar */}
        <div className="bg-surface border-b border-line px-4 sm:px-6 flex items-center justify-between min-h-[60px] gap-2 sm:gap-4 sticky top-0 z-10">
          <div className="flex items-center gap-2 min-w-0">
            <img src="/logo-mark.svg" alt="Intellect Olympiad" className="lg:hidden w-[34px] h-[34px] flex-none" />
            <span className="font-sans font-semibold text-[16px] text-ink">
              {tab === 'dashboard' ? 'Bosh sahifa' : tab === 'tolov' ? "To'lov" : tab === 'natijalar' ? 'Natijalarim' : tab === 'sertifikatlar' ? 'Sertifikatlarim' : tab === 'ustoz' ? 'Ustozlar dasturi' : 'Olimpiadalar'}
            </span>
          </div>
          <div className="flex items-center gap-1 sm:gap-2 flex-none">

            {/* Til tanlagich */}
            <div data-notranslate className="hidden sm:flex items-center gap-[2px] bg-parchment-2 border border-line rounded p-[3px]">
              {LOCALES.map(l => (
                <button key={l} type="button" title={LOCALE_FULL[l]} aria-label={`Til: ${LOCALE_FULL[l]}`} onClick={() => setLocale(l)}
                  className={`text-[11px] font-semibold px-[8px] py-[3px] rounded-sm border-none cursor-pointer transition-colors hover:text-ink ${locale === l ? 'bg-surface text-ink shadow-sm' : 'bg-transparent text-muted'}`}>
                  {LOCALE_LABEL[l]}
                </button>
              ))}
            </div>

            {/* Bildirishnomalar qo'ng'irog'i */}
            <div className="relative">
              <button type="button" onClick={toggleNotif} title="Bildirishnomalar"
                className="relative w-9 h-9 rounded-full flex items-center justify-center text-ink-2 hover:bg-parchment border-none bg-transparent cursor-pointer transition-colors">
                <span className="w-[20px] h-[20px]">{Ic.Bell}</span>
                {notifUnread > 0 && (
                  <span className="absolute top-0.5 right-0.5 min-w-[16px] h-[16px] px-1 rounded-full bg-ds-red text-white text-[10px] font-bold flex items-center justify-center">{notifUnread > 9 ? '9+' : notifUnread}</span>
                )}
              </button>
              {notifOpen && (
                <>
                  <div className="fixed inset-0 z-30" onClick={() => setNotifOpen(false)} />
                  <div className="fixed top-[64px] left-3 right-3 sm:absolute sm:top-auto sm:left-auto sm:right-0 sm:mt-2 sm:w-[320px] max-h-[72vh] overflow-y-auto bg-surface border border-line rounded-xl shadow-xl z-40 anim-fade-up">
                    <div className="px-4 py-3 border-b border-line flex items-center justify-between">
                      <h4 className="font-serif font-semibold text-[14.5px]">Bildirishnomalar</h4>
                      <span className="text-[11.5px] text-muted">{notifs.length} ta</span>
                    </div>
                    <div className="max-h-[360px] overflow-y-auto">
                      {notifs.length === 0 ? (
                        <div className="px-4 py-8 text-center text-muted text-[13px]">Hozircha bildirishnoma yo&apos;q</div>
                      ) : notifs.map(n => (
                        <button key={n.id} type="button" onClick={() => onNotifClick(n)}
                          className={`w-full text-left flex gap-3 px-4 py-3 border-b border-line last:border-0 transition-colors cursor-pointer border-x-0 border-t-0 ${n.isRead ? 'bg-transparent hover:bg-parchment' : 'bg-bordo-tint/40 hover:bg-bordo-tint'}`}>
                          <span className="w-8 h-8 rounded-full bg-parchment-2 text-bordo flex items-center justify-center flex-none mt-0.5"><span className="w-[16px] h-[16px] block">{NOTIF_ICON[n.kind] ?? NOTIF_ICON.info}</span></span>
                          <span className="min-w-0 flex-1">
                            <span className="block font-semibold text-ink text-[13px] leading-snug">{n.title}</span>
                            <span className="block text-[12px] text-ink-2 leading-snug mt-0.5">{n.body}</span>
                            <span className="block text-[11px] text-muted mt-1">{fmtAgo(n.createdAt)}</span>
                          </span>
                          {!n.isRead && <span className="w-2 h-2 rounded-full bg-bordo flex-none mt-1.5" />}
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>

            <button type="button" onClick={openProfile} className="flex items-center gap-[10px] bg-transparent border-none cursor-pointer rounded-lg hover:bg-parchment px-1.5 py-1 transition-colors" title="Profil">
              <div className="w-9 h-9 rounded-full overflow-hidden bg-bordo flex items-center justify-center font-bold text-white text-[14px] flex-none">
                {avatarUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={avatarUrl} alt="avatar" className="w-full h-full object-cover" />
                ) : userInitials}
              </div>
              <div className="hidden sm:block leading-[1.2] text-left">
                <b className="text-[14px] text-ink">{userName}</b><br />
                <small className="text-[12px] text-muted">{isTeacher ? 'Ustoz' : "O'quvchi"}</small>
              </div>
            </button>
          </div>
        </div>

        <div className="flex-1 lg:min-h-0 lg:overflow-y-auto">
        <div className="p-4 sm:p-6 pb-24 lg:pb-6 max-w-[1100px] w-full mx-auto overflow-x-hidden">

          {/* ════════ USTOZLAR DASTURI (teacher referral) ════════ */}
          {tab === 'ustoz' && (
            <TeacherPanel token={getToken() ?? ''} teacherId={currentUser?.id} teacherName={currentUser ? `${currentUser.firstName} ${currentUser.lastName}` : undefined} />
          )}

          {/* ════════ BOSH SAHIFA (dashboard) ════════ */}
          {tab === 'dashboard' && (
            <div className="anim-fade-up">
              <div className="mb-6">
                <h1 className="font-serif text-[22px] sm:text-[27px] font-semibold text-ink">Assalomu alaykum, {currentUser?.firstName ?? 'Foydalanuvchi'}!</h1>
                <p className="text-muted text-[14px] mt-1">Bir qarashda — olimpiadalar, natijalar va sertifikatlaringiz.</p>
              </div>

              {/* Statistika kartalari */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-5">
                {[
                  { label: 'Yozilgan olimpiada', value: String(paidCount), sub: '', icon: Ic.Grid, go: 'olimpiadalar' as CabinetTab },
                  { label: 'Yakunlangan test', value: String(finishedCount), sub: '', icon: Ic.Chart, go: 'natijalar' as CabinetTab },
                  { label: 'Sertifikatlar', value: String(myCerts.length), sub: '', icon: Ic.Award, go: 'sertifikatlar' as CabinetTab },
                  { label: 'Reyting', value: myRank?.rank != null ? `#${myRank.rank}` : '—', sub: myRank ? `${myRank.points} ball` : '', icon: Ic.Trophy, go: undefined },
                ].map((s, i) => (
                  <button key={i} onClick={() => s.go && setTab(s.go)} disabled={!s.go}
                    className={`text-left bg-surface border border-line rounded-xl p-4 transition-colors ${s.go ? 'hover:border-bordo/40 cursor-pointer' : 'cursor-default'}`}>
                    <div className="w-9 h-9 rounded-lg bg-bordo-tint text-bordo flex items-center justify-center mb-3"><span className="w-[18px] h-[18px] block">{s.icon}</span></div>
                    <div className="font-serif text-[24px] font-bold text-ink leading-none">{s.value}</div>
                    <div className="text-[12px] text-muted mt-1.5 truncate">{s.label}{s.sub ? ` · ${s.sub}` : ''}</div>
                  </button>
                ))}
              </div>

              {/* Faol / yaqin olimpiada */}
              {dashActiveOly ? (
                <div className="rounded-2xl p-6 mb-5 relative overflow-hidden text-white" style={{ background: 'linear-gradient(135deg,#0b3b5a,#0877B5)' }}>
                  <span className="absolute -top-12 -right-12 w-44 h-44 rounded-full border border-gold/20" aria-hidden />
                  <div className="relative">
                    <div className="text-[10.5px] tracking-[.16em] uppercase text-gold font-bold mb-1">Faol olimpiada · hozir ochiq</div>
                    <h3 className="font-serif text-[20px] sm:text-[22px] font-semibold leading-tight">{dashActiveOly.title}</h3>
                    <p className="text-white/75 text-[13px] mt-1">{dashActiveOly.durationMin} daqiqa · {dashActiveOly.subjects?.length ?? 0} ta fan</p>
                    <a href={`/exam?olympiadId=${dashActiveOly.id}`} className="inline-flex items-center gap-2 mt-4 font-semibold text-[14px] px-6 py-[11px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors">
                      Testga kirish <span className="w-4 h-4">{Ic.ArrowRight}</span>
                    </a>
                  </div>
                </div>
              ) : dashUpcomingOly ? (
                <div className="bg-surface border border-line rounded-2xl p-6 mb-5 flex items-start justify-between gap-4 flex-wrap">
                  <div className="min-w-0">
                    <div className="text-[10.5px] tracking-[.14em] uppercase text-gold font-bold mb-1">Yaqinlashayotgan olimpiada</div>
                    <h3 className="font-serif text-[19px] font-semibold text-ink leading-tight">{dashUpcomingOly.title}</h3>
                    <p className="text-muted text-[13px] mt-1">{fmtDateTime(dashUpcomingOly.examStart)} · {dashUpcomingOly.durationMin} daqiqa</p>
                  </div>
                  <button onClick={() => setTab('olimpiadalar')} className="font-semibold text-[13px] px-4 py-[9px] rounded-lg border border-line-2 text-ink hover:bg-parchment-2 transition-colors flex-none">Batafsil</button>
                </div>
              ) : (
                <div className="bg-surface border border-line rounded-2xl p-6 mb-5 text-center">
                  <div className="w-12 h-12 rounded-full bg-bordo-tint text-bordo flex items-center justify-center mx-auto mb-3"><span className="w-6 h-6 block">{Ic.Grid}</span></div>
                  <h3 className="font-serif text-[18px] font-semibold text-ink mb-1">Olimpiadaga yoziling</h3>
                  <p className="text-muted text-[13.5px] mb-4">Hozircha faol olimpiadangiz yo&apos;q. Ro&apos;yxatdan o&apos;tib, bilimingizni sinab ko&apos;ring.</p>
                  <button onClick={() => setTab('olimpiadalar')} className="font-semibold text-[14px] px-6 py-[11px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors border-none cursor-pointer">Olimpiadalar →</button>
                </div>
              )}

              {/* Natijalar tahlili — diagrammalar (mobil uchun ham) */}
              <DashboardStats results={myResults} gam={gam} certCount={myCerts.length} />

              {/* XP / Daraja va Do'st taklif */}
              <div className="grid lg:grid-cols-2 gap-4 mb-4">
                {/* XP / Daraja */}
                <div className="bg-surface border border-line rounded-xl p-5">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className="w-8 h-8 rounded-lg bg-gold-tint text-gold flex items-center justify-center"><span className="w-[18px] h-[18px] block">{Ic.Trophy}</span></span>
                      <div>
                        <div className="font-serif text-[16px] font-semibold text-ink leading-none">Daraja {gam?.level ?? 1}</div>
                        <div className="text-[11.5px] text-muted mt-1">Gamifikatsiya</div>
                      </div>
                    </div>
                    <span className="font-mono font-bold text-bordo text-[16px]">{gam?.xp ?? 0} XP</span>
                  </div>
                  <div className="h-2.5 rounded-full bg-parchment-2 overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-500" style={{ width: `${gam?.progressPct ?? 0}%`, background: 'linear-gradient(90deg,#0877B5,#5cb8e6)' }} />
                  </div>
                  <p className="text-[12px] text-muted mt-2">Keyingi darajagacha <b className="text-ink">{(gam?.nextLevelXp ?? 100) - (gam?.levelXp ?? 0)} XP</b> · imtihon, o'tish va do'st taklifi XP beradi</p>
                </div>

                {/* Do'st taklif qilish */}
                <div className="bg-surface border border-line rounded-xl p-5">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-5 h-5 text-bordo">{Ic.Users}</span>
                    <h3 className="font-serif text-[16px] font-semibold text-ink">Do&apos;st taklif qiling</h3>
                  </div>
                  <p className="text-[12.5px] text-muted mb-3">Havola orqali do&apos;stingiz ro&apos;yxatdan o&apos;tsa — <b className="text-ink">ikkalangiz ham XP</b> olasiz.</p>
                  <div className="flex gap-2">
                    <input readOnly value={gam?.inviteUrl ?? ''} onFocus={e => e.target.select()}
                      className="flex-1 min-w-0 text-[12.5px] bg-parchment border border-line rounded-lg px-3 py-2 text-ink-2 outline-none" />
                    <button onClick={copyInvite} disabled={!gam?.inviteUrl}
                      className="font-semibold text-[12.5px] px-4 py-2 rounded-lg bg-bordo text-white hover:bg-bordo-700 border-none cursor-pointer disabled:opacity-50 whitespace-nowrap transition-colors">
                      {inviteCopied ? 'Nusxalandi ✓' : 'Nusxalash'}
                    </button>
                  </div>
                  <p className="text-[12px] text-muted mt-2"><b className="text-ink">{gam?.invitedCount ?? 0} ta</b> do&apos;st taklif qilingan · <b className="text-bordo">+{gam?.invitedXp ?? 0} XP</b></p>
                </div>
              </div>

              {/* So'nggi natijalar va sertifikatlar */}
              <div className="grid lg:grid-cols-2 gap-4">
                <div className="bg-surface border border-line rounded-xl p-5">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-serif text-[16px] font-semibold text-ink">So&apos;nggi natijalar</h3>
                    {myResults.length > 0 && <button onClick={() => setTab('natijalar')} className="text-[12.5px] font-semibold text-bordo hover:underline bg-transparent border-none cursor-pointer">Barchasi</button>}
                  </div>
                  {recentResults.length === 0 ? (
                    <p className="text-[13px] text-muted py-5 text-center">Hali natija yo&apos;q</p>
                  ) : (
                    <div className="flex flex-col gap-2">
                      {recentResults.map(r => (
                        <div key={r.sessionId} className="flex items-center justify-between gap-3 bg-parchment rounded-lg px-3 py-2.5">
                          <div className="min-w-0">
                            <div className="font-semibold text-ink text-[13.5px] truncate">{r.olympiadTitle}</div>
                            <div className="text-[11.5px] text-muted">{r.score ?? 0}/{r.totalScore ?? r.passScore} ball</div>
                          </div>
                          <span className={`text-[11px] font-semibold px-2 py-[3px] rounded-full flex-none ${r.passed ? 'bg-ds-green-tint text-ds-green' : 'bg-parchment-2 text-muted'}`}>{r.passed ? "O'tdi" : 'Tugallandi'}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="bg-surface border border-line rounded-xl p-5">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-serif text-[16px] font-semibold text-ink">So&apos;nggi sertifikatlar</h3>
                    {myCerts.length > 0 && <button onClick={() => setTab('sertifikatlar')} className="text-[12.5px] font-semibold text-bordo hover:underline bg-transparent border-none cursor-pointer">Barchasi</button>}
                  </div>
                  {recentCerts.length === 0 ? (
                    <p className="text-[13px] text-muted py-5 text-center">Hali sertifikat yo&apos;q</p>
                  ) : (
                    <div className="flex flex-col gap-2">
                      {recentCerts.map(c => (
                        <div key={c.id} className="flex items-center justify-between gap-3 bg-parchment rounded-lg px-3 py-2.5">
                          <div className="min-w-0">
                            <div className="font-semibold text-ink text-[13.5px] truncate">{c.session.olympiad.title}</div>
                            <div className="font-mono text-[11.5px] text-muted truncate">{c.certCode}</div>
                          </div>
                          {c.pdfUrl && <a href={`${API_BASE}/certificates/${c.certCode}/pdf`} target="_blank" rel="noreferrer" className="text-[11.5px] font-semibold text-bordo hover:underline flex-none">PDF</a>}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ════════ OLIMPIADALAR (hub) ════════ */}
          {tab === 'olimpiadalar' && (
            <>
              <div className="mb-6 flex items-start justify-between gap-4 flex-wrap">
                <div>
                  <h1 className="font-serif text-[20px] sm:text-[26px] font-semibold text-ink">Assalomu alaykum, {currentUser?.firstName ?? 'Foydalanuvchi'}!</h1>
                  <p className="text-muted text-[14.5px] mt-1">
                    Quyidagi olimpiadalardan o&apos;zingizga mosini tanlang va to&apos;lov qiling.
                    {paidCount > 0 && <> Siz <b className="text-ds-green">{paidCount} ta</b> olimpiadaga yozilgansiz.</>}
                  </p>
                </div>
                {myRank && myRank.rank != null && (
                  <a href="/#reyting" className="flex-none bg-bordo text-white rounded-xl px-5 py-3 flex items-center gap-4 hover:bg-bordo-700 transition-colors">
                    <div className="text-center">
                      <div className="text-[10px] uppercase tracking-[.1em] text-[#cfdde8]">Mening o&apos;rnim</div>
                      <div className="font-serif text-[24px] font-bold leading-none mt-[2px]">#{myRank.rank}</div>
                      <div className="text-[10.5px] text-[#cfdde8]">/ {myRank.total}</div>
                    </div>
                    <div className="border-l border-white/20 pl-4 text-center">
                      <div className="font-serif text-[22px] font-bold leading-none">{myRank.points}</div>
                      <div className="text-[10.5px] text-[#cfdde8] mt-[2px]">ball</div>
                    </div>
                  </a>
                )}
              </div>

              {!olysLoading && olys.length > 0 && (
                <div className="flex items-center gap-2 mb-5 flex-wrap">
                  {FILTERS.map(f => (
                    <button key={f.id} type="button" onClick={() => setOlyFilter(f.id)}
                      className={`text-[12px] sm:text-[13px] font-semibold px-[10px] sm:px-[14px] py-[6px] sm:py-[7px] rounded-full border transition-colors cursor-pointer ${
                        olyFilter === f.id ? 'bg-bordo text-white border-bordo' : 'bg-surface text-ink-2 border-line hover:border-line-2 hover:bg-parchment'
                      }`}>
                      {f.label}
                      <span className={`ml-[6px] text-[11px] font-bold ${olyFilter === f.id ? 'text-white/70' : 'text-muted'}`}>{f.count}</span>
                    </button>
                  ))}
                </div>
              )}

              {olysLoading ? (
                <div className="py-16 text-center anim-fade-up">
                  <div className="w-12 h-12 rounded-full bg-parchment-2 text-muted flex items-center justify-center mx-auto mb-3 anim-float">
                    <span className="w-6 h-6">{Ic.Grid}</span>
                  </div>
                  <div className="text-muted text-[14px] font-medium animate-pulse">Olimpiadalar yuklanmoqda…</div>
                </div>
              ) : olys.length === 0 ? (
                <div className="bg-surface border border-line rounded-xl py-16 px-6 text-center anim-fade-up">
                  <div className="w-16 h-16 rounded-full bg-parchment-2 text-muted flex items-center justify-center mx-auto mb-4 anim-pop">
                    <span className="w-8 h-8">{Ic.Grid}</span>
                  </div>
                  <h3 className="font-serif text-[18px] font-semibold text-ink mb-2">Hozircha olimpiada yo&apos;q</h3>
                  <p className="text-muted text-[13.5px] max-w-[40ch] mx-auto">Hali e&apos;lon qilingan olimpiada yo&apos;q. Tez orada qaytib keling.</p>
                </div>
              ) : filteredOlys.length === 0 ? (
                <div className="bg-surface border border-line rounded-xl py-16 px-6 text-center anim-fade-up">
                  <div className="w-16 h-16 rounded-full bg-parchment-2 text-muted flex items-center justify-center mx-auto mb-4 anim-pop">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-8 h-8"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>
                  </div>
                  <h3 className="font-serif text-[18px] font-semibold text-ink mb-2">Mos olimpiada topilmadi</h3>
                  <p className="text-muted text-[13.5px] max-w-[40ch] mx-auto mb-5">Bu filtr bo&apos;yicha olimpiada yo&apos;q. Boshqa bo&apos;limni tanlab ko&apos;ring.</p>
                  <button onClick={() => setOlyFilter('all')}
                    className="font-semibold text-[13.5px] px-5 py-[10px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors border-none cursor-pointer">
                    Barchasini ko&apos;rsatish
                  </button>
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 gap-4">
                  {filteredOlys.map(o => {
                    const st = statusOf(o.id);
                    const meta = STATUS[st];
                    const full = o.slotsLeft != null && o.slotsLeft <= 0 && st === 'none';
                    return (
                      <div key={o.id} className="bg-surface border border-line rounded-xl p-5 flex flex-col shadow-sm">
                        <div className="flex items-start justify-between gap-3 mb-2">
                          <h3 className="font-serif text-[17px] font-semibold leading-tight">{o.title}</h3>
                          <span className={`text-[11px] font-bold px-[10px] py-[4px] rounded-full whitespace-nowrap flex items-center gap-1 flex-none ${meta.cls}`}>
                            <span className={`w-[5px] h-[5px] rounded-full ${meta.dot}`} />{meta.label}
                          </span>
                        </div>
                        {o.audience && (
                          <div className="text-[12px] text-ink-2 mb-3"><b className="text-ink">Kimlar uchun:</b> {o.audience}</div>
                        )}
                        <div className="grid grid-cols-2 gap-y-2 gap-x-3 sm:gap-x-4 text-[12.5px] mb-4">
                          <div className="min-w-0"><span className="text-muted block">Boshlanish</span><span className="font-semibold text-ink break-words">{fmtDateTime(o.examStart)}</span></div>
                          <div className="min-w-0"><span className="text-muted block">Davomiyligi</span><span className="font-semibold text-ink break-words">{o.durationMin} daqiqa</span></div>
                          <div className="min-w-0"><span className="text-muted block">Fanlar</span><span className="font-semibold text-ink break-words">{o.subjects?.map(s => s.subject.name).join(', ') || '—'}</span></div>
                          <div className="min-w-0"><span className="text-muted block">Joylar</span><span className="font-semibold text-ink break-words">{o.totalSlots == null ? 'Cheksiz' : `${o.slotsLeft ?? o.totalSlots} ta qoldi`}</span></div>
                        </div>
                        <div className="mt-auto pt-3 border-t border-line flex items-center justify-between gap-3 flex-wrap">
                          <div className="min-w-0"><span className="font-serif text-[20px] font-bold text-bordo">{fmtPrice(o.price)}</span><span className="text-[12px] text-muted"> so&apos;m</span></div>
                          {(o.status === 'FINISHED' || o.status === 'CANCELLED') ? (
                            st === 'confirmed'
                              ? <span className="font-semibold text-[13px] px-4 py-[9px] rounded-lg bg-parchment-2 text-muted border border-line-2">{o.status === 'CANCELLED' ? 'Bekor qilingan' : 'Yakunlangan'} · yozilgan</span>
                              : <span className="font-semibold text-[13px] px-4 py-[9px] rounded-lg bg-parchment-2 text-muted border border-line-2">{o.status === 'CANCELLED' ? 'Bekor qilingan' : 'Yakunlangan'}</span>
                          ) : st === 'confirmed' ? (
                            o.status === 'ACTIVE' ? (
                              <a href={`/exam?olympiadId=${o.id}`} className="font-semibold text-[13px] px-4 py-[9px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors">Testga kirish →</a>
                            ) : (
                              <button onClick={() => openOlympiad(o)} className="font-semibold text-[13px] px-4 py-[9px] rounded-lg border border-ds-green/40 text-ds-green bg-ds-green-tint cursor-pointer">Yozilgan ✓</button>
                            )
                          ) : full ? (
                            <span className="font-semibold text-[13px] px-4 py-[9px] rounded-lg bg-parchment-2 text-muted border border-line-2">Joylar to&apos;lgan</span>
                          ) : (
                            <button onClick={() => openOlympiad(o)}
                              className="font-semibold text-[13px] px-4 py-[9px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors border-none cursor-pointer">
                              {st === 'none' ? "To'lov qilish" : st === 'pending' ? 'Chek yuklash' : st === 'uploaded' ? "Holatni ko'rish" : "Qayta to'lash"}
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {/* ════════ TO'LOV (selected olympiad flow) ════════ */}
          {tab === 'tolov' && (
            <div className="max-w-[680px]">
              <button onClick={() => setTab('olimpiadalar')} className="inline-flex items-center gap-2 text-[13.5px] font-semibold text-bordo hover:underline bg-transparent border-none cursor-pointer mb-4">
                <span className="w-4 h-4">{Ic.Back}</span> Olimpiadalar ro&apos;yxatiga
              </button>

              {!selected ? (
                <div className="bg-surface border border-line rounded-xl p-10 text-center anim-fade-up">
                  <div className="w-16 h-16 rounded-full bg-parchment-2 text-muted flex items-center justify-center mx-auto mb-4 anim-pop">
                    <span className="w-8 h-8">{Ic.CreditCard}</span>
                  </div>
                  <h3 className="font-serif text-[18px] font-semibold text-ink mb-2">Olimpiada tanlanmagan</h3>
                  <p className="text-muted text-[13.5px] max-w-[40ch] mx-auto mb-5">To&apos;lov qilish uchun avval olimpiadalar ro&apos;yxatidan birini tanlang.</p>
                  <button onClick={() => setTab('olimpiadalar')}
                    className="font-semibold text-[13.5px] px-5 py-[10px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors border-none cursor-pointer">
                    Olimpiadalar
                  </button>
                </div>
              ) : (
                <>
                  {/* Selected olympiad header */}
                  <div className="bg-surface border border-line rounded-xl p-5 mb-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h2 className="font-serif text-[19px] font-semibold">{selected.title}</h2>
                        <div className="text-[13px] text-muted mt-1">{fmtDateTime(selected.examStart)} · {selected.durationMin} daqiqa</div>
                      </div>
                      <div className="text-right flex-none">
                        <div className="font-serif text-[20px] font-bold text-bordo">{fmtPrice(selected.price)}</div>
                        <div className="text-[12px] text-muted">so&apos;m</div>
                      </div>
                    </div>
                  </div>

                  {payError && <div className="text-[13.5px] text-ds-red bg-ds-red-tint border border-ds-red/30 rounded-lg px-3 py-2 mb-4">{payError}</div>}

                  {/* Yakunlangan/bekor qilingan — yozilish yopiq */}
                  {selStatus === 'none' && (selected.status === 'FINISHED' || selected.status === 'CANCELLED') && (
                    <div className="bg-surface border border-line rounded-xl p-6 text-center text-muted text-[14.5px]">
                      Bu olimpiada {selected.status === 'CANCELLED' ? 'bekor qilingan' : 'yakunlangan'} — yangi yozilish yopiq. Faol olimpiadani tanlang.
                    </div>
                  )}

                  {/* Step: not paid yet → Click (asosiy) + bank o'tkazma (zaxira) */}
                  {selStatus === 'none' && selected.status !== 'FINISHED' && selected.status !== 'CANCELLED' && (
                    <div className="bg-surface border border-line rounded-xl p-5 sm:p-6">
                      <div className="text-[12px] font-bold uppercase tracking-[.08em] text-muted mb-3">To&apos;lov</div>
                      {/* Click — asosiy usul */}
                      <button onClick={payClick} disabled={payLoading}
                        className="w-full flex items-center justify-center gap-2.5 font-semibold text-[15px] px-7 py-[13px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors border-none cursor-pointer disabled:opacity-50">
                        {payLoading
                          ? <span className="inline-flex items-center gap-2"><Spinner size={16} /> Yo&apos;naltirilmoqda…</span>
                          : <>Click orqali to&apos;lash — {fmtPrice(selected.price)} so&apos;m →</>}
                      </button>
                      <p className="text-[12.5px] text-muted text-center mt-2.5 leading-snug">
                        Click to&apos;lov sahifasiga o&apos;tasiz; to&apos;lagach <b className="text-ink-2">avtomatik tasdiqlanadi</b> — chek yuklash shart emas.
                      </p>
                      {/* Zaxira: bank o'tkazmasi */}
                      <details className="border-t border-line mt-4 pt-3">
                        <summary className="text-[12.5px] text-ink-2 font-semibold cursor-pointer select-none list-none">Bank o&apos;tkazmasi orqali to&apos;lash (zaxira)</summary>
                        <p className="text-[13px] text-ink-2 my-3 leading-relaxed">Hisob raqamga o&apos;tkazma orqali ham to&apos;lashingiz mumkin — avval to&apos;lov kodini oling, so&apos;ngra chekni yuklang.</p>
                        <button onClick={requestPaymentCode} disabled={payLoading}
                          className="font-semibold text-[13.5px] px-5 py-[9px] rounded-lg border border-line-2 text-ink bg-transparent hover:bg-parchment-2 transition-colors cursor-pointer disabled:opacity-50">
                          To&apos;lov kodini olish →
                        </button>
                      </details>
                    </div>
                  )}

                  {/* Step: pending → instructions + receipt upload */}
                  {selStatus === 'pending' && selPayment && (
                    <div className="space-y-4">
                      <div className="bg-surface border border-line rounded-xl p-5">
                        <div className="text-[12px] font-bold uppercase tracking-[.08em] text-muted mb-2">Sizning to&apos;lov kodingiz</div>
                        <div className="flex items-center gap-3 flex-wrap">
                          <span className="font-mono text-[20px] font-bold text-ink tracking-[.04em] flex-1 min-w-0 break-all">{selPayment.paymentCode}</span>
                          <button onClick={() => copyCode(selPayment.paymentCode ?? '')}
                            className={`flex items-center gap-[6px] text-[13px] font-semibold px-4 py-[8px] rounded-lg border-none cursor-pointer ${copied ? 'bg-ds-green-tint text-ds-green' : 'bg-parchment-2 text-ink hover:bg-parchment'}`}>
                            <span className="w-[14px] h-[14px]">{copied ? Ic.CheckSmall : Ic.Copy}</span>{copied ? 'Nusxalandi' : 'Nusxalash'}
                          </button>
                        </div>
                        <p className="text-[12.5px] text-muted mt-2">To&apos;lov izohiga <b className="text-ink">shu kodni yozing</b>.</p>
                      </div>

                      <div className="bg-gradient-to-br from-bordo-900 to-bordo rounded-xl p-6 text-white">
                        <div className="text-[11px] tracking-[.16em] uppercase text-[#cfdde8] font-bold mb-3">To&apos;lov rekvizitlari</div>
                        <div className="space-y-[7px]">
                          {[
                            ['Oluvchi', PAY_ORG, false],
                            ['Hisob raqam', PAY_ACCOUNT, true],
                            ['Bank', PAY_BANK, false],
                            ['MFO', PAY_MFO, true],
                            ['STIR', PAY_STIR, true],
                          ].map(([l, v, mono]) => (
                            <div key={l as string} className="flex items-start justify-between gap-2 flex-wrap">
                              <span className="text-[11px] text-[#9fbdd2] uppercase flex-none pt-[2px]">{l}</span>
                              <span className={`text-[13.5px] font-semibold text-right min-w-0 break-all ${mono ? 'font-mono tracking-[.02em]' : ''}`}>{v}</span>
                            </div>
                          ))}
                        </div>
                        <div className="mt-4 pt-3 border-t border-white/15 flex items-center justify-between gap-2 flex-wrap">
                          <span className="text-[11px] text-[#9fbdd2] uppercase">To&apos;lov maqsadi</span>
                          <span className="font-mono font-bold text-[15px] min-w-0 break-all text-right">{selPayment.paymentCode}</span>
                        </div>
                        <div className="mt-2 flex items-center justify-between gap-2 flex-wrap">
                          <span className="text-[11px] text-[#9fbdd2] uppercase">Summa</span>
                          <span className="font-serif font-bold text-[19px]">{fmtPrice(selected.price)} <span className="text-[13px] font-normal">so&apos;m</span></span>
                        </div>
                      </div>

                      {/* Qanday to'lash — usul tanlovi + batafsil qadamlar */}
                      <div className="bg-surface border border-line rounded-xl overflow-hidden">
                        <div className="px-5 pt-4">
                          <div className="text-[14px] font-semibold text-ink mb-3">Qanday to&apos;laysiz? Usulni tanlang</div>
                          <div className="grid grid-cols-2 gap-2">
                            {([
                              { id: 'mobile' as const, title: 'Mobil ilova orqali', sub: 'Bank ilovasidan, uydan chiqmasdan' },
                              { id: 'bank' as const, title: 'Bank kassasida', sub: 'Filialga borib, naqd yoki karta' },
                            ]).map(m => (
                              <button key={m.id} type="button" onClick={() => setPayMethod(m.id)}
                                className={`text-left rounded-xl border-2 p-3 cursor-pointer transition-colors ${
                                  payMethod === m.id ? 'border-bordo bg-bordo-tint' : 'border-line bg-surface hover:bg-parchment'
                                }`}>
                                <div className={`text-[13.5px] font-bold ${payMethod === m.id ? 'text-bordo' : 'text-ink'}`}>{m.title}</div>
                                <div className="text-[11.5px] text-muted mt-[2px] leading-snug">{m.sub}</div>
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* ── MOBIL ILOVA QADAMLARI ── */}
                        {payMethod === 'mobile' && (
                          <div className="p-5 space-y-2">
                            {[
                              <>Bankingizning <b>mobil ilovasini</b> oching (Kapitalbank, Ipoteka Mobile, SQB, Xalq banki, Agrobank, Asaka va h.k.).</>,
                              <>&quot;To&apos;lovlar&quot; yoki &quot;O&apos;tkazmalar&quot; bo&apos;limidan <b>&quot;Tashkilotga to&apos;lov&quot;</b> / <b>&quot;Yuridik shaxsga o&apos;tkazma&quot;</b> / <b>&quot;Hisobraqamga to&apos;lov&quot;</b> ni tanlang (nomi har bankda har xil; qidiruvga &quot;yuridik&quot; deb yozsangiz chiqadi).</>,
                              <>Hisob raqamni kiriting: <b className="font-mono">{PAY_ACCOUNT}</b> — yuqoridagi kartadan nusxalang, qo&apos;lda termang.</>,
                              <>MFO so&apos;ralsa: <b className="font-mono">{PAY_MFO}</b> — bank nomi (&quot;{PAY_BANK.split(',')[0]}&quot;) avtomatik chiqadi.</>,
                              <>Oluvchi: <b>{PAY_ORG}</b>, STIR so&apos;ralsa: <b className="font-mono">{PAY_STIR}</b>.</>,
                              <>Summa: <b>{fmtPrice(selected.price)} so&apos;m</b>. Ilova komissiya ko&apos;rsatsa, komissiya <b>summaning ustiga</b> qo&apos;shilsin — hisobga aynan to&apos;liq summa borishi kerak.</>,
                              <>&quot;To&apos;lov maqsadi&quot; / &quot;Izoh&quot; maydoniga faqat shu kodni yozing: <b className="font-mono">{selPayment.paymentCode}</b> (yuqorida nusxalash tugmasi bor).</>,
                              <>SMS-kod bilan tasdiqlang va <b>chekni saqlang</b> — ilovada &quot;Chekni yuklab olish&quot; (PDF) yoki ekran surati (screenshot).</>,
                              <>Chekni <b>pastdagi &quot;Chek yuklash&quot;</b> bo&apos;limiga yuklang — shu bilan tamom, tasdiqlashni kutasiz.</>,
                            ].map((s, i) => (
                              <div key={i} className="flex items-start gap-3 text-[13px] text-ink leading-relaxed">
                                <span className="w-5 h-5 rounded-full bg-bordo text-white flex items-center justify-center text-[11px] font-bold flex-none mt-[1px]">{i + 1}</span>
                                <span className="min-w-0">{s}</span>
                              </div>
                            ))}
                            <div className="bg-ds-amber-tint border border-[#e0cba0] rounded-lg p-3.5 mt-3 space-y-1.5">
                              <div className="font-bold text-[12.5px] text-[#7a5a25] uppercase tracking-[.04em]">Bilib qo&apos;ying</div>
                              {[
                                <><b>Pul darhol o&apos;tmasligi mumkin.</b> Tashkilot hisobiga o&apos;tkazma odatda bir necha daqiqada, ba&apos;zan bir necha soatda boradi; kechki payt, shanba-yakshanba yoki bayramda yuborilgani <b>keyingi ish kunida</b> o&apos;tadi. Shuning uchun imtihonga <b>kamida 1–2 kun qolganda</b> to&apos;lang.</>,
                                <><b>Click va Payme&apos;dan bu hisobga to&apos;g&apos;ridan-to&apos;g&apos;ri o&apos;tkazib bo&apos;lmaydi</b> — ular kartadan-kartaga ishlaydi. Faqat bankning o&apos;z ilovasidan yuboring.</>,
                                <>To&apos;lov maqsadiga <b>kod yozilmasa</b> to&apos;lovingizni topish qiyinlashadi va tasdiqlash kechikadi — chekni yuklasangiz baribir hal qilamiz, lekin kod yozilgani ancha tez.</>,
                                <>Chek yuklangach admin odatda <b>1–2 soat ichida</b> tasdiqlaydi (ish vaqtida) — holat shu sahifada va Telegram&apos;da ko&apos;rinadi.</>,
                              ].map((w, i) => (
                                <div key={i} className="flex items-start gap-2 text-[12.5px] text-ink leading-relaxed">
                                  <span className="flex-none mt-[3px] w-[6px] h-[6px] rounded-full bg-[#b98a2e]" />
                                  <span className="min-w-0">{w}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* ── BANK KASSASI QADAMLARI ── */}
                        {payMethod === 'bank' && (
                          <div className="p-5 space-y-2">
                            {[
                              <>Istalgan bank filialiga <b>pasport (yoki ID-karta)</b> bilan boring — to&apos;lovni ota-ona yoki boshqa kishi ham qilib berishi mumkin.</>,
                              <>Kassirga ayting: <b>&quot;Tashkilot hisob raqamiga to&apos;lov qilmoqchiman&quot;</b>.</>,
                              <>Rekvizitlarni ko&apos;rsating — eng osoni telefonda <b>shu sahifani ochib berish</b>: oluvchi <b>{PAY_ORG}</b>, hisob raqam <b className="font-mono">{PAY_ACCOUNT}</b>, MFO <b className="font-mono">{PAY_MFO}</b>, STIR <b className="font-mono">{PAY_STIR}</b>.</>,
                              <>Summani ayting: <b>{fmtPrice(selected.price)} so&apos;m</b>. Kassir komissiya olsa — komissiya <b>alohida</b> to&apos;lanadi, hisobga to&apos;liq summa borishi kerak.</>,
                              <>To&apos;lov maqsadiga shu kodni <b>yozdirishni unutmang</b>: <b className="font-mono">{selPayment.paymentCode}</b> — qog&apos;ozga yozib olib boring yoki telefondan ko&apos;rsating.</>,
                              <>Kassir bergan <b>kvitansiyani oling</b> va imtihon natijalari e&apos;lon qilinguncha saqlang.</>,
                              <>Kvitansiyani <b>suratga olib</b> pastdagi &quot;Chek yuklash&quot; bo&apos;limiga yuklang (yozuvlari aniq o&apos;qiladigan bo&apos;lsin).</>,
                            ].map((s, i) => (
                              <div key={i} className="flex items-start gap-3 text-[13px] text-ink leading-relaxed">
                                <span className="w-5 h-5 rounded-full bg-bordo text-white flex items-center justify-center text-[11px] font-bold flex-none mt-[1px]">{i + 1}</span>
                                <span className="min-w-0">{s}</span>
                              </div>
                            ))}
                            <div className="bg-ds-amber-tint border border-[#e0cba0] rounded-lg p-3.5 mt-3 space-y-1.5">
                              <div className="font-bold text-[12.5px] text-[#7a5a25] uppercase tracking-[.04em]">Bilib qo&apos;ying</div>
                              {[
                                <><b>Bank ish vaqti cheklangan</b> — odatda dushanba–juma 9:00–17:00, shanba qisqartirilgan, yakshanba dam. Imtihon arafasiga qoldirmang: <b>kamida 1–2 kun oldin</b> to&apos;lang.</>,
                                <>Kassa orqali to&apos;lov ham hisobga <b>darhol tushmasligi mumkin</b> (bank ichki o&apos;tkazmasi) — bu normal holat, chek yuklangan bo&apos;lsa tasdiqlaymiz.</>,
                                <><b>Kvitansiyani yo&apos;qotmang</b> — biror tushunmovchilik bo&apos;lsa, to&apos;lovning yagona isboti shu.</>,
                                <>Ismingiz yozilmagan (boshqa odam to&apos;lagan) bo&apos;lsa ham muammo emas — <b>to&apos;lov kodi</b> orqali topiladi, shuning uchun kod juda muhim.</>,
                              ].map((w, i) => (
                                <div key={i} className="flex items-start gap-2 text-[12.5px] text-ink leading-relaxed">
                                  <span className="flex-none mt-[3px] w-[6px] h-[6px] rounded-full bg-[#b98a2e]" />
                                  <span className="min-w-0">{w}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="bg-surface border border-line rounded-xl p-5">
                        <div className="text-[14px] font-semibold text-ink mb-3">Chek yuklash</div>
                        <input ref={fileRef} type="file" accept="image/*,.pdf" onChange={e => { const f = e.target.files?.[0]; if (f) setReceiptFile(f); }} className="hidden" />
                        <div onClick={() => fileRef.current?.click()}
                          className="border-2 border-dashed border-line-2 rounded-lg p-6 text-center cursor-pointer hover:border-bordo hover:bg-parchment transition-colors">
                          <span className="w-8 h-8 mx-auto mb-2 block text-muted">{Ic.Upload}</span>
                          {receiptFile ? (
                            <div><div className="text-[14px] font-semibold text-ds-green">{receiptFile.name}</div><div className="text-[11.5px] text-muted mt-[2px]">{(receiptFile.size / 1024).toFixed(1)} KB</div></div>
                          ) : (
                            <><div className="text-[14px] font-semibold text-ink">Faylni bosing yoki torting</div><div className="text-[12.5px] text-muted mt-1">PNG, JPG, WEBP, PDF — max 8 MB</div></>
                          )}
                        </div>
                        <button onClick={submitReceipt} disabled={!receiptFile || payLoading}
                          className="mt-4 w-full font-semibold text-[15px] py-[12px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors border-none cursor-pointer disabled:opacity-40">
                          {payLoading ? <span className="inline-flex items-center gap-2"><Spinner size={16} /> Yuklanmoqda…</span> : 'Chekni yuborish'}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Step: uploaded → waiting */}
                  {selStatus === 'uploaded' && (
                    <div className="bg-ds-amber-tint border border-[#c9a96e] rounded-xl p-7 text-center">
                      <div className="w-14 h-14 rounded-full bg-[#c9a96e] flex items-center justify-center mx-auto mb-4"><span className="w-7 h-7 text-white">{Ic.Hourglass}</span></div>
                      <h3 className="font-serif text-[19px] font-semibold text-ink mb-2">Chekingiz ko&apos;rib chiqilmoqda</h3>
                      <p className="text-[14px] text-muted max-w-[42ch] mx-auto">Admin chekni tekshirib, 1–2 soat ichida tasdiqlaydi. Tasdiqlangach bu yerda avtomatik yangilanadi.</p>
                    </div>
                  )}

                  {/* Step: confirmed */}
                  {selStatus === 'confirmed' && (
                    <div className="bg-ds-green-tint border border-[#a8d5bb] rounded-xl p-7 text-center">
                      <div className="w-14 h-14 rounded-full bg-ds-green flex items-center justify-center mx-auto mb-4"><span className="w-7 h-7 text-white">{Ic.CheckCircle}</span></div>
                      <h3 className="font-serif text-[19px] font-semibold text-ink mb-2">To&apos;lov tasdiqlandi!</h3>
                      <p className="text-[14px] text-muted max-w-[42ch] mx-auto">Siz <b>{selected.title}</b>ga rasman yozildingiz.</p>
                      {/* Countdown */}
                      <div className="mt-5 flex gap-[6px] sm:gap-[10px] max-w-full md:max-w-[360px] mx-auto">
                        {[{ v: pad(cd.d), l: 'kun' }, { v: pad(cd.h), l: 'soat' }, { v: pad(cd.m), l: 'daqiqa' }, { v: pad(cd.s), l: 'soniya' }].map((u, i) => (
                          <div key={i} className="flex-1 min-w-0 bg-surface rounded-lg py-[8px] sm:py-[10px] px-[2px] text-center border border-line">
                            <b className="font-serif text-[18px] sm:text-[22px] font-bold text-ink block leading-none">{u.v}</b><span className="text-[10px] sm:text-[11px] text-muted">{u.l}</span>
                          </div>
                        ))}
                      </div>
                      {selected.status === 'ACTIVE' ? (
                        <a href={`/exam?olympiadId=${selected.id}`} className="mt-5 inline-flex items-center justify-center font-semibold text-[15px] px-8 py-[12px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors">Testga kirish →</a>
                      ) : (
                        <div className="mt-5 text-[13px] text-muted">Test belgilangan vaqtda avtomatik ochiladi.</div>
                      )}
                    </div>
                  )}

                  {/* Step: rejected */}
                  {selStatus === 'rejected' && (
                    <div className="bg-ds-red-tint border border-ds-red/30 rounded-xl p-7 text-center">
                      <div className="w-14 h-14 rounded-full bg-ds-red flex items-center justify-center mx-auto mb-4"><span className="w-7 h-7 text-white">{Ic.Alert}</span></div>
                      <h3 className="font-serif text-[19px] font-semibold text-ink mb-2">To&apos;lov rad etildi</h3>
                      {selPayment?.rejectionReason && <p className="text-[14px] text-ds-red mb-2"><b>Sabab:</b> {selPayment.rejectionReason}</p>}
                      <p className="text-[14px] text-muted max-w-[42ch] mx-auto">To&apos;lovni qaytadan amalga oshiring va yangi chek yuklang.</p>
                      <button onClick={requestPaymentCode} disabled={payLoading}
                        className="mt-5 font-semibold text-[15px] px-7 py-[11px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors border-none cursor-pointer disabled:opacity-50">
                        {payLoading ? <span className="inline-flex items-center gap-2"><Spinner size={16} /> Yuklanmoqda…</span> : "Qaytadan to'lash"}
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          {/* ════════ NATIJALAR ════════ */}
          {tab === 'natijalar' && (
            <>
              <div className="mb-5">
                <h1 className="font-serif text-[24px] font-semibold text-ink">Natijalarim</h1>
                <p className="text-muted text-[14px] mt-1">Yakunlangan imtihonlaringiz va ballaringiz.</p>
              </div>
              {!resultsLoaded ? (
                <div className="py-16 text-center anim-fade-up">
                  <div className="w-12 h-12 rounded-full bg-parchment-2 text-muted flex items-center justify-center mx-auto mb-3 anim-float">
                    <span className="w-6 h-6">{Ic.Chart}</span>
                  </div>
                  <div className="text-muted text-[14px] font-medium animate-pulse">Natijalar yuklanmoqda…</div>
                </div>
              ) : myResults.length === 0 ? (
                <div className="bg-surface border border-line rounded-xl p-10 text-center anim-fade-up">
                  <div className="w-16 h-16 rounded-full bg-parchment-2 text-muted flex items-center justify-center mx-auto mb-4 anim-pop">
                    <span className="w-8 h-8">{Ic.Chart}</span>
                  </div>
                  <h3 className="font-serif text-[18px] font-semibold text-ink mb-2">Hali natija yo&apos;q</h3>
                  <p className="text-muted text-[13.5px] max-w-[42ch] mx-auto mb-5">Olimpiadada qatnashganingizdan so&apos;ng ballaringiz va natijalaringiz shu yerda ko&apos;rinadi.</p>
                  <button onClick={() => setTab('olimpiadalar')}
                    className="font-semibold text-[13.5px] px-5 py-[10px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors border-none cursor-pointer">
                    Olimpiadalar
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {myResults.map(r => {
                    const finished = r.status === 'FINISHED' || r.status === 'TIMED_OUT';
                    const pct = r.score != null && r.totalScore ? Math.round((r.score / r.totalScore) * 100) : null;
                    return (
                      <div key={r.sessionId} className="bg-surface border border-line rounded-xl p-5">
                        <div className="flex items-start justify-between gap-3 sm:gap-4 flex-wrap">
                          <div className="min-w-0 flex-1">
                            <h3 className="font-serif text-[17px] font-semibold leading-tight break-words">{r.olympiadTitle}</h3>
                            <div className="text-[12.5px] text-muted mt-1">
                              {fmtDateTime(r.startsAt)}
                              {r.status === 'DISQUALIFIED' && <span className="text-ds-red font-semibold"> · Diskvalifikatsiya</span>}
                              {r.status === 'IN_PROGRESS' && <span className="text-ds-info font-semibold"> · Jarayonda</span>}
                              {r.status === 'NOT_STARTED' && <span className="text-muted"> · Boshlanmagan</span>}
                            </div>
                          </div>
                          {finished && (
                            <div className="flex items-center gap-3 sm:gap-4 flex-none">
                              <div className="text-right">
                                <div className="font-serif text-[24px] font-bold text-ink leading-none">{r.score ?? 0}<span className="text-[14px] text-muted font-normal">/{r.totalScore ?? 0}</span></div>
                                {pct != null && <div className="text-[12px] text-muted mt-1">{pct}%</div>}
                              </div>
                              <span className={`text-[12px] font-bold px-3 py-[5px] rounded-full whitespace-nowrap ${r.passed ? 'bg-ds-green-tint text-ds-green' : 'bg-ds-red-tint text-ds-red'}`}>
                                {r.passed ? "O'tdi" : "O'tmadi"}
                              </span>
                            </div>
                          )}
                        </div>
                        <div className="mt-3 pt-3 border-t border-line flex items-center gap-3 flex-wrap">
                          {finished && (
                            <a href={`/result?sessionId=${r.sessionId}`} className="font-semibold text-[13px] px-4 py-[8px] rounded-lg border border-line-2 text-ink hover:bg-parchment-2 transition-colors">Batafsil natija</a>
                          )}
                          {r.status === 'IN_PROGRESS' && (
                            <a href={`/exam?olympiadId=${r.olympiadId}`} className="font-semibold text-[13px] px-4 py-[8px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors">Davom etish →</a>
                          )}
                          {r.certCode && (
                            <button onClick={() => setTab('sertifikatlar')} className="font-semibold text-[13px] px-4 py-[8px] rounded-lg bg-gold-tint text-gold border-none cursor-pointer">Sertifikat: {r.certCode}</button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {/* ════════ SERTIFIKATLAR ════════ */}
          {tab === 'sertifikatlar' && (
            <>
              <div className="mb-5 flex items-end justify-between gap-3 flex-wrap">
                <div>
                  <h1 className="font-serif text-[24px] font-semibold text-ink">Sertifikatlarim</h1>
                  <p className="text-muted text-[14px] mt-1">Raqamli sertifikatlaringiz — yuklab oling yoki QR orqali tekshiring.</p>
                </div>
                <a href="/verify" className="font-semibold text-[13.5px] px-4 py-[9px] rounded-lg border border-line-2 text-ink hover:bg-parchment-2 transition-colors">Sertifikat tekshirish</a>
              </div>
              {!certsLoaded ? (
                <div className="py-16 text-center anim-fade-up">
                  <div className="w-12 h-12 rounded-full bg-parchment-2 text-muted flex items-center justify-center mx-auto mb-3 anim-float">
                    <span className="w-6 h-6">{Ic.Award}</span>
                  </div>
                  <div className="text-muted text-[14px] font-medium animate-pulse">Sertifikatlar yuklanmoqda…</div>
                </div>
              ) : myCerts.length === 0 ? (
                <div className="bg-surface border border-line rounded-xl p-10 text-center anim-fade-up">
                  <div className="w-16 h-16 rounded-full bg-gold-tint text-gold flex items-center justify-center mx-auto mb-4 anim-pop">
                    <span className="w-8 h-8">{Ic.Award}</span>
                  </div>
                  <h3 className="font-serif text-[18px] font-semibold text-ink mb-2">Hali sertifikat yo&apos;q</h3>
                  <p className="text-muted text-[13.5px] max-w-[44ch] mx-auto mb-5">Olimpiadadan muvaffaqiyatli o&apos;tgach, raqamli sertifikatingiz shu yerda paydo bo&apos;ladi.</p>
                  <button onClick={() => setTab('natijalar')}
                    className="font-semibold text-[13.5px] px-5 py-[10px] rounded-lg border border-line-2 text-ink hover:bg-parchment-2 transition-colors bg-transparent cursor-pointer">
                    Natijalarim
                  </button>
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 gap-4">
                  {myCerts.map(c => (
                    <div key={c.id} className="bg-surface border border-line rounded-xl p-5 flex flex-col">
                      <div className="flex items-start gap-3 mb-3">
                        <div className="w-11 h-11 rounded-lg bg-gold-tint flex items-center justify-center flex-none"><span className="w-6 h-6 text-gold">{Ic.Award}</span></div>
                        <div className="min-w-0">
                          <h3 className="font-serif text-[16px] font-semibold leading-tight">{c.session.olympiad.title}</h3>
                          <div className="text-[12px] text-muted mt-[2px]">{c.session.olympiad.year}-yil</div>
                        </div>
                      </div>
                      <div className="bg-parchment-2 rounded-lg px-3 py-2 mb-3">
                        <div className="text-[10.5px] uppercase tracking-[.08em] text-muted font-bold">Sertifikat kodi</div>
                        <div className="font-mono text-[15px] font-bold text-ink break-all">{c.certCode}</div>
                      </div>
                      <div className="mt-auto flex items-center gap-2 flex-wrap">
                        <a href={`${API_BASE}/certificates/${c.certCode}/pdf`} target="_blank" rel="noreferrer"
                          className="flex-1 min-w-[120px] text-center font-semibold text-[13px] px-2 sm:px-3 py-[9px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors">PDF yuklab olish</a>
                        <a href={`/verify?code=${c.certCode}`}
                          className="flex-1 min-w-[120px] text-center font-semibold text-[13px] px-2 sm:px-3 py-[9px] rounded-lg border border-line-2 text-ink hover:bg-parchment-2 transition-colors">Tekshirish</a>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

        </div>
        </div>

        {/* Profil modali */}
        {profileOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 p-4" onClick={() => !profileSaving && setProfileOpen(false)}>
            <div className="bg-surface rounded-2xl shadow-xl max-w-[460px] w-full max-h-[92vh] overflow-y-auto anim-fade-up" onClick={e => e.stopPropagation()}>
              <div className="px-5 py-4 border-b border-line flex items-center gap-3">
                <div className="relative flex-none">
                  <button type="button" onClick={() => avatarInputRef.current?.click()} disabled={avatarBusy}
                    className="w-12 h-12 rounded-full overflow-hidden bg-bordo text-white flex items-center justify-center font-bold font-serif text-[16px] border-none cursor-pointer relative group">
                    {avatarUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={avatarUrl} alt="avatar" className="w-full h-full object-cover" />
                    ) : userInitials}
                    <span className="absolute inset-0 bg-black/45 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
                    </span>
                  </button>
                  {avatarBusy && <span className="absolute inset-0 rounded-full bg-white/60 flex items-center justify-center text-[9px] font-bold text-bordo">…</span>}
                  <input ref={avatarInputRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden"
                    onChange={e => { const f = e.target.files?.[0]; if (f) uploadAvatar(f); e.target.value = ''; }} />
                </div>
                <div className="min-w-0 flex-1">
                  <h4 className="font-serif font-semibold text-[17px] truncate">{userName}</h4>
                  <p className="text-[12.5px] text-muted truncate">{currentUser?.email} · {isTeacher ? 'Ustoz' : "O'quvchi"}</p>
                  <button type="button" onClick={() => avatarInputRef.current?.click()} className="text-[11.5px] font-semibold text-bordo hover:underline bg-transparent border-none cursor-pointer p-0 mt-0.5">Rasm o&apos;zgartirish</button>
                </div>
                <button onClick={() => setProfileOpen(false)} className="text-muted hover:text-ink bg-transparent border-none cursor-pointer p-1" aria-label="Yopish">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
              </div>
              <div className="p-5 space-y-3">
                {(() => { const fld = "w-full text-[14px] border border-line-2 rounded-lg px-3 py-2.5 bg-parchment/40 focus:outline-none focus:border-bordo text-ink"; const lbl = "block text-[12px] font-semibold text-ink-2 mb-1"; return (
                  <>
                    <div className="grid grid-cols-2 gap-3">
                      <div><label className={lbl}>Ism</label><input className={fld} value={profileForm.firstName} onChange={e => setProfileForm(f => ({ ...f, firstName: e.target.value }))} /></div>
                      <div><label className={lbl}>Familiya</label><input className={fld} value={profileForm.lastName} onChange={e => setProfileForm(f => ({ ...f, lastName: e.target.value }))} /></div>
                    </div>
                    <div><label className={lbl}>Email</label><input className={`${fld} opacity-60 cursor-not-allowed`} value={currentUser?.email ?? ''} readOnly /></div>
                    <div><label className={lbl}>Telefon</label><input className={fld} value={profileForm.phone} onChange={e => setProfileForm(f => ({ ...f, phone: e.target.value }))} placeholder="+998 90 123 45 67" /></div>
                    <div className="grid grid-cols-2 gap-3">
                      <div><label className={lbl}>Viloyat</label><input className={fld} value={profileForm.region} onChange={e => setProfileForm(f => ({ ...f, region: e.target.value }))} /></div>
                      <div><label className={lbl}>Maktab</label><input className={fld} value={profileForm.school} onChange={e => setProfileForm(f => ({ ...f, school: e.target.value }))} /></div>
                    </div>
                  </>
                ); })()}
                {gam && (
                  <div className="bg-parchment rounded-lg p-3 flex items-center justify-between text-[12.5px]">
                    <span className="text-muted">XP · Daraja</span>
                    <b className="text-ink">{gam.xp} XP · {gam.level}-daraja</b>
                  </div>
                )}

                {/* Parolni o'zgartirish */}
                <details className="border border-line rounded-lg overflow-hidden">
                  <summary className="px-3 py-2.5 text-[13px] font-semibold text-ink cursor-pointer select-none flex items-center gap-2 bg-parchment/40 list-none">
                    <span className="w-4 h-4 text-bordo"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg></span>
                    Parolni o&apos;zgartirish
                  </summary>
                  <div className="p-3 space-y-2 border-t border-line">
                    <input type="password" autoComplete="current-password" placeholder="Joriy parol" value={pwForm.current}
                      onChange={e => setPwForm(f => ({ ...f, current: e.target.value }))}
                      className="w-full text-[13.5px] border border-line-2 rounded-lg px-3 py-2 bg-parchment/40 focus:outline-none focus:border-bordo" />
                    <input type="password" autoComplete="new-password" placeholder="Yangi parol (min 10 belgi)" value={pwForm.next}
                      onChange={e => setPwForm(f => ({ ...f, next: e.target.value }))}
                      className="w-full text-[13.5px] border border-line-2 rounded-lg px-3 py-2 bg-parchment/40 focus:outline-none focus:border-bordo" />
                    {pwMsg && <p className={`text-[12px] ${pwMsg.ok ? 'text-ds-green' : 'text-ds-red'}`}>{pwMsg.text}</p>}
                    <button onClick={changePassword} disabled={pwBusy}
                      className="w-full font-semibold text-[13px] py-2 rounded-lg bg-ink text-white hover:bg-black disabled:opacity-50 border-none cursor-pointer transition-colors">
                      {pwBusy ? 'O\'zgartirilmoqda…' : 'Parolni yangilash'}
                    </button>
                  </div>
                </details>

                {/* Telegram bog'lash — natija, sertifikat (PDF) va yangiliklar botga keladi */}
                <div className="border border-line rounded-lg p-3.5 bg-parchment/40">
                  <div className="flex items-start gap-2.5">
                    <span className="w-8 h-8 flex-none rounded-full bg-bordo/10 text-bordo flex items-center justify-center">
                      <svg viewBox="0 0 24 24" fill="currentColor" style={{ width: 17, height: 17 }}>
                        <path d="M21.94 4.6 18.9 19.3c-.23 1.02-.84 1.27-1.7.79l-4.7-3.46-2.27 2.18c-.25.25-.46.46-.94.46l.33-4.78L18.6 6.1c.38-.34-.08-.53-.6-.19L7.3 12.78l-4.65-1.45c-1.01-.32-1.03-1.01.21-1.5l18.2-7.01c.84-.31 1.58.2 1.31 1.78z" />
                      </svg>
                    </span>
                    <div className="flex-1 min-w-0">
                      <b className="text-[13.5px] text-ink block">Telegram bildirishnomalari</b>
                      <p className="text-[12px] text-muted leading-snug mt-0.5">
                        {tgLinked
                          ? 'Ulangan — test natijasi, sertifikat (PDF) va yangiliklar shaxsan botingizga keladi.'
                          : 'Ulang: test natijasi, sertifikat (PDF) va yangiliklar shaxsan Telegram botingizga keladi.'}
                      </p>
                    </div>
                    {tgLinked && <span className="flex-none text-[11px] font-bold text-ds-green bg-ds-green/10 px-2 py-1 rounded-full">Ulangan</span>}
                  </div>

                  {tgLinked ? (
                    <button onClick={disconnectTelegramFn} disabled={tgBusy}
                      className="mt-2.5 text-[12px] text-ds-red font-semibold hover:underline bg-transparent border-none cursor-pointer disabled:opacity-50">
                      {tgBusy ? 'Uzilmoqda…' : 'Telegramni uzish'}
                    </button>
                  ) : (
                    <div className="mt-2.5 space-y-2">
                      <button onClick={connectTelegram} disabled={tgBusy}
                        className="w-full flex items-center justify-center gap-2 font-semibold text-[13px] py-2 rounded-lg bg-bordo text-white hover:bg-bordo-700 disabled:opacity-50 border-none cursor-pointer transition-colors">
                        {tgBusy ? <><Spinner size={14} /> Ochilmoqda…</> : 'Telegram botni ochish'}
                      </button>
                      {tgHint && (
                        <div className="text-[12px] text-ink-2 bg-parchment rounded-lg px-3 py-2 space-y-1.5">
                          <p>Ochilgan botda <b>Start</b> (yoki <b>/start</b>) tugmasini bosing — hisobingiz bog&apos;lanadi.</p>
                          <button onClick={refreshTgStatus} disabled={tgBusy}
                            className="text-[12px] text-bordo font-semibold hover:underline bg-transparent border-none cursor-pointer disabled:opacity-50">
                            {tgBusy ? 'Tekshirilmoqda…' : "Bog'landim — tekshirish"}
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
              <div className="px-5 py-4 border-t border-line flex gap-2">
                <button onClick={saveProfile} disabled={profileSaving}
                  className="flex-1 font-semibold text-[14px] py-[10px] rounded-lg bg-bordo text-white hover:bg-bordo-700 disabled:opacity-50 border-none cursor-pointer transition-colors">
                  {profileSaving ? <span className="inline-flex items-center gap-2"><Spinner size={16} /> Saqlanmoqda…</span> : 'Saqlash'}
                </button>
                <button onClick={() => setProfileOpen(false)} disabled={profileSaving}
                  className="px-5 font-semibold text-[14px] py-[10px] rounded-lg border border-line-2 text-ink bg-transparent hover:bg-parchment-2 cursor-pointer">Bekor</button>
              </div>
            </div>
          </div>
        )}

        {/* Mobil "Barchasi" pastki menyu (qo'shimcha amallar) */}
        {moreOpen && (
          <div className="lg:hidden fixed inset-0 z-40" onClick={() => setMoreOpen(false)}>
            <div className="absolute inset-0 bg-black/40" />
            <div className="absolute bottom-[64px] left-0 right-0 bg-surface border-t border-line rounded-t-2xl p-2 shadow-[0_-4px_20px_rgba(0,0,0,.12)]" onClick={e => e.stopPropagation()}>
              <div className="w-10 h-1 rounded-full bg-line-2 mx-auto my-2" />
              {/* Til tanlagich (mobil) */}
              <div data-notranslate className="flex items-center gap-2 px-4 py-2">
                <span className="text-[12.5px] font-semibold text-muted">Til:</span>
                <div className="flex items-center gap-[3px] bg-parchment-2 border border-line rounded p-[3px] flex-1">
                  {LOCALES.map(l => (
                    <button key={l} type="button" onClick={() => setLocale(l)}
                      className={`flex-1 text-[12px] font-semibold py-[5px] rounded-sm border-none cursor-pointer transition-colors ${locale === l ? 'bg-surface text-ink shadow-sm' : 'bg-transparent text-muted'}`}>
                      {LOCALE_LABEL[l]}
                    </button>
                  ))}
                </div>
              </div>
              <button type="button" onClick={() => { setMoreOpen(false); openProfile(); }} className="w-full flex items-center gap-3 px-4 py-[13px] rounded-lg text-[14.5px] font-semibold text-ink hover:bg-parchment transition-colors border-none bg-transparent cursor-pointer text-left">
                <span className="w-7 h-7 flex-none rounded-full bg-bordo text-white flex items-center justify-center text-[11px] font-bold">{userInitials}</span>Profil
              </button>
              <button type="button" onClick={() => { setTab('sertifikatlar'); setMoreOpen(false); }} className="w-full flex items-center gap-3 px-4 py-[13px] rounded-lg text-[14.5px] font-semibold text-ink hover:bg-parchment transition-colors border-none bg-transparent cursor-pointer text-left">
                <span className="w-5 h-5 flex-none text-bordo">{Ic.Award}</span>Sertifikatlarim
              </button>
              <a href="/verify" className="flex items-center gap-3 px-4 py-[13px] rounded-lg text-[14.5px] font-semibold text-ink hover:bg-parchment transition-colors">
                <span className="w-5 h-5 flex-none text-bordo">{Ic.QR}</span>Sertifikat tekshirish
              </a>
              <a href="/" className="flex items-center gap-3 px-4 py-[13px] rounded-lg text-[14.5px] font-semibold text-ink hover:bg-parchment transition-colors">
                <span className="w-5 h-5 flex-none text-bordo">{Ic.Home}</span>Sayt bosh sahifasi
              </a>
              <button type="button" onClick={handleLogout}
                className="w-full flex items-center gap-3 px-4 py-[13px] rounded-lg text-[14.5px] font-semibold text-ds-red hover:bg-ds-red-tint transition-colors border-none bg-transparent cursor-pointer text-left">
                <span className="w-5 h-5 flex-none">{Ic.Door}</span>Chiqish
              </button>
            </div>
          </div>
        )}

        {/* Mobil pastki navigatsiya — 4 asosiy + "Barchasi" */}
        <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-surface border-t border-line flex items-stretch shadow-[0_-2px_10px_rgba(0,0,0,.05)]">
          {navItems.slice(0, 4).map(({ id, label, icon }) => {
            const short: Record<string, string> = { dashboard: 'Bosh', olimpiadalar: 'Olimpiada', tolov: "To'lov", natijalar: 'Natija', sertifikatlar: 'Sertifikat', ustoz: 'Ustoz' };
            return (
              <button key={id} type="button" onClick={() => { setTab(id); setMoreOpen(false); }}
                className={`flex-1 flex flex-col items-center justify-center gap-[3px] py-2 border-none bg-transparent cursor-pointer relative ${tab === id && !moreOpen ? 'text-bordo' : 'text-muted'}`}>
                <span className="w-[22px] h-[22px]">{icon}</span>
                <span className="text-[10px] font-semibold leading-none truncate max-w-full px-1">{short[id] ?? label}</span>
                {id === 'tolov' && pendingCount > 0 && <span className="absolute top-[6px] right-[26%] w-2 h-2 rounded-full bg-ds-amber" />}
              </button>
            );
          })}
          {/* 5-tugma: Barchasi */}
          <button type="button" onClick={() => setMoreOpen(v => !v)}
            className={`flex-1 flex flex-col items-center justify-center gap-[3px] py-2 border-none bg-transparent cursor-pointer ${moreOpen ? 'text-bordo' : 'text-muted'}`}>
            <span className="w-[22px] h-[22px] flex items-center justify-center">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/></svg>
            </span>
            <span className="text-[10px] font-semibold leading-none">Barchasi</span>
          </button>
        </nav>
      </main>
    </div>
  );
}
