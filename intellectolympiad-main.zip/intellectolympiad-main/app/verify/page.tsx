'use client';
import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { certificates, BASE, type CertificateVerifyResponse } from '@/lib/api';
import { Spinner } from '@/components/Spinner';
import { fmtDate } from '@/lib/locale';
import { isLoggedIn } from '@/lib/auth';

const DIAMOND = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='60' height='60'%3E%3Cpath d='M30 0L60 30L30 60L0 30Z' fill='none' stroke='%230877B5' stroke-opacity='0.03' stroke-width='1'/%3E%3C/svg%3E")`;

const fmtUzDate = (iso: string) => fmtDate(iso);

const IcShield = ({ size = 32 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z" />
    <path d="M9 12l2 2 4-4" />
  </svg>
);

const IcCheck = ({ size = 26 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 6L9 17l-5-5" />
  </svg>
);

const IcX = ({ size = 26 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
    <line x1="18" y1="6" x2="6" y2="18" />
    <line x1="6" y1="6" x2="18" y2="18" />
  </svg>
);

const IcShieldCheck = ({ size = 18 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z" />
    <path d="M9 12l2 2 4-4" />
  </svg>
);

const IcQr = ({ size = 21 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="7" height="7" />
    <rect x="14" y="3" width="7" height="7" />
    <rect x="3" y="14" width="7" height="7" />
    <rect x="14" y="14" width="7" height="7" />
  </svg>
);

const IcId = ({ size = 21 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 7V5a1 1 0 0 1 1-1h2M4 17v2a1 1 0 0 0 1 1h2M20 7V5a1 1 0 0 0-1-1h-2M20 17v2a1 1 0 0 1-1 1h-2" />
    <line x1="8" y1="12" x2="16" y2="12" />
  </svg>
);

type State =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'valid'; data: Extract<CertificateVerifyResponse, { valid: true }> }
  | { status: 'revoked'; data: Extract<CertificateVerifyResponse, { revoked: true }> }
  | { status: 'invalid' }
  | { status: 'error'; message: string };

export default function VerifyPageWrapper() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center bg-parchment p-6">
        <div className="text-center anim-fade-up">
          <div className="anim-float mb-4 inline-block">
            <img src="/logo-mark.svg" alt="IO" className="w-14 h-14" />
          </div>
          <div className="text-muted text-[14px] timer-pulse">Yuklanmoqda…</div>
        </div>
      </div>
    }>
      <VerifyPage />
    </Suspense>
  );
}

function VerifyPage() {
  const sp = useSearchParams();
  const initialCode = sp.get('code') ?? '';
  const [certId, setCertId] = useState(initialCode);
  const [state, setState] = useState<State>({ status: 'idle' });
  const [loggedIn, setLoggedIn] = useState(false);
  useEffect(() => { setLoggedIn(isLoggedIn()); }, []);

  const check = async (codeOverride?: string) => {
    const v = (codeOverride ?? certId).trim().toUpperCase();
    if (!v) return;
    setState({ status: 'loading' });
    try {
      const res = await certificates.verify(v);
      if (res.valid) setState({ status: 'valid', data: res });
      else if ('revoked' in res && res.revoked) setState({ status: 'revoked', data: res });
      else setState({ status: 'invalid' });
    } catch (err: unknown) {
      setState({ status: 'error', message: err instanceof Error ? err.message : 'Xatolik yuz berdi' });
    }
  };

  // Auto-check if code came from URL
  useEffect(() => {
    if (initialCode) check(initialCode);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialCode]);

  const reset = () => { setState({ status: 'idle' }); setCertId(''); };

  return (
    <div className="min-h-screen bg-parchment">
      {/* Header */}
      <header className="bg-surface border-b border-line">
        <div className="max-w-wrap mx-auto px-6 flex items-center justify-between min-h-[64px] gap-4">
          <a href="/" className="flex items-center gap-2 sm:gap-3 flex-none">
            <img src="/logo-mark.svg" alt="IO" className="w-10 h-10 flex-none" />
            <div className="hidden sm:flex flex-col leading-[1.05]">
              <b className="font-serif font-semibold text-sm text-ink">Intellect Olympiad</b>
              <small className="text-muted" style={{ fontSize: 10.5, letterSpacing: '.12em', textTransform: 'uppercase' }}>Olimpiada xizmati</small>
            </div>
          </a>

          {/* Orqaga — kirgan bo'lsa Kabinetga, aks holda Bosh sahifa (mobil) */}
          <a href={loggedIn ? '/cabinet' : '/'} className="md:hidden inline-flex items-center gap-1.5 text-[13px] font-semibold text-ink-2 bg-surface border border-line-2 rounded-lg px-3 py-2 hover:border-bordo hover:text-bordo transition-colors flex-none mr-auto whitespace-nowrap">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="flex-none"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>
            {loggedIn ? 'Kabinet' : 'Bosh sahifa'}
          </a>

          {loggedIn ? (
            /* Kirgan foydalanuvchi — kabinet konteksti (public nav/registratsiya yo'q) */
            <a href="/cabinet" className="hidden md:inline-flex items-center gap-1.5 ml-auto text-[13.5px] font-semibold text-ink-2 bg-surface border border-line-2 rounded-lg px-4 py-2 hover:border-bordo hover:text-bordo transition-colors">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="flex-none"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>
              Kabinetga qaytish
            </a>
          ) : (
            <>
              <nav className="hidden md:flex items-center gap-5 text-[13.5px] font-semibold">
                <a href="/" className="text-ink-2 hover:text-ink transition-colors">Bosh sahifa</a>
                <a href="/news" className="text-ink-2 hover:text-ink transition-colors">Yangiliklar</a>
                <a href="/verify" className="text-bordo">Sertifikat tekshirish</a>
              </nav>
              <div className="flex items-center gap-2">
                <a href="/login" className="text-[13px] text-ink-2 hover:text-ink transition-colors hidden md:block">Kirish</a>
                <a href="/login" className="font-semibold text-[13px] px-4 py-[7px] rounded bg-bordo text-white hover:bg-bordo-700 transition-colors">
                  Ro&apos;yxatdan o&apos;tish
                </a>
              </div>
            </>
          )}
        </div>
      </header>

      {/* Hero / Search */}
      <section className="relative overflow-hidden border-b border-line py-[56px] pb-[48px] px-6"
        style={{ background: 'linear-gradient(180deg, #ffffff, #f2f5f8)' }}>
        <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: DIAMOND }} />
        <div className="relative max-w-[640px] mx-auto text-center">
          <div className="w-[74px] h-[74px] rounded-full bg-gradient-to-br from-bordo to-bordo-900 text-white flex items-center justify-center mx-auto mb-5 shadow-lg ring-4 ring-gold/20">
            <IcShield size={34} />
          </div>
          <div className="text-[11px] tracking-[.16em] uppercase text-gold font-bold mb-2">Rasmiy tasdiq</div>
          <h1 className="font-serif font-semibold text-ink" style={{ fontSize: 'clamp(28px,4vw,38px)' }}>Sertifikatni tekshirish</h1>
          <p className="text-ink-2 mt-3 text-[16px] leading-relaxed">
            Sertifikat ID raqamini kiriting yoki QR-kodni skanerlang. Tizim haqiqiyligini soniyalarda tasdiqlaydi.
          </p>

          <div className="mt-7 flex flex-col sm:flex-row gap-2 sm:gap-[10px] max-w-[500px] mx-auto">
            <input
              type="text"
              value={certId}
              onChange={e => setCertId(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && check()}
              placeholder="IO-2026-XXXXXXX"
              disabled={state.status === 'loading'}
              className="flex-1 font-mono text-[15px] sm:text-[16px] text-center tracking-[.05em] px-4 py-[14px] rounded-lg border border-line-2 bg-surface focus:outline-none focus:border-bordo focus:shadow-[0_0_0_3px_#e3f1f9] transition-all disabled:opacity-60 placeholder:tracking-normal placeholder:text-muted/60"
            />
            <button onClick={() => check()}
              disabled={state.status === 'loading' || !certId.trim()}
              className="font-semibold text-[15px] px-7 py-[14px] rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors border-none cursor-pointer whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed shadow-sm">
              {state.status === 'loading' ? <span className="inline-flex items-center gap-2"><Spinner size={16} /> Tekshirilmoqda...</span> : 'Tekshirish'}
            </button>
          </div>
          <p className="mt-3 text-[13px] text-muted">
            Format: <b>IO-YYYY-XXXXXXX</b> · Sinab ko&apos;rish uchun namuna:{' '}
            <button type="button" onClick={() => { setCertId('IO-2026-0007788'); check('IO-2026-0007788'); }}
              className="font-mono font-semibold text-bordo hover:underline bg-transparent border-none cursor-pointer p-0">
              IO-2026-0007788
            </button>
          </p>
        </div>
      </section>

      {/* Result */}
      <section className="py-[44px] pb-[64px] px-6">
        <div className="max-w-[720px] mx-auto">

          {state.status === 'loading' && (
            <div className="text-center anim-fade-up py-10">
              <div className="anim-float mb-4 inline-block">
                <img src="/logo-mark.svg" alt="IO" className="w-14 h-14" />
              </div>
              <div className="text-muted text-[14px] timer-pulse">Yuklanmoqda…</div>
            </div>
          )}

          {state.status === 'valid' && (() => {
            const d = state.data;
            return (
            <div className="anim-fade-up">
              {/* Verdict badge */}
              <div className="flex items-center gap-3 bg-ds-green-tint border border-[#cfe5d8] text-ds-green rounded-lg px-5 py-[14px] mb-5">
                <span className="w-9 h-9 rounded-full bg-ds-green text-white grid place-items-center flex-none anim-pop"><IcCheck size={20} /></span>
                <div className="leading-tight">
                  <b className="text-[15.5px] block">Sertifikat haqiqiy</b>
                  <span className="text-[13px] opacity-90">Intellect Olympiad tomonidan rasmiy berilgan va amal qiladi.</span>
                </div>
              </div>

              {/* ── Full certificate (asl PDF dizayniga mos, landscape) ── */}
              <div className="relative bg-gradient-to-br from-[#fbfdff] to-[#f4ecdf] border-[3px] border-bordo/25 rounded-lg p-2 shadow-md">
                <div className="relative border border-[rgba(154,123,63,.45)] rounded p-6 sm:p-9 overflow-hidden">
                  {/* IO watermark */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
                    <span className="font-serif font-bold text-[110px] sm:text-[180px] md:text-[230px] text-bordo/[.04] leading-none">IO</span>
                  </div>
                  <div className="relative text-center">
                    <img src="/logo-mark.svg" alt="Intellect Olympiad" className="w-[54px] h-[54px] mx-auto" />
                    <div className="text-[11px] tracking-[.22em] uppercase text-gold font-bold mt-2">Intellect Olympiad</div>
                    <h2 className="font-serif text-[26px] sm:text-[34px] font-bold text-bordo tracking-[.05em] mt-1">SERTIFIKAT</h2>
                    <p className="text-[12px] text-muted mt-3">Ushbu sertifikat quyidagi shaxsga taqdim etiladi</p>
                    <div className="font-serif text-[24px] sm:text-[30px] font-bold text-ink mt-2">{d.holder}</div>
                    <div className="w-[130px] h-[2px] bg-gradient-to-r from-transparent via-bordo to-transparent mx-auto mt-3" />
                    <p className="text-[13px] text-ink-2 mt-4 max-w-[500px] mx-auto leading-relaxed">
                      {d.year}-yil <b>{d.olympiad}</b> onlayn olimpiadasida <b>{d.score} ball</b> to&apos;plab muvaffaqiyatli ishtirok etgani uchun beriladi.
                    </p>
                    {/* Bottom row: signature | QR | score+code */}
                    <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-end sm:justify-between sm:gap-3 mt-8">
                      <div className="flex-1 text-center sm:text-left">
                        <div className="font-serif text-[14px] text-ink">Agzamova X. M.</div>
                        <div className="w-[110px] max-w-full h-px bg-ink-2/40 mt-[6px] mx-auto sm:mx-0" />
                        <div className="text-[10.5px] text-muted mt-[5px]">Direktor · {fmtUzDate(d.issuedAt)}</div>
                      </div>
                      <div className="flex-none">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={`${BASE}/certificates/${encodeURIComponent(d.certCode)}/qr`}
                          alt={`Sertifikat ${d.certCode} QR-kodi`}
                          className="w-[64px] h-[64px] rounded border border-line-2 bg-white p-[3px]" />
                      </div>
                      <div className="flex-1 text-center sm:text-right">
                        <div className="font-serif font-bold text-[30px] text-bordo leading-none">{d.score}<span className="text-[15px] text-muted font-normal"> ball</span></div>
                        <div className="font-mono text-[11px] font-semibold text-bordo mt-[6px]">{d.certCode}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* ── Parameters below ── */}
              <div className="bg-surface border border-line rounded-lg p-6 mt-4">
                <div className="text-[12px] uppercase tracking-[.08em] text-muted font-bold mb-2">Tafsilotlar</div>
                {([
                  { l: 'Sertifikat egasi', v: <b className="text-ink">{d.holder}</b> },
                  { l: 'Olimpiada', v: `${d.olympiad} (${d.year})` },
                  { l: 'Natija', v: <span className="font-mono">{d.score} ball</span> },
                  { l: 'Sertifikat ID', v: <span className="font-mono font-semibold text-bordo">{d.certCode}</span> },
                  { l: 'Raqamli imzo', v: (
                    <span className="inline-flex items-center gap-1 bg-ds-green-tint text-ds-green text-[11px] font-bold px-2 py-[2px] rounded-full">
                      <span className="w-[5px] h-[5px] rounded-full bg-ds-green" />TASDIQLANGAN
                    </span>
                  ) },
                  { l: 'Holat', v: (
                    <span className="inline-flex items-center gap-1 bg-ds-green-tint text-ds-green text-[12px] font-bold px-2 py-[3px] rounded-full">
                      <span className="w-[5px] h-[5px] rounded-full bg-ds-green" />Faol
                    </span>
                  ) },
                ] as { l: string; v: React.ReactNode }[]).map((row, i) => (
                  <div key={i} className="flex justify-between gap-2 sm:gap-4 py-[12px] border-b border-line last:border-0 text-[14px]">
                    <span className="text-muted flex-none">{row.l}</span>
                    <span className="font-semibold text-right min-w-0 break-words">{row.v}</span>
                  </div>
                ))}

                <div className="flex gap-3 items-start bg-ds-green-tint border border-[#cfe5d8] rounded p-[14px_16px] mt-5 text-[13.5px] text-ds-green">
                  <span className="flex-none mt-[1px]"><IcShieldCheck /></span>
                  Ushbu yozuv platforma ma&apos;lumotlar bazasi bilan tasdiqlangan. Soxtalashtirishdan himoyalangan.
                </div>

                {d.pdfUrl && (
                  <div className="mt-3">
                    <a href={d.pdfUrl} target="_blank" rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 font-semibold text-[14px] px-5 py-[10px] rounded border border-line-2 bg-transparent text-ink hover:bg-parchment-2 transition-colors cursor-pointer">
                      Sertifikat PDF&apos;ini ko&apos;rish
                    </a>
                  </div>
                )}
              </div>

              <button onClick={reset}
                className="mt-4 inline-flex items-center gap-2 font-semibold text-[14px] px-5 py-[10px] rounded border border-line-2 bg-transparent text-ink hover:bg-parchment-2 transition-colors cursor-pointer">
                Yangi tekshirish
              </button>
            </div>
            );
          })()}

          {state.status === 'revoked' && (
            <div className="anim-fade-up">
              <div className="bg-surface border border-line rounded-lg rounded-b-none p-7 sm:p-9 text-center">
                <div className="relative w-[72px] h-[72px] mx-auto mb-5">
                  <span className="absolute inset-0 rounded-full anim-ring bg-ds-amber/30" />
                  <span className="absolute inset-0 rounded-full anim-ring bg-ds-amber/25" style={{ animationDelay: '.7s' }} />
                  <div className="relative w-[72px] h-[72px] rounded-full flex items-center justify-center anim-pop bg-ds-amber text-white">
                    <IcX size={30} />
                  </div>
                </div>
                <h2 className="font-serif text-[21px] font-semibold text-ink anim-fade-up" style={{ animationDelay: '.08s' }}>Sertifikat bekor qilingan</h2>
                <p className="text-[14px] text-muted mt-[6px] anim-fade-up" style={{ animationDelay: '.14s' }}>Ushbu sertifikat administrator tomonidan bekor qilingan.</p>
              </div>
              <div className="bg-surface border border-line border-t-0 rounded-b-lg p-5 sm:p-[30px_32px]">
                <div className="space-y-3 text-[14px]">
                  <div className="flex justify-between gap-2 sm:gap-4 py-[10px] border-b border-line">
                    <span className="text-muted flex-none">Sertifikat egasi</span>
                    <b className="text-ink text-right min-w-0 break-words">{state.data.holder}</b>
                  </div>
                  <div className="flex justify-between gap-2 sm:gap-4 py-[10px] border-b border-line">
                    <span className="text-muted flex-none">Sertifikat ID</span>
                    <span className="font-mono font-semibold text-bordo text-right min-w-0 break-words">{state.data.certCode}</span>
                  </div>
                  {state.data.revokedAt && (
                    <div className="flex justify-between gap-2 sm:gap-4 py-[10px] border-b border-line">
                      <span className="text-muted">Bekor qilingan sana</span>
                      <span className="font-semibold">{fmtUzDate(state.data.revokedAt)}</span>
                    </div>
                  )}
                  {state.data.revokedReason && (
                    <div className="py-[10px]">
                      <div className="text-muted mb-1">Sabab</div>
                      <div className="text-ink font-semibold bg-ds-amber-tint border border-ds-amber/30 rounded px-3 py-2">{state.data.revokedReason}</div>
                    </div>
                  )}
                </div>
              </div>
              <button onClick={reset}
                className="mt-4 inline-flex items-center gap-2 font-semibold text-[14px] px-5 py-[10px] rounded border border-line-2 bg-transparent text-ink hover:bg-parchment-2 transition-colors cursor-pointer">
                Yangi tekshirish
              </button>
            </div>
          )}

          {state.status === 'invalid' && (
            <div className="max-w-[440px] mx-auto bg-surface border border-line rounded-2xl p-8 sm:p-10 text-center shadow-sm anim-fade-up">
              <div className="relative w-[72px] h-[72px] mx-auto mb-5">
                <span className="absolute inset-0 rounded-full anim-ring bg-ds-red/30" />
                <span className="absolute inset-0 rounded-full anim-ring bg-ds-red/25" style={{ animationDelay: '.7s' }} />
                <div className="relative w-[72px] h-[72px] rounded-full flex items-center justify-center anim-pop bg-ds-red-tint text-ds-red">
                  <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10" />
                    <line x1="15" y1="9" x2="9" y2="15" />
                    <line x1="9" y1="9" x2="15" y2="15" />
                  </svg>
                </div>
              </div>
              <h2 className="font-serif text-[21px] font-semibold text-ink mb-2 anim-fade-up" style={{ animationDelay: '.08s' }}>Sertifikat topilmadi</h2>
              <p className="text-[14px] text-muted mb-6 leading-relaxed anim-fade-up" style={{ animationDelay: '.14s' }}>
                Kiritilgan ID bo&apos;yicha hech qanday yozuv mavjud emas. Iltimos, ID raqamni qayta tekshiring. Sertifikatdagi ID <b>IO-YYYY-XXXXXXX</b> formatida bo&apos;ladi.
              </p>
              <div className="anim-fade-up flex flex-wrap items-center justify-center gap-3" style={{ animationDelay: '.2s' }}>
                <button onClick={reset}
                  className="font-semibold text-[14px] px-6 py-[11px] rounded-lg bg-bordo text-white hover:bg-bordo-700 border-none cursor-pointer transition-colors">
                  Qaytadan urinish
                </button>
                <a href="/"
                  className="font-semibold text-[14px] px-6 py-[11px] rounded-lg border border-line-2 bg-transparent text-ink hover:bg-parchment-2 transition-colors cursor-pointer">
                  Bosh sahifa
                </a>
              </div>
            </div>
          )}

          {state.status === 'error' && (
            <div className="bg-surface border border-ds-red-tint rounded-lg p-6">
              <h2 className="font-serif text-[18px] font-semibold text-ds-red mb-2">Xatolik</h2>
              <p className="text-[13.5px] text-muted mb-4">{state.message}</p>
              <button onClick={reset}
                className="font-semibold text-[14px] px-5 py-[10px] rounded border border-line-2 bg-transparent text-ink hover:bg-parchment-2 transition-colors cursor-pointer">
                Qayta urinish
              </button>
            </div>
          )}

          {state.status === 'idle' && (
            <div className="mt-10">
              <div className="text-center">
                <span className="text-[11px] tracking-[.12em] uppercase text-muted font-bold">Qanday tekshiriladi</span>
                <h2 className="font-serif text-[24px] font-semibold text-ink mt-2">Uch xil usul</h2>
              </div>
              <div className="grid sm:grid-cols-3 gap-4 mt-[18px]">
                {[
                  { Icon: IcQr, title: 'QR-kod orqali', desc: 'Sertifikatdagi QR-kodni telefon kamerasi bilan skanerlang.' },
                  { Icon: IcId, title: 'ID raqami orqali', desc: 'Yuqoridagi maydonga sertifikat ID raqamini kiriting.' },
                  { Icon: IcShield, title: 'Rasmiy tasdiq', desc: "Natija to'g'ridan-to'g'ri platforma bazasidan olinadi." },
                ].map(({ Icon, title, desc }, i) => (
                  <div key={i} className="bg-surface border border-line rounded-lg p-4 sm:p-5 text-center shadow-sm">
                    <div className="w-[42px] h-[42px] rounded-[10px] bg-bordo-tint text-bordo flex items-center justify-center mx-auto mb-3">
                      <Icon size={21} />
                    </div>
                    <b className="text-[14.5px] block mb-1">{title}</b>
                    <p className="text-[13px] text-ink-2">{desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
