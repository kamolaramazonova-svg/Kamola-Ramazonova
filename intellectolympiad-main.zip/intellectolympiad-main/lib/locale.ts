'use client';
import { useEffect, useState } from 'react';

// Platforma 4 tili. Kalit — API/kontent locale qiymatlari bilan bir xil.
export const LOCALES = ['uz-Latn', 'uz-Cyrl', 'ru', 'en'] as const;
export type Locale = (typeof LOCALES)[number];
export const DEFAULT_LOCALE: Locale = 'uz-Latn';

export const LOCALE_LABEL: Record<Locale, string> = {
  'uz-Latn': "O'z",
  'uz-Cyrl': 'Ўз',
  ru: 'Ру',
  en: 'En',
};
export const LOCALE_FULL: Record<Locale, string> = {
  'uz-Latn': "O'zbekcha",
  'uz-Cyrl': 'Ўзбекча (кирилл)',
  ru: 'Русский',
  en: 'English',
};

const KEY = 'io_locale';

// ── Til-bog'liq sana formatlash ──────────────────────────────────────────────
// uz-UZ lokal ICU ba'zi brauzerlarda oyni "M12" qiladi, ru/en uchun esa oy
// o'zbekcha qolib ketadi — shuning uchun har til uchun qo'lda oy nomlari.
const DATE_MONTHS: Record<Locale, string[]> = {
  'uz-Latn': ['yanvar', 'fevral', 'mart', 'aprel', 'may', 'iyun', 'iyul', 'avgust', 'sentyabr', 'oktyabr', 'noyabr', 'dekabr'],
  'uz-Cyrl': ['январ', 'феврал', 'март', 'апрел', 'май', 'июн', 'июл', 'август', 'сентябр', 'октябр', 'ноябр', 'декабр'],
  ru: ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'],
  en: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
};

/** Joriy (yoki berilgan) tilga mos sana. Vaqt bilan: { time: true }. */
export function fmtDate(iso: string | null, opts?: { time?: boolean; locale?: Locale }): string {
  const loc = opts?.locale ?? getLocale();
  const d = new Date(iso ?? Date.now());
  const TZ = 'Asia/Tashkent';
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: 'numeric', day: 'numeric' }).formatToParts(d);
  const g = (t: string) => Number(parts.find(p => p.type === t)?.value ?? 0);
  const day = g('day'), mon = DATE_MONTHS[loc][g('month') - 1], year = g('year');

  let base: string;
  if (loc === 'ru') base = `${day} ${mon} ${year}`;            // 11 июня 2026
  else if (loc === 'en') base = `${mon} ${day}, ${year}`;      // June 11, 2026
  else base = `${day}-${mon}, ${year}`;                        // 11-iyun / 11-июн, 2026

  if (opts?.time) {
    const time = d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', timeZone: TZ });
    base += loc === 'en' ? ` ${time}` : `, ${time}`;
  }
  return base;
}

/** Joriy (yoki berilgan) tilga mos oy nomi (0-indeksli). */
export function localeMonth(monthIdx0: number, locale?: Locale): string {
  return DATE_MONTHS[locale ?? getLocale()][monthIdx0] ?? '';
}

export function getLocale(): Locale {
  if (typeof window === 'undefined') return DEFAULT_LOCALE;
  const v = window.localStorage.getItem(KEY);
  return (LOCALES as readonly string[]).includes(v ?? '') ? (v as Locale) : DEFAULT_LOCALE;
}

export function setLocale(l: Locale) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(KEY, l);
  window.dispatchEvent(new CustomEvent('io-locale', { detail: l }));
}

/** Joriy locale'ni kuzatuvchi hook — almashtirilganda komponentlar yangilanadi. */
export function useLocale(): [Locale, (l: Locale) => void] {
  const [loc, setLoc] = useState<Locale>(DEFAULT_LOCALE);
  useEffect(() => {
    setLoc(getLocale());
    const onChange = (e: Event) => setLoc((e as CustomEvent<Locale>).detail ?? getLocale());
    const onStorage = (e: StorageEvent) => { if (e.key === KEY) setLoc(getLocale()); };
    window.addEventListener('io-locale', onChange);
    window.addEventListener('storage', onStorage);
    return () => { window.removeEventListener('io-locale', onChange); window.removeEventListener('storage', onStorage); };
  }, []);
  return [loc, setLocale];
}
