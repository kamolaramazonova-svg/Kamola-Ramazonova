// O'zbek lotin → kirill transliteratsiyasi (mijoz tomonida, oniy, bepul).
// API tomonidagi transliterate.ts bilan bir xil mantiq.

const SINGLES: Record<string, string> = {
  a: 'а', b: 'б', c: 'с', d: 'д', e: 'е', f: 'ф', g: 'г', h: 'ҳ',
  i: 'и', j: 'ж', k: 'к', l: 'л', m: 'м', n: 'н', o: 'о', p: 'п',
  q: 'қ', r: 'р', s: 'с', t: 'т', u: 'у', v: 'в', w: 'в', x: 'х',
  y: 'й', z: 'з',
};
const DIGRAPHS: Record<string, string> = {
  sh: 'ш', ch: 'ч', yo: 'ё', yu: 'ю', ya: 'я', ye: 'е', ts: 'ц',
};
const isLatinLetter = (c: string) => /[a-zA-Z']/.test(c);
const applyCase = (up: boolean, cyr: string) => (up ? cyr.toUpperCase() : cyr);

export function latnToCyrl(input: string): string {
  if (!input) return input;
  const text = input.replace(/[ʻʼ‘’`´']/g, "'");
  let out = '';
  let i = 0;
  while (i < text.length) {
    const ch = text[i];
    const lower = ch.toLowerCase();
    const upper = ch !== lower && /[A-Z]/.test(ch);
    const two = text.slice(i, i + 2).toLowerCase();
    if (two === "o'") { out += applyCase(upper, 'ў'); i += 2; continue; }
    if (two === "g'") { out += applyCase(upper, 'ғ'); i += 2; continue; }
    if (DIGRAPHS[two]) { out += applyCase(upper, DIGRAPHS[two]); i += 2; continue; }
    if (lower === 'e') {
      const atStart = i === 0 || !isLatinLetter(text[i - 1]);
      out += applyCase(upper, atStart ? 'э' : 'е'); i += 1; continue;
    }
    if (ch === "'") { out += 'ъ'; i += 1; continue; }
    if (SINGLES[lower]) { out += upper ? SINGLES[lower].toUpperCase() : SINGLES[lower]; i += 1; continue; }
    out += ch; i += 1;
  }
  return out;
}
