'use client';
import { io, Socket } from 'socket.io-client';

const RAW_API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000/api/v1';
// Strip /api/v1 suffix for socket.io host
const SOCKET_HOST = RAW_API.replace(/\/api\/v\d+\/?$/, '');

export interface TimerTickEvent {
  remainingSec: number;
}

export interface ExamExpiredEvent {
  sessionId: string;
}

export interface ExamStoppedEvent {
  reason: string;
}

export interface ExamKickedEvent {
  reason: string;
}

export interface ExamSocketHandlers {
  onTick?: (e: TimerTickEvent) => void;
  onExpired?: (e: ExamExpiredEvent) => void;
  onStopped?: (e: ExamStoppedEvent) => void;
  onKicked?: (e: ExamKickedEvent) => void;
  onConnect?: () => void;
  onDisconnect?: (reason: string) => void;
}

export function connectExamSocket(
  token: string,
  sessionId: string,
  handlers: ExamSocketHandlers,
): Socket {
  const socket = io(`${SOCKET_HOST}/exams`, {
    transports: ['websocket', 'polling'],
    auth: { token },
    reconnection: true,
    reconnectionDelay: 1000,
    reconnectionDelayMax: 5000,
  });

  socket.on('connect', () => {
    socket.emit('exam:join', { sessionId }, (_ack: unknown) => {
      // ack ignored; rely on events
    });
    handlers.onConnect?.();
  });

  socket.on('disconnect', (reason: string) => {
    handlers.onDisconnect?.(reason);
  });

  if (handlers.onTick) socket.on('timer:tick', handlers.onTick);
  if (handlers.onExpired) socket.on('exam:expired', handlers.onExpired);
  if (handlers.onStopped) socket.on('exam:stopped', handlers.onStopped);
  if (handlers.onKicked) socket.on('exam:kicked', handlers.onKicked);

  return socket;
}

export function reportAntiCheat(
  socket: Socket,
  sessionId: string,
  type: 'focus-loss' | 'tab-switch' | 'network-drop' | 'fullscreen-exit' | 'copy-paste' | 'context-menu' | 'devtools-key' | 'print',
  meta?: Record<string, unknown>,
) {
  socket.emit('exam:anti-cheat', { sessionId, type, meta });
}
