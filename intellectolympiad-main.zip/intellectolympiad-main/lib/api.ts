// API manzili:
//   1) NEXT_PUBLIC_API_URL env bo'lsa — o'sha (override).
//   2) localhost / LAN IP — o'sha host:4000 (lokal dev).
//   3) aks holda (prod domen, SSR) — production API (standart, env shart emas).
const PROD_API = 'https://api.intellectolympiad.uz/api/v1';
function resolveBase(): string {
  if (process.env.NEXT_PUBLIC_API_URL) return process.env.NEXT_PUBLIC_API_URL;
  if (typeof window !== 'undefined') {
    const { protocol, hostname } = window.location;
    if (hostname === 'localhost' || hostname === '127.0.0.1' || /^\d{1,3}(\.\d{1,3}){3}$/.test(hostname)) {
      return `${protocol}//${hostname}:4000/api/v1`;
    }
  }
  return PROD_API;
}

export const BASE = resolveBase();

type ApiResponse<T> = { data: T; meta?: unknown; error?: string };

class ApiError extends Error {
  constructor(
    public statusCode: number,
    message: string,
  ) {
    super(message);
  }
}

// Barqaror qurilma identifikatori (bitta-qurilma imtihon qulfi uchun) — localStorage'da saqlanadi
function deviceId(): string {
  if (typeof window === 'undefined') return '';
  try {
    let id = window.localStorage.getItem('io_device');
    if (!id) {
      id = (typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2)) + Date.now().toString(36);
      window.localStorage.setItem('io_device', id);
    }
    return id;
  } catch { return ''; }
}

// Access token muddati tugaganda (15 daqiqa) — refresh_token cookie orqali
// yangilab, so'rovni bir marta qayta urinamiz. Bir vaqtda faqat bitta refresh
// ishlaydi (storm bo'lmasin).
let refreshing: Promise<string | null> | null = null;
async function tryRefresh(): Promise<string | null> {
  if (typeof window === 'undefined') return null;
  if (!refreshing) {
    refreshing = (async () => {
      try {
        const res = await fetch(`${BASE}/auth/refresh`, { method: 'POST', credentials: 'include' });
        if (!res.ok) return null;
        const data = await res.json();
        if (data?.accessToken) {
          localStorage.setItem('io_access_token', data.accessToken);
          if (data.user) localStorage.setItem('io_user', JSON.stringify(data.user));
          return data.accessToken as string;
        }
        return null;
      } catch {
        return null;
      }
    })();
    refreshing.finally(() => { refreshing = null; });
  }
  return refreshing;
}

const AUTH_PATHS = ['/auth/login', '/auth/register', '/auth/refresh', '/auth/google', '/auth/telegram', '/auth/logout'];

async function request<T>(
  path: string,
  options: RequestInit & { token?: string } = {},
  _retried = false,
  _throttleRetry = 0,
): Promise<T> {
  const { token, ...init } = options;
  // Content-Type faqat body bor bo'lsa — aks holda Fastify "Body cannot be empty" beradi
  // (masalan PATCH /exams/:id/finish — bodysiz so'rov).
  const headers: Record<string, string> = {
    ...(init.body != null ? { 'Content-Type': 'application/json' } : {}),
    ...(init.headers as Record<string, string>),
  };
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const dev = deviceId();
  if (dev) headers['x-device-fp'] = dev;
  // Ilova tilini har so'rovga qo'shamiz — dinamik kontent (olimpiada/yangilik
  // nomlari) brauzer Accept-Language emas, ilova tanlagan til bilan kelsin.
  if (typeof window !== 'undefined') {
    try {
      // tanlanmagan bo'lsa — standart uz-Latn (brauzer tiliga tushib qolmasin)
      headers['x-locale'] = window.localStorage.getItem('io_locale') || 'uz-Latn';
    } catch { /* ignore */ }
  }

  const res = await fetch(`${BASE}${path}`, {
    ...init,
    headers,
    credentials: 'include',
  });

  // Token eskirgan bo'lsa — bir marta yangilab qayta urinamiz
  if (res.status === 401 && !_retried && !AUTH_PATHS.some(a => path.startsWith(a))) {
    const newToken = await tryRefresh();
    if (newToken) {
      return request<T>(path, { ...options, token: newToken }, true);
    }
    // Yangilash imkonsiz — sessiya tugagan, login'ga yo'naltiramiz
    if (typeof window !== 'undefined') {
      localStorage.removeItem('io_access_token');
      localStorage.removeItem('io_user');
      const next = encodeURIComponent(window.location.pathname + window.location.search);
      window.location.href = `/login?expired=1&next=${next}`;
    }
    throw new ApiError(401, 'Sessiya muddati tugadi — qaytadan kiring');
  }

  // 429 (rate-limit) — maktab NAT'ida ko'p o'quvchi bir vaqtda so'rov yuborsa
  // (ayniqsa login spike). Qisqa backoff + jitter bilan avtomatik qayta urinamiz,
  // o'quvchi qo'lda qayta bosishga majbur bo'lmasin. Maks 3 marta.
  if (res.status === 429 && _throttleRetry < 3) {
    const retryAfter = Number(res.headers.get('retry-after'));
    const delay = Number.isFinite(retryAfter) && retryAfter > 0
      ? retryAfter * 1000
      : 400 * 2 ** _throttleRetry + Math.floor(Math.random() * 300);
    await new Promise((r) => setTimeout(r, delay));
    return request<T>(path, options, _retried, _throttleRetry + 1);
  }

  const json = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new ApiError(res.status, json.message ?? 'Request failed');
  }
  return json as T;
}

// ─── Auth ────────────────────────────────────────────────────────────────────

export interface LoginResponse {
  user: User;
  accessToken: string;
}

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  status: string;
  phone: string | null;
  grade: number | null;
  school: string | null;
  region: string | null;
  avatarUrl: string | null;
  isVerified: boolean;
  telegramId?: string | null;
}

export const auth = {
  login: (email: string, password: string) =>
    request<LoginResponse>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  register: (data: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    phone?: string;
    grade?: string; // Grade enum, e.g. 'GRADE_10'
    school?: string;
    region?: string;
    district?: string;
    parentPhone?: string;
    passport?: string;
    ref?: string;        // ustoz referal kodi
    asTeacher?: boolean; // ustoz sifatida ro'yxatdan o'tish
  }) =>
    request<LoginResponse>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  telegramVerify: (code: string) =>
    request<LoginResponse>('/auth/telegram/verify', {
      method: 'POST',
      body: JSON.stringify({ code }),
    }),

  google: (idToken: string) =>
    request<LoginResponse>('/auth/google', {
      method: 'POST',
      body: JSON.stringify({ idToken }),
    }),

  me: (token: string) => request<User>('/auth/me', { token }),

  logout: (token: string) =>
    request<void>('/auth/logout', { method: 'POST', token }),

  refresh: () => request<LoginResponse>('/auth/refresh', { method: 'POST' }),
};

// ─── Payments ────────────────────────────────────────────────────────────────

export interface Payment {
  id: string;
  amountUzs: number;
  status: string;
  paymentCode: string | null;
  receiptUrl: string | null;
  registrationId: string;
  approvedAt: string | null;
  rejectionReason: string | null;
  createdAt: string;
  registration?: {
    olympiad: { id: string; title: string; startsAt: string; status: string };
  } | null;
}

export const payments = {
  create: (token: string, olympiadId: string, amountUzs: number) =>
    request<Payment>('/payments', {
      method: 'POST',
      token,
      body: JSON.stringify({ olympiadId, amountUzs }),
    }),

  // Click to'lovini boshlaydi — to'lov yaratadi va my.click.uz yo'naltirish havolasini qaytaradi.
  clickStart: (token: string, olympiadId: string, amountUzs: number) =>
    request<{ paymentId: string; amountUzs: number; url: string }>('/payments/click/start', {
      method: 'POST',
      token,
      body: JSON.stringify({ olympiadId, amountUzs }),
    }),

  myPayments: (token: string) =>
    request<Payment[]>('/payments/my', { token }),

  uploadReceipt: (token: string, paymentId: string, receiptUrl: string) =>
    request<Payment>(`/payments/${paymentId}/receipt`, {
      method: 'PATCH',
      token,
      body: JSON.stringify({ receiptUrl }),
    }),

  uploadReceiptFile: async (token: string, paymentId: string, file: File): Promise<Payment> => {
    const fd = new FormData();
    fd.append('file', file);
    const res = await fetch(`${BASE}/payments/${paymentId}/receipt-upload`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: fd,
      credentials: 'include',
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new ApiError(res.status, json.message ?? 'Upload failed');
    return json as Payment;
  },

  // Admin
  list: (token: string, status?: string) =>
    request<{ data: Payment[]; total: number }>(
      `/payments${status ? `?status=${status}` : ''}`,
      { token },
    ),

  approve: (token: string, paymentId: string, transactionId?: string) =>
    request<Payment>(`/payments/${paymentId}/approve`, {
      method: 'PATCH',
      token,
      body: JSON.stringify({ transactionId }),
    }),

  reject: (token: string, paymentId: string, rejectionReason: string) =>
    request<Payment>(`/payments/${paymentId}/reject`, {
      method: 'PATCH',
      token,
      body: JSON.stringify({ rejectionReason }),
    }),
};

// ─── News ────────────────────────────────────────────────────────────────────

export interface NewsItem {
  id: string;
  title: string;
  slug: string;
  summary: string | null;
  body: string;
  category: string;
  imageUrl: string | null;
  isFeatured: boolean;
  isPublished: boolean;
  publishedAt: string | null;
  createdAt: string;
}

export const news = {
  list: (params?: { category?: string; featured?: boolean; limit?: number; lang?: string }) => {
    const q = new URLSearchParams();
    if (params?.category) q.set('category', params.category);
    if (params?.featured) q.set('featured', 'true');
    if (params?.limit) q.set('limit', String(params.limit));
    if (params?.lang) q.set('lang', params.lang);
    const qs = q.toString();
    return request<{ data: NewsItem[] }>(`/news${qs ? `?${qs}` : ''}`);
  },

  bySlug: (slug: string, lang?: string) => request<NewsItem>(`/news/${slug}${lang ? `?lang=${lang}` : ''}`),

  // Admin
  create: (
    token: string,
    data: Partial<NewsItem> & { title: string; body: string },
  ) =>
    request<NewsItem>('/news', {
      method: 'POST',
      token,
      body: JSON.stringify(data),
    }),

  update: (token: string, id: string, data: Partial<NewsItem>) =>
    request<NewsItem>(`/news/${id}`, {
      method: 'PATCH',
      token,
      body: JSON.stringify(data),
    }),

  delete: (token: string, id: string) =>
    request<void>(`/news/${id}`, { method: 'DELETE', token }),
};

// ─── Content (Judges, Partners) ──────────────────────────────────────────────

export interface Judge {
  id: string;
  firstName: string;
  lastName: string;
  initials: string;
  title: string;
  institution: string | null;
  subject: string | null;
  avatarUrl: string | null;
  bio: string | null;
  isActive: boolean;
  order: number;
}

export interface AssignedJudge extends Judge {
  assignmentOrder: number;
}

export interface Partner { id: string; name: string; logoUrl: string | null; website: string | null; order: number }

export const content = {
  judges: () => request<{ data: Judge[] }>('/content/judges'),

  partners: () => request<Partner[]>('/content/partners'),

  olympiadJudges: (olympiadId: string) =>
    request<AssignedJudge[]>(`/content/olympiads/${olympiadId}/judges`),

  createJudge: (token: string, data: Partial<Judge> & { firstName: string; lastName: string; initials: string; title: string }) =>
    request<Judge>('/content/judges', {
      method: 'POST',
      token,
      body: JSON.stringify(data),
    }),

  updateJudge: (token: string, id: string, data: Partial<Judge>) =>
    request<Judge>(`/content/judges/${id}`, {
      method: 'PATCH',
      token,
      body: JSON.stringify(data),
    }),

  deleteJudge: (token: string, id: string) =>
    request<void>(`/content/judges/${id}`, { method: 'DELETE', token }),
};

// ─── Olympiads ───────────────────────────────────────────────────────────────

export interface OlympiadSubject {
  id: string;
  subject: { name: string; slug: string; priceUzs: number };
  questionCnt: number;
}

export interface Olympiad {
  id: string;
  title: string;
  description: string | null;
  audience?: string | null;
  year: number;
  status: string;
  startsAt: string;
  endsAt: string;
  durationMin: number;
  maxScore: number;
  passScore: number;
  priceUzs: number;
  totalSlots: number | null;
  slotsTaken?: number;
  slotsLeft?: number | null;
  stageCount: number;
  stage2Info: string | null;
  subjects: OlympiadSubject[];
  // derived/virtual for UI
  price: number;
  examStart: string;
}

function decorate(o: Olympiad): Olympiad {
  return { ...o, examStart: o.startsAt, price: o.priceUzs };
}

export const olympiads = {
  list: (status?: string, lang?: string) => {
    const q = new URLSearchParams();
    if (status) q.set('status', status);
    if (lang) q.set('lang', lang);
    const qs = q.toString();
    return request<Olympiad[]>(`/olympiads${qs ? `?${qs}` : ''}`).then(list => list.map(decorate));
  },
  byId: (id: string, lang?: string) => request<Olympiad>(`/olympiads/${id}${lang ? `?lang=${lang}` : ''}`).then(decorate),
  stats: (id: string) => request<OlympiadStats>(`/olympiads/${id}/stats`),
};

export interface OlympiadStats {
  totalRegistrations: number;
  confirmedCount: number;
  examTaken: number;
  byRegion: { region: string; count: number }[];
}

// ─── Subjects (public) ───────────────────────────────────────────────────────

export interface PublicSubject { id: string; name: string; slug: string }

export const subjects = {
  list: () => request<PublicSubject[]>('/subjects'),
};

// ─── Ratings (public) ────────────────────────────────────────────────────────

export interface RatingParticipant { rank: number; userId: string; name: string; region: string | null; school: string | null; points: number; olympiads: number }
export interface RatingSchool { rank: number; school: string; region: string | null; points: number; students: number }
export interface RatingRegion { rank: number; region: string; points: number; participants: number }
export interface RatingsResponse { participants: RatingParticipant[]; schools: RatingSchool[]; regions: RatingRegion[] }

export interface MyRank { rank: number | null; total: number; points: number; olympiads: number }

// ─── Gamifikatsiya (XP / daraja / do'st taklif) ──────────────────────────────
export interface Gamification {
  xp: number;
  level: number;
  levelXp: number;
  nextLevelXp: number;
  progressPct: number;
  inviteCode: string;
  inviteUrl: string;
  invitedCount: number;
  invitedXp: number;
}
export const gamification = {
  me: (token: string) => request<Gamification>('/users/me/gamification', { token }),
};

// ─── Bildirishnomalar (qo'ng'iroq) ───────────────────────────────────────────
export interface NotificationItem {
  id: string;
  kind: string;        // payment | result | certificate | exam | info
  title: string;
  body: string;
  link: string | null;
  isRead: boolean;
  createdAt: string;
}
export interface NotificationsResponse { items: NotificationItem[]; unread: number }
export const notificationsApi = {
  list: (token: string) => request<NotificationsResponse>('/notifications', { token }),
  readAll: (token: string) => request<{ ok: boolean }>('/notifications/read-all', { method: 'POST', token }),
  read: (token: string, id: string) => request<{ ok: boolean }>(`/notifications/${id}/read`, { method: 'POST', token }),
};

// ─── Profil (shaxsiy ma'lumotlar) ────────────────────────────────────────────
export const users = {
  updateProfile: (token: string, data: { firstName?: string; lastName?: string; phone?: string; region?: string; district?: string; school?: string; parentPhone?: string; passport?: string }) =>
    request<User>('/users/profile', { method: 'PATCH', token, body: JSON.stringify(data) }),
  changePassword: (token: string, currentPassword: string, newPassword: string) =>
    request<{ ok: boolean }>('/users/me/change-password', { method: 'POST', token, body: JSON.stringify({ currentPassword, newPassword }) }),
  uploadAvatar: async (token: string, file: File): Promise<User> => {
    const form = new FormData();
    form.append('file', file);
    const res = await fetch(`${BASE}/users/me/avatar`, { method: 'POST', headers: { Authorization: `Bearer ${token}` }, body: form, credentials: 'include' });
    if (!res.ok) {
      const msg = await res.json().catch(() => null);
      throw new Error(msg?.message || `Yuklash xatosi (${res.status})`);
    }
    return res.json();
  },
};

export interface RatingTeacher { rank: number; id: string; name: string; region: string | null; school: string | null; referralCode: string | null; students: number; points: number; wins: number }
export interface TeachersResponse { teachers: RatingTeacher[] }

export const ratings = {
  get: (params: { subjectId?: string; year?: number; month?: number; limit?: number } = {}) => {
    const qs = new URLSearchParams();
    if (params.subjectId) qs.set('subjectId', params.subjectId);
    if (params.year) qs.set('year', String(params.year));
    if (params.month) qs.set('month', String(params.month));
    if (params.limit) qs.set('limit', String(params.limit));
    const q = qs.toString();
    return request<RatingsResponse>(`/ratings${q ? `?${q}` : ''}`);
  },
  teachers: (params: { year?: number; limit?: number } = {}) => {
    const qs = new URLSearchParams();
    if (params.year) qs.set('year', String(params.year));
    if (params.limit) qs.set('limit', String(params.limit));
    const q = qs.toString();
    return request<TeachersResponse>(`/ratings/teachers${q ? `?${q}` : ''}`);
  },
  me: (token: string, params: { year?: number } = {}) =>
    request<MyRank>(`/ratings/me${params.year ? `?year=${params.year}` : ''}`, { token }),
};

// ─── Referral (ustoz) ──────────────────────────────────────────────────────────

export interface ReferralStudent { id: string; name: string; region: string | null; school: string | null; joinedAt: string; olympiads: number }
export interface ReferralInfo { code: string | null; studentCount: number; students: ReferralStudent[] }

export const referral = {
  me: (token: string) => request<ReferralInfo>('/auth/referral/me', { token }),
  claim: (token: string, code: string) =>
    request<{ applied: boolean }>('/auth/referral/claim', {
      method: 'POST',
      token,
      body: JSON.stringify({ code }),
    }),
};

// ─── Exams ───────────────────────────────────────────────────────────────────

export interface ExamOption {
  id: string;
  text: string;
  order: number;
}

export interface ExamQuestion {
  id: string;
  text: string;
  imageUrl: string | null;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD' | 'EXPERT';
  points: number;
  subjectId: string;
  options: ExamOption[];
}

export interface ExamSessionInfo {
  id: string;
  userId: string;
  olympiadId: string;
  registrationId: string;
  status: 'NOT_STARTED' | 'IN_PROGRESS' | 'FINISHED' | 'TIMED_OUT' | 'DISQUALIFIED';
  startedAt: string | null;
  expiresAt: string | null;
  finishedAt: string | null;
  score: number | null;
  totalScore: number | null;
  timeTakenSec: number | null;
  tabSwitches: number;
  olympiad?: { title: string; durationMin: number; maxScore: number; passScore: number };
  answers?: { questionId: string; optionId: string | null }[];
}

export interface ExamPayload {
  session: ExamSessionInfo;
  questions: ExamQuestion[];
}

export interface ExamResult {
  session: ExamSessionInfo;
}

export const exams = {
  start: (token: string, olympiadId: string, registrationId?: string) =>
    request<ExamPayload>('/exams/start', {
      method: 'POST',
      token,
      body: JSON.stringify({ olympiadId, ...(registrationId && { registrationId }) }),
    }),

  get: (token: string, sessionId: string) =>
    request<ExamPayload>(`/exams/${sessionId}`, { token }),

  submitAnswer: (token: string, sessionId: string, questionId: string, optionId: string | null) =>
    request<{ saved: boolean }>(`/exams/${sessionId}/answers`, {
      method: 'POST',
      token,
      body: JSON.stringify({ questionId, optionId: optionId ?? undefined }),
    }),

  finish: (token: string, sessionId: string) =>
    request<ExamSessionInfo>(`/exams/${sessionId}/finish`, {
      method: 'PATCH',
      token,
    }),

  reportTabSwitch: (token: string, sessionId: string) =>
    request<{ tabSwitches: number }>(`/exams/${sessionId}/tab-switch`, {
      method: 'POST',
      token,
    }),
};

// ─── Results ─────────────────────────────────────────────────────────────────

export interface MyResultResponse {
  sessionId: string;
  olympiadId: string;
  status: 'NOT_STARTED' | 'IN_PROGRESS' | 'FINISHED' | 'TIMED_OUT' | 'DISQUALIFIED';
  score: number | null;
  totalScore: number | null;
  timeTakenSec: number | null;
  passed: boolean;
  advancedToStage2: boolean;
  manualAdvance: boolean;
  certificate: { certCode: string; degree: string } | null;
  olympiad: { title: string; passScore: number; stageCount: number; stage2Info: string | null };
  answeredCount: number;
}

export interface LeaderboardEntry {
  rank: number;
  userId: string;
  name: string;
  region: string | null;
  school: string | null;
  score: number | null;
  timeTakenSec: number | null;
}

export interface MyResultRow {
  sessionId: string;
  olympiadId: string;
  olympiadTitle: string;
  status: 'NOT_STARTED' | 'IN_PROGRESS' | 'FINISHED' | 'TIMED_OUT' | 'DISQUALIFIED';
  score: number | null;
  totalScore: number | null;
  passScore: number;
  passed: boolean;
  advancedToStage2: boolean;
  manualAdvance: boolean;
  stageCount: number;
  stage2Info: string | null;
  stage2Score: number | null;
  stage2Place: number | null;
  stage2Notes: string | null;
  stage2WorkUrl: string | null;
  timeTakenSec: number | null;
  certCode: string | null;
  startsAt: string;
}

export const results = {
  mine: (token: string, sessionId: string) =>
    request<MyResultResponse>(`/results/session/${sessionId}`, { token }),

  my: (token: string) => request<MyResultRow[]>('/results/my', { token }),

  leaderboard: (olympiadId: string, limit = 50) =>
    request<LeaderboardEntry[]>(`/results/leaderboard/${olympiadId}?limit=${limit}`),
};

// ─── Certificates ────────────────────────────────────────────────────────────

export type CertificateVerifyResponse =
  | { valid: false; revoked?: false }
  | {
      valid: false;
      revoked: true;
      certCode: string;
      holder: string;
      revokedAt: string | null;
      revokedReason: string | null;
    }
  | {
      valid: true;
      certCode: string;
      holder: string;
      firstName: string;
      lastName: string;
      olympiad: string;
      year: number;
      stageCount: number;
      stage: number | null;
      degree: 'FIRST' | 'SECOND' | 'THIRD' | 'PARTICIPATION';
      score: number;
      issuedAt: string;
      pdfUrl: string | null;
      signature: string;
      verifyUrl: string;
    };

export interface MyCertificate {
  id: string;
  certCode: string;
  issuedAt: string;
  pdfUrl: string | null;
  session: { olympiad: { id: string; title: string; year: number } };
}

export interface FeaturedCertificate {
  certCode: string;
  holder: string;
  olympiad: string;
  year: number;
  score: number;
  issuedAt: string;
  signature: string;
  verifyUrl: string;
}

export const certificates = {
  verify: (certCode: string) =>
    request<CertificateVerifyResponse>(`/certificates/verify/${encodeURIComponent(certCode)}`),

  featured: () => request<FeaturedCertificate | null>('/certificates/featured'),

  my: (token: string) => request<MyCertificate[]>('/certificates/my', { token }),
};

// ─── Telegram linking ────────────────────────────────────────────────────────

export interface TelegramLinkToken {
  token: string;
  deepLink: string;
  expiresIn: number;
}

export const userMe = {
  getTelegramLinkToken: (token: string) =>
    request<TelegramLinkToken>('/users/me/telegram/link-token', { token }),
  disconnectTelegram: (token: string) =>
    request<{ id: string; telegramId: string | null }>('/users/me/telegram/disconnect', { method: 'POST', token }),
};

export { ApiError };
