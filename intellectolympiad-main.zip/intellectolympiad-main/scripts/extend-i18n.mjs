// One-off: yangi bosh sahifa bo'limlari (Yo'nalishlar/Sovrinlar) matnlarini
// ru/en uchun ui-i18n.json katalogiga qo'shadi. uz-Cyrl runtime transliteratsiya.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CATALOG = path.resolve(__dirname, '../lib/ui-i18n.json');

// .env dan OPENAI_API_KEY
const envText = fs.readFileSync(path.resolve(__dirname, '../../../.env'), 'utf8');
const KEY = (envText.match(/^OPENAI_API_KEY=(.+)$/m)?.[1] ?? '').trim().replace(/^["']|["']$/g, '');
if (!KEY) { console.error('OPENAI_API_KEY topilmadi'); process.exit(1); }

const STRINGS = [
  "Yo'nalishlar",
  'Fan yo\'nalishlari',
  "Olimpiada bir nechta fan yo'nalishlarini qamrab oladi — o'zingizga mosini tanlang va bilimingizni sinab ko'ring.",
  'Sovrinlar',
  "G'oliblar uchun mukofotlar",
  'Eng yuqori natijaga erishganlar daraja, sertifikat va qimmatbaho sovrinlar bilan taqdirlanadi.',
  "o'rin",
  'Oltin daraja', 'Kumush daraja', 'Bronza daraja',
  'Algebra, geometriya va mantiqiy masalalar',
  'Mexanika, elektr va zamonaviy fizika',
  'Organik, anorganik va analitik kimyo',
  'Botanika, zoologiya va inson anatomiyasi',
  'Algoritmlar, dasturlash va mantiq',
  "Grammatika, lug'at va matn tahlili",
  "Jahon va O'zbekiston tarixi",
  'Tabiiy va iqtisodiy geografiya',
  'Oltin sertifikat', 'Pul mukofoti', "Universitetga imtiyozli yo'l",
  'Kumush sertifikat', "Maxsus sovg'alar",
  'Bronza sertifikat', "Esdalik sovg'alari", 'Rasmiy tan olinish',
  'Har bir ishtirokchi rasmiy', 'QR-kodli sertifikat',
  "oladi. Aniq sovrinlar va mukofot jamg'armasi har olimpiada uchun alohida e'lon qilinadi.",
  // Ustozlar reytingi bo'limi
  'Ustozlar dasturi', 'Eng faol ustozlar reytingi', "Ustoz bo'lish",
  "Ko'proq o'quvchi olib kelgan ustozlar — pul mukofot va sovg'alar bilan taqdirlanadi.",
  "o'quvchi", 'ball',
];

const LANG_NAME = { ru: 'Russian', en: 'English' };

async function translate(strings, target) {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${KEY}` },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      temperature: 0,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content:
          `You translate UI strings for an academic "Olympiad" platform (a knowledge competition for students in maths, physics, etc.) from Uzbek (Latin script) into ${LANG_NAME[target]}. ` +
          `Translate "olimpiada" as academic "Olympiad" — NOT the sports "Olympics". Keep translations natural and concise for a UI. ` +
          `Do NOT translate brand names, codes (IO-2026-...), emails, URLs or numbers. Preserve punctuation and arrows. ` +
          `Return STRICT JSON: {"translations": [...]} — same number of items, same order.` },
        { role: 'user', content: JSON.stringify(strings) },
      ],
    }),
  });
  if (!res.ok) throw new Error(`OpenAI ${res.status}: ${(await res.text()).slice(0, 200)}`);
  const json = await res.json();
  const arr = JSON.parse(json.choices?.[0]?.message?.content ?? '{}').translations ?? [];
  return strings.map((s, i) => (typeof arr[i] === 'string' ? arr[i] : s));
}

const dict = JSON.parse(fs.readFileSync(CATALOG, 'utf8'));
dict.ru ||= {}; dict.en ||= {};

for (const target of ['ru', 'en']) {
  const missing = STRINGS.filter((s) => !dict[target][s]);
  if (missing.length === 0) { console.log(`${target}: hammasi mavjud`); continue; }
  const out = await translate(missing, target);
  missing.forEach((s, i) => { dict[target][s] = out[i]; });
  console.log(`${target}: ${missing.length} ta qo'shildi`);
}

// kalitlarni alfavit tartibida saqlash (diff toza bo'lishi uchun)
for (const loc of Object.keys(dict)) {
  dict[loc] = Object.fromEntries(Object.entries(dict[loc]).sort(([a], [b]) => a.localeCompare(b)));
}

// Mavjud formatga mos (har kalit alohida qatorda, indentsiz) — qiymatlardan
// qat'i nazar xavfsiz (har biri JSON.stringify orqali).
function serialize(d) {
  const locs = Object.keys(d);
  let out = '{\n';
  locs.forEach((loc, li) => {
    out += JSON.stringify(loc) + ': {\n';
    const entries = Object.entries(d[loc]);
    entries.forEach(([k, v], i) => {
      out += JSON.stringify(k) + ': ' + JSON.stringify(v) + (i < entries.length - 1 ? ',' : '') + '\n';
    });
    out += '}' + (li < locs.length - 1 ? ',' : '') + '\n';
  });
  return out + '}\n';
}
const text = serialize(dict);
JSON.parse(text); // sanity check
fs.writeFileSync(CATALOG, text);
console.log('ui-i18n.json yangilandi');
