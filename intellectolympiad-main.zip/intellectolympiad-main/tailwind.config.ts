import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}', './lib/**/*.{ts,tsx}', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        parchment: { DEFAULT: '#f2f5f8', 2: '#e3eef8' },
        surface: '#ffffff',
        ink: { DEFAULT: '#1b2129', 2: '#434b55' },
        muted: '#6f7a89',
        line: { DEFAULT: '#dce3eb', 2: '#c6d0db' },
        bordo: {
          DEFAULT: '#0877B5',
          700: '#066291',
          900: '#0b3b5a',
          tint: '#e3f1f9',
          tint2: '#c8e4f3',
        },
        gold: { DEFAULT: '#9a7b3f', tint: '#e3f1f9' },
        'ds-green': { DEFAULT: '#2e6b4f', tint: '#e6f0ea' },
        'ds-amber': { DEFAULT: '#9a6a1f', tint: '#f6edda' },
        'ds-red': { DEFAULT: '#9c2b2b', tint: '#f6e6e6' },
        'ds-info': { DEFAULT: '#2a4f7a', tint: '#e7eef6' },
      },
      fontFamily: {
        sans: ['var(--font-sans)', '-apple-system', 'system-ui', 'sans-serif'],
        serif: ['var(--font-serif)', 'Georgia', 'serif'],
        mono: ['var(--font-mono)', 'ui-monospace', 'monospace'],
      },
      borderRadius: {
        sm: '4px',
        DEFAULT: '6px',
        lg: '10px',
        full: '9999px',
      },
      boxShadow: {
        // Softer, layered depth — premium diffused look
        sm: '0 1px 2px rgba(31,27,25,.04), 0 2px 6px rgba(31,27,25,.05)',
        DEFAULT: '0 2px 4px rgba(31,27,25,.04), 0 8px 24px rgba(31,27,25,.06)',
        md: '0 4px 8px rgba(31,27,25,.05), 0 12px 32px rgba(31,27,25,.08)',
        lg: '0 8px 16px rgba(31,27,25,.06), 0 24px 56px rgba(31,27,25,.11)',
        xl: '0 16px 32px rgba(31,27,25,.08), 0 40px 80px rgba(31,27,25,.14)',
      },
      maxWidth: { wrap: '1200px' },
      keyframes: {
        marquee: {
          '0%': { transform: 'translateX(0)' },
          '100%': { transform: 'translateX(-50%)' },
        },
        blink: {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.4' },
        },
      },
      animation: {
        marquee: 'marquee 28s linear infinite',
        blink: 'blink 1s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};

export default config;
