/** @type {import('next').NextConfig} */

const isProd = process.env.NODE_ENV === 'production';

// API origini (connect-src uchun). Standart — production; env qo'yilsa o'sha.
const PROD_API = 'https://api.intellectolympiad.uz';
const apiUrl = process.env.NEXT_PUBLIC_API_URL || `${PROD_API}/api/v1`;
let apiOrigin = PROD_API;
try { apiOrigin = new URL(apiUrl).origin; } catch { /* default */ }
const wsOrigin = apiOrigin.replace(/^http/, 'ws');
// connect-src — prod API + lokal dev (localhost:4000) + Google. Ikkalasi ham ishlasin.
const connectSrc = [...new Set([
  "'self'", apiOrigin, wsOrigin,
  PROD_API, PROD_API.replace(/^http/, 'ws'),
  'http://localhost:4000', 'ws://localhost:4000',
  'https://accounts.google.com',
])].join(' ');

// Content-Security-Policy — XSS uchun defense-in-depth.
// Eslatma: Next.js App Router hidratsiya uchun inline skript ishlatadi, shuning uchun
// script-src'da 'unsafe-inline' kerak (nonce infratuzilmasisiz). object-src/base-uri/
// frame-ancestors/connect-src/form-action cheklovlari baribir kuchli himoya beradi.
// Google login (GSI) uchun accounts.google.com allowlist qilingan.
const csp = [
  "default-src 'self'",
  "base-uri 'self'",
  "object-src 'none'",
  "frame-ancestors 'none'",
  "form-action 'self'",
  `img-src 'self' data: blob: https: http: ${apiOrigin}`, // API/storage QR va rasm'lari (dev http, prod https)
  "font-src 'self' data:",
  "style-src 'self' 'unsafe-inline' https://accounts.google.com", // GSI stylesheet
  `script-src 'self' 'unsafe-inline'${isProd ? '' : " 'unsafe-eval'"} https://accounts.google.com https://apis.google.com`,
  `connect-src ${connectSrc}`,
  "frame-src 'self' https://accounts.google.com",
  "worker-src 'self' blob:",
  "manifest-src 'self'",
  // Faqat API https bo'lганda — aks holda lokal http API'ni buzmaslik uchun.
  ...(isProd && apiOrigin.startsWith('https') ? ['upgrade-insecure-requests'] : []),
].join('; ');

const securityHeaders = [
  { key: 'Content-Security-Policy', value: csp },
  { key: 'X-Frame-Options', value: 'DENY' },
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=(), payment=()' },
  { key: 'X-DNS-Prefetch-Control', value: 'on' },
  {
    key: 'Strict-Transport-Security',
    value: 'max-age=31536000; includeSubDomains; preload',
  },
  // Google OAuth popup postMessage uchun — default same-origin blok qiladi
  { key: 'Cross-Origin-Opener-Policy', value: 'same-origin-allow-popups' },
];

const config = {
  reactStrictMode: true,
  poweredByHeader: false,
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: securityHeaders,
      },
    ];
  },
};

export default config;
