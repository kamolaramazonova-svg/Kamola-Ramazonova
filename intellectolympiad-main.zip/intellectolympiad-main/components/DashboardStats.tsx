'use client';

import type { MyResultRow, Gamification } from '@/lib/api';

// Ballni 0–100% ga normallashtirish
function normScore(r: MyResultRow): number {
  if (r.score == null) return 0;
  const total = r.totalScore ?? 100;
  return total > 0 ? Math.round((r.score / total) * 100) : Math.round(r.score);
}

function Stat({ label, value, accent }: { label: string; value: string | number; accent?: boolean }) {
  return (
    <div className={`rounded-lg px-2 py-3 text-center ${accent ? 'bg-bordo-tint' : 'bg-parchment'}`}>
      <div className={`font-mono font-bold text-[20px] leading-none ${accent ? 'text-bordo' : 'text-ink'}`}>{value}</div>
      <div className="text-[10.5px] text-muted mt-1.5">{label}</div>
    </div>
  );
}

/**
 * Foydalanuvchi dashboard — natijalar tahlili (mobil uchun ham): stat plitkalar,
 * o'tish-darajasi donut diagrammasi va so'nggi imtihon ballari bar-chart. SVG, kutubxonasiz.
 */
export default function DashboardStats({
  results,
  gam,
  certCount,
}: {
  results: MyResultRow[];
  gam: Gamification | null;
  certCount: number;
}) {
  const finished = results.filter(r => r.status === 'FINISHED' || r.status === 'TIMED_OUT');
  const examCount = finished.length;
  const passedCount = finished.filter(r => r.passed).length;
  const avg = examCount ? Math.round(finished.reduce((s, r) => s + normScore(r), 0) / examCount) : 0;
  const passRate = examCount ? Math.round((passedCount / examCount) * 100) : 0;
  const chart = finished.slice(-7); // so'nggi 7 imtihon

  // donut geometriyasi
  const R = 26;
  const C = 2 * Math.PI * R;
  const dash = (passRate / 100) * C;

  if (examCount === 0) {
    return (
      <div className="bg-surface border border-line rounded-xl p-5 mb-4">
        <h3 className="font-serif text-[16px] font-semibold text-ink mb-2">Natijalar tahlili</h3>
        <p className="text-[13px] text-muted leading-relaxed">
          Imtihon topshirgach — bu yerda <b className="text-ink">ballar diagrammasi, o&apos;rtacha
          ko&apos;rsatkich va o&apos;tish darajasi</b> ko&apos;rinadi.
        </p>
        <div className="grid grid-cols-3 gap-2.5 mt-4">
          <Stat label="Imtihon" value={0} />
          <Stat label="O'rtacha" value="—" accent />
          <Stat label="Sertifikat" value={certCount} />
        </div>
      </div>
    );
  }

  return (
    <div className="bg-surface border border-line rounded-xl p-5 mb-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-serif text-[16px] font-semibold text-ink">Natijalar tahlili</h3>
        <span className="text-[11px] font-semibold text-bordo bg-bordo-tint px-2.5 py-1 rounded-full">
          Daraja {gam?.level ?? 1} · {gam?.xp ?? 0} XP
        </span>
      </div>

      {/* Stat plitkalar */}
      <div className="grid grid-cols-3 gap-2.5 mb-5">
        <Stat label="Imtihon" value={examCount} />
        <Stat label="O'rtacha ball" value={`${avg}%`} accent />
        <Stat label="Sertifikat" value={certCount} />
      </div>

      <div className="flex items-center gap-4 min-w-0">
        {/* O'tish darajasi — donut */}
        <div className="relative flex-none" style={{ width: 72, height: 72 }}>
          <svg width="72" height="72" viewBox="0 0 72 72" className="-rotate-90">
            <circle cx="36" cy="36" r={R} fill="none" stroke="#e7edf3" strokeWidth="8" />
            <circle
              cx="36" cy="36" r={R} fill="none" stroke="#0877B5" strokeWidth="8"
              strokeLinecap="round" strokeDasharray={`${dash} ${C}`}
              style={{ transition: 'stroke-dasharray .6s ease' }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="font-mono font-bold text-bordo text-[18px] leading-none">{passRate}%</span>
            <span className="text-[9px] text-muted mt-0.5">o&apos;tish</span>
          </div>
        </div>

        {/* So'nggi ballar — bar chart */}
        <div className="flex-1 min-w-0">
          <div className="flex items-end justify-between gap-1.5">
            {chart.map(r => {
              const pct = normScore(r);
              return (
                <div key={r.sessionId} className="flex-1 flex flex-col items-center gap-1" title={`${r.olympiadTitle}: ${pct}%`}>
                  <span className="text-[9px] font-mono text-muted leading-none">{pct}</span>
                  <div className="w-full flex items-end" style={{ height: 50 }}>
                    <div
                      className="w-full rounded-t-[3px]"
                      style={{
                        height: `${Math.max(6, pct)}%`,
                        background: r.passed ? 'linear-gradient(180deg,#5cb8e6,#0877B5)' : '#c6d0db',
                        transition: 'height .5s ease',
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
          <div className="text-[10px] text-muted mt-1.5 text-center">So&apos;nggi {chart.length} imtihon bali (%)</div>
        </div>
      </div>
    </div>
  );
}
