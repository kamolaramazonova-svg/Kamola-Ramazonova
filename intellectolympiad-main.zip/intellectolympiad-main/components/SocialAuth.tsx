'use client';
import { useState, useRef, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { auth, referral } from '@/lib/api';
import { saveSession } from '@/lib/auth';
import { Spinner } from '@/components/Spinner';

const BOT = process.env.NEXT_PUBLIC_TELEGRAM_BOT || 'Intellect_Olympiad_bot';
const GOOGLE_CLIENT_ID = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID || '302395779594-n3su6p46cpg2cc3ntkccemap637pp1cq.apps.googleusercontent.com';

type AuthResult = { accessToken: string; user: Parameters<typeof saveSession>[1] };

const IcTelegram = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" style={{ width: 17, height: 17 }}>
    <path d="M21.94 4.6 18.9 19.3c-.23 1.02-.84 1.27-1.7.79l-4.7-3.46-2.27 2.18c-.25.25-.46.46-.94.46l.33-4.78L18.6 6.1c.38-.34-.08-.53-.6-.19L7.3 12.78l-4.65-1.45c-1.01-.32-1.03-1.01.21-1.5l18.2-7.01c.84-.31 1.58.2 1.31 1.78z" />
  </svg>
);

const IcGoogle = () => (
  <svg viewBox="0 0 24 24" style={{ width: 17, height: 17 }}>
    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.27-4.74 3.27-8.1z" />
    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A11 11 0 0 0 12 23z" />
    <path fill="#FBBC05" d="M5.84 14.1a6.6 6.6 0 0 1 0-4.2V7.06H2.18a11 11 0 0 0 0 9.88l3.66-2.84z" />
    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1A11 11 0 0 0 2.18 7.06l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z" />
  </svg>
);

declare global {
  interface Window { google?: any }
}

let gsiInitialized = false;

export default function SocialAuth({ redirectTo = '/cabinet', onAuthed }: { redirectTo?: string; onAuthed?: (res: AuthResult) => void }) {
  const router = useRouter();
  const [digits, setDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [opened, setOpened] = useState(false);
  const [gsiReady, setGsiReady] = useState(false);
  const inputs = useRef<(HTMLInputElement | null)[]>([]);
  const googleHostRef = useRef<HTMLDivElement>(null);

  const finish = useCallback(async (res: AuthResult) => {
    if (onAuthed) { onAuthed(res); return; }
    saveSession(res.accessToken, res.user);
    try {
      const ref = new URLSearchParams(window.location.search).get('ref');
      if (ref && res.user.role === 'STUDENT') await referral.claim(res.accessToken, ref.trim());
    } catch { /* ixtiyoriy */ }
    router.push(redirectTo);
  }, [router, redirectTo, onAuthed]);

  const submitCode = useCallback(async (code: string) => {
    setLoading(true); setError('');
    try {
      const res = await auth.telegramVerify(code);
      finish(res);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Kod noto'g'ri yoki muddati o'tgan");
      setDigits(['', '', '', '', '', '']);
      inputs.current[0]?.focus();
    } finally { setLoading(false); }
  }, [finish]);

  const setDigit = (i: number, val: string) => {
    const v = val.replace(/\D/g, '');
    if (!v) { setDigits(d => { const n = [...d]; n[i] = ''; return n; }); return; }
    setDigits(d => {
      const n = [...d];
      const chars = v.split('');
      for (let k = 0; k < chars.length && i + k < 6; k++) n[i + k] = chars[k];
      const next = Math.min(i + chars.length, 5);
      inputs.current[next]?.focus();
      if (n.every(x => x !== '')) submitCode(n.join(''));
      return n;
    });
  };

  const onKey = (i: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !digits[i] && i > 0) inputs.current[i - 1]?.focus();
  };

  const toggleTelegram = () => {
    setError('');
    if (!opened && BOT) window.open(`https://t.me/${BOT}?start=login`, '_blank', 'noopener');
    setOpened(o => !o);
    setTimeout(() => inputs.current[0]?.focus(), 100);
  };

  // finish ref — initialize() bir marta chaqiriladi, callback yangi finish'ni ko'radi
  const finishRef = useRef(finish);
  finishRef.current = finish;

  // Google'ning HAQIQIY tugmasini render qiladi — o'lchamini stilizatsiya qilingan
  // tugmamizga moslab. Bu tugma shaffof (opacity 0) holda ustiga qo'yiladi va
  // foydalanuvchining HAQIQIY bosishini qabul qiladi. (Google sintetik .click() ni
  // — isTrusted=false — rad etadi, shuning uchun dasturiy bosish ishlamaydi.)
  const renderGoogleButton = useCallback(() => {
    const host = googleHostRef.current;
    if (!host || !window.google?.accounts?.id) return;
    const w = Math.round(Math.max(host.parentElement?.offsetWidth || 0, 200));
    host.innerHTML = '';
    window.google.accounts.id.renderButton(host, {
      type: 'standard', theme: 'outline', size: 'large', text: 'continue_with', width: w,
    });
  }, []);

  useEffect(() => {
    if (!GOOGLE_CLIENT_ID) return;

    const initGSI = () => {
      if (!window.google?.accounts?.id) return;
      if (!gsiInitialized) {
        gsiInitialized = true;
        window.google.accounts.id.initialize({
          client_id: GOOGLE_CLIENT_ID,
          callback: async (resp: { credential: string }) => {
            setLoading(true); setError('');
            try { finishRef.current(await auth.google(resp.credential)); }
            catch (e: unknown) { setError(e instanceof Error ? e.message : 'Google orqali kirishda xatolik'); }
            finally { setLoading(false); }
          },
        });
      }
      setGsiReady(true);
    };

    const ID = 'gsi-script';
    if (document.getElementById(ID)) { initGSI(); return; }
    const s = document.createElement('script');
    s.src = 'https://accounts.google.com/gsi/client';
    s.async = true; s.defer = true; s.id = ID;
    s.onload = initGSI;
    document.head.appendChild(s);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // GSI tayyor bo'lgach tugmani render qilamiz + kenglik o'zgarsa qayta render
  useEffect(() => {
    if (!gsiReady) return;
    renderGoogleButton();
    const parent = googleHostRef.current?.parentElement;
    if (!parent || typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver(() => renderGoogleButton());
    ro.observe(parent);
    return () => ro.disconnect();
  }, [gsiReady, renderGoogleButton]);

  const btnBase = 'flex items-center justify-center gap-2 py-[10px] px-3 rounded-lg font-semibold text-[13.5px] border transition-colors cursor-pointer disabled:opacity-55 disabled:cursor-not-allowed';

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2.5">
        <button type="button" onClick={toggleTelegram}
          className={`${btnBase} ${opened ? 'bg-bordo text-white border-bordo' : 'bg-surface text-ink border-line-2 hover:border-bordo hover:text-bordo'}`}>
          <IcTelegram /> Telegram
        </button>

        {/* Google: bizning stilimizdagi ko'rinadigan tugma + ustiga Google'ning
            HAQIQIY tugmasi shaffof (opacity 0) qilib qo'yiladi. Foydalanuvchi
            bordo tugmani bosadi — bosish aslida Google tugmasiga tegadi. */}
        <div className="relative group">
          <div aria-hidden="true"
            className={`${btnBase} w-full pointer-events-none bg-surface text-ink border-line-2 group-hover:border-bordo group-hover:text-bordo`}>
            {loading
              ? <><Spinner size={16} className="text-bordo" /> Ulanmoqda…</>
              : <><IcGoogle /> Google</>}
          </div>
          {GOOGLE_CLIENT_ID && (
            <div ref={googleHostRef}
              className={`absolute inset-0 z-10 flex items-center justify-center overflow-hidden opacity-0 ${loading ? 'pointer-events-none' : ''}`}
              style={{ colorScheme: 'light' }} />
          )}
        </div>
      </div>

      {/* Telegram kod kiritish */}
      {opened && (
        <div className="border border-line-2 rounded-lg p-3.5 bg-parchment-2">
          <p className="text-[12.5px] text-ink-2 mb-2.5 leading-snug">
            {BOT ? <>@{BOT} botida <b>/start</b> bosing va kelgan <b>6 xonali kodni</b> kiriting:</> : <>Telegram botida <b>/start</b> bosing va kodni kiriting:</>}
          </p>
          <div className="flex gap-2 justify-center" onPaste={(e) => { const t = e.clipboardData.getData('text'); if (/\d/.test(t)) { e.preventDefault(); setDigit(0, t); } }}>
            {digits.map((d, i) => (
              <input key={i} ref={el => { inputs.current[i] = el; }} value={d}
                onChange={e => setDigit(i, e.target.value)} onKeyDown={e => onKey(i, e)}
                inputMode="numeric" maxLength={1} disabled={loading}
                className="flex-1 min-w-0 max-w-[48px] h-[50px] text-center font-serif text-[19px] font-bold text-ink border border-line-2 rounded-lg bg-surface focus:outline-none focus:border-bordo focus:shadow-[0_0_0_3px_#e3f1f9] disabled:opacity-50" />
            ))}
          </div>
          {BOT && (
            <button type="button" onClick={() => window.open(`https://t.me/${BOT}?start=login`, '_blank', 'noopener')}
              className="mt-2.5 text-[12px] text-bordo font-semibold hover:underline bg-transparent border-none cursor-pointer">
              Botni qayta ochish
            </button>
          )}
        </div>
      )}

      {loading && <div className="flex items-center justify-center gap-2 text-[13px] text-muted"><Spinner size={16} className="text-bordo" /> Tekshirilmoqda…</div>}
      {error && <div className="text-[13px] text-ds-red bg-ds-red-tint border border-ds-red/30 rounded-lg px-3 py-2 text-center">{error}</div>}
    </div>
  );
}
