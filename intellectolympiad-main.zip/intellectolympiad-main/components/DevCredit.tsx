'use client';

import { usePathname } from 'next/navigation';

const PORTFOLIO = 'https://www.soliyev.uz/';

/**
 * Ishlab chiquvchi krediti — faqat bosh sahifa pastida nozik qator. Portfolio: soliyev.uz.
 */
export default function DevCredit() {
  const pathname = usePathname();
  if (pathname !== '/') return null;

  return (
    <footer className="text-center py-3 px-4 text-[12px] text-muted border-t border-line/60 bg-parchment">
      Ishlab chiquvchi:{' '}
      <a href={PORTFOLIO} target="_blank" rel="noreferrer" className="font-semibold text-bordo hover:underline">
        soliyev.uz
      </a>
    </footer>
  );
}
