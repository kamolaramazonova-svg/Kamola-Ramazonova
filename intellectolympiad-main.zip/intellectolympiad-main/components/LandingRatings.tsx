'use client';
import { useState, useEffect } from 'react';
import { ratings, subjects as subjectsApi, type RatingsResponse, type PublicSubject, type RatingTeacher } from '@/lib/api';
import { LoadingRow } from '@/components/Spinner';

const YEARS = [2026, 2025];
const REGION_COLORS = ['#0877B5', '#9a7b3f', '#2a4f7a', '#2e6b4f', '#9a6a1f', '#066291', '#4a6b2e', '#7a4f2a'];

export default function LandingRatings() {
  const [data, setData] = useState<RatingsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [subjects, setSubjects] = useState<PublicSubject[]>([]);
  const [subjectId, setSubjectId] = useState('');
  const [year, setYear] = useState<number>(2026);
  const [teachers, setTeachers] = useState<RatingTeacher[]>([]);

  useEffect(() => { subjectsApi.list().then(setSubjects).catch(() => {}); }, []);

  useEffect(() => {
    setLoading(true);
    ratings.get({ subjectId: subjectId || undefined, year, limit: 5 })
      .then(setData)
      .catch(() => setData({ participants: [], schools: [], regions: [] }))
      .finally(() => setLoading(false));
  }, [subjectId, year]);

  useEffect(() => {
    ratings.teachers({ year, limit: 5 }).then(r => setTeachers(r.teachers)).catch(() => setTeachers([]));
  }, [year]);

  const selCls = 'font-sans text-[13px] text-ink-2 pl-3 pr-7 py-[6px] border border-line-2 rounded-full bg-surface focus:outline-none focus:border-bordo cursor-pointer';
  const regions = (data?.regions ?? []).slice(0, 8);
  const top = (data?.participants ?? []).slice(0, 3);
  const maxPart = Math.max(1, ...regions.map(r => r.participants));
  const total = regions.reduce((s, r) => s + r.participants, 0);

  return (
    <section id="reyting" data-reveal className="py-20 bg-surface scroll-mt-24">
      <div className="max-w-[760px] mx-auto px-6">
        {/* Header */}
        <div className="flex items-end justify-between gap-4 mb-6 flex-wrap">
          <div>
            <div className="text-[10.5px] tracking-[.18em] uppercase text-gold font-bold mb-1">Jonli reyting</div>
            <h2 className="font-serif text-[clamp(24px,3vw,30px)] font-semibold text-ink leading-tight">Viloyatlar bellashuvi</h2>
            <p className="text-muted text-[14px] mt-1">Qaysi viloyat oldinda — ishtirokchilar soni bo&apos;yicha.</p>
          </div>
          <div className="flex gap-2">
            <select value={subjectId} onChange={e => setSubjectId(e.target.value)} className={selCls}>
              <option value="">Barcha fanlar</option>
              {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <select value={year} onChange={e => setYear(+e.target.value)} className={selCls}>
              {YEARS.map(y => <option key={y} value={y}>{y}-yil</option>)}
            </select>
          </div>
        </div>

        {/* Regions race */}
        <div className="bg-bordo-tint border border-bordo/15 rounded-2xl p-6 sm:p-8">
          {loading ? (
            <LoadingRow className="py-10" />
          ) : regions.length === 0 ? (
            <div className="py-10 text-center text-muted text-[14px]">Hozircha ma&apos;lumot yo&apos;q. Olimpiadalar boshlanishi bilan reyting to&apos;ladi.</div>
          ) : (
            <>
              <div className="flex items-center justify-between mb-5">
                <span className="text-[12px] uppercase tracking-[.08em] text-muted font-bold">Viloyat</span>
                <span className="text-[12px] text-muted">Jami <b className="text-ink font-mono">{total}</b> ishtirokchi</span>
              </div>
              <div className="flex flex-col gap-[15px] [--region-grid:16px_84px_minmax(0,1fr)_28px] sm:[--region-grid:20px_116px_1fr_32px]">
                {regions.map((r, i) => (
                  <div key={r.rank} className="grid items-center gap-x-2 sm:gap-x-3" style={{ gridTemplateColumns: 'var(--region-grid)' }}>
                    <span className="font-mono text-[13px] font-bold text-muted text-center">{r.rank}</span>
                    <span className="text-[13.5px] text-ink font-semibold truncate">{r.region}</span>
                    <span className="h-[14px] rounded-full bg-surface overflow-hidden border border-line block">
                      <span className="h-full rounded-full transition-all duration-500 block" style={{ width: `${Math.max(6, (r.participants / maxPart) * 100)}%`, backgroundColor: REGION_COLORS[i % REGION_COLORS.length] }} />
                    </span>
                    <span className="text-right font-mono text-[14px] font-bold text-ink">{r.participants}</span>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Top participants strip */}
        {!loading && top.length > 0 && (
          <div className="mt-4 bg-surface border border-line rounded-2xl px-5 py-4">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[12px] uppercase tracking-[.08em] text-muted font-bold mr-1">Yetakchilar</span>
              {top.map(p => (
                <span key={p.userId} className="inline-flex items-center gap-[7px] bg-parchment-2 rounded-full px-[14px] py-[7px]">
                  <span className="font-serif font-bold text-[13px]" style={{ color: p.rank === 1 ? '#9a7b3f' : p.rank === 2 ? '#6b7785' : '#9a6a3f' }}>{p.rank}</span>
                  <span className="text-[13px] font-semibold text-ink whitespace-nowrap max-w-[140px] truncate">{p.name}</span>
                  <span className="text-[12px] font-mono font-bold text-bordo">{p.points}</span>
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Ustozlar reytingi — ajralib turadigan bordo karta (doimo ochiq) */}
        {teachers.length > 0 && (
          <div className="mt-6 rounded-2xl p-6 sm:p-8 relative overflow-hidden shadow-lg" style={{ background: 'linear-gradient(135deg,#0b3b5a 0%,#0877B5 100%)' }}>
            {/* dekorativ gold halqa */}
            <span className="absolute -top-16 -right-16 w-48 h-48 rounded-full border border-gold/20" aria-hidden />
            <span className="absolute -top-10 -right-10 w-32 h-32 rounded-full border border-gold/15" aria-hidden />
            <div className="flex items-end justify-between gap-3 flex-wrap mb-5 relative">
              <div>
                <div className="text-[10.5px] tracking-[.18em] uppercase text-gold font-bold mb-1">Ustozlar dasturi</div>
                <h3 className="font-serif text-[clamp(20px,2.6vw,26px)] font-semibold text-white leading-tight">Eng faol ustozlar reytingi</h3>
                <p className="text-white/75 text-[13px] mt-1.5 max-w-[52ch] leading-relaxed">
                  Eng ko&apos;p ball to&apos;plagan ustozlar pul mukofoti va sovg&apos;alar bilan taqdirlanadi.
                </p>
              </div>
              <a href="/register?ustoz=1" className="inline-flex items-center gap-2 text-[13px] font-semibold px-5 py-[10px] rounded-full bg-bordo text-white hover:bg-bordo-700 transition-colors whitespace-nowrap flex-none">
                Ustoz bo&apos;lish
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
              </a>
            </div>
            <div className="flex flex-col gap-[10px] relative">
              {teachers.map((t) => (
                <div key={t.id} className="flex items-center gap-3 bg-white/[.07] border border-white/[.13] rounded-xl px-4 py-3 hover:bg-white/[.11] transition-colors">
                  <span className="font-serif font-bold text-[16px] w-7 h-7 rounded-full flex items-center justify-center flex-none" style={t.rank <= 3 ? { background: t.rank === 1 ? '#9a7b3f' : t.rank === 2 ? '#b8bcc4' : '#b07d4f', color: '#fff' } : { color: 'rgba(255,255,255,.7)' }}>{t.rank}</span>
                  <div className="min-w-0 flex-1">
                    <div className="text-[14px] font-semibold text-white truncate">{t.name}</div>
                    {t.region && <div className="text-[12px] text-white/55 truncate">{t.region}</div>}
                  </div>
                  <div className="text-center flex-none px-2">
                    <div className="font-mono font-bold text-[14px] text-white leading-none">{t.students}</div>
                    <div className="text-[10.5px] text-white/55 mt-[2px]">o&apos;quvchi</div>
                  </div>
                  <div className="text-center flex-none px-2 border-l border-white/15">
                    <div className="font-mono font-bold text-[15px] text-gold leading-none">{t.points}</div>
                    <div className="text-[10.5px] text-white/55 mt-[2px]">ball</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* CTA */}
        <div className="text-center mt-6">
          <a href="/register" className="inline-flex items-center gap-2 font-semibold text-[14px] px-6 py-[11px] rounded-full bg-bordo text-white hover:bg-bordo-700 transition-colors">
            Siz ham qatnashing va viloyatingizni yuqoriga ko&apos;taring
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
          </a>
        </div>
      </div>
    </section>
  );
}
