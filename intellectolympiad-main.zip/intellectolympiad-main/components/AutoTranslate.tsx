'use client';
import { useEffect } from 'react';
import { getLocale, type Locale } from '@/lib/locale';
import { latnToCyrl } from '@/lib/translit';
import UI_I18N from '@/lib/ui-i18n.json';

/**
 * Statik UI tarjimasi — TO'LIQ offline, hech qanday runtime so'rovi yo'q.
 *   - uz-Cyrl : lokal transliteratsiya (oniy, deterministik)
 *   - ru / en : oldindan tayyorlangan statik katalog (lib/ui-i18n.json)
 *
 * Katalog bir marta (build vaqtida) tuziladi. Foydalanuvchi tilni almashtirganda
 * HECH QANDAY API/OpenAI ishlamaydi — faqat lug'atdan o'qiladi.
 * Lug'atda yo'q matn uz-Latn'da qoladi (xavfsiz fallback).
 */
const DICT = UI_I18N as Record<string, Record<string, string>>;

export default function AutoTranslate() {
  useEffect(() => {
    const originals = new Map<Text, string>();
    let current: Locale = getLocale();
    let observer: MutationObserver | null = null;
    let debounce: ReturnType<typeof setTimeout> | null = null;

    const SKIP = '[data-notranslate],[translate="no"],script,style,noscript,code,pre,textarea,input,select,svg,.font-mono';
    const BRAND = new Set(['Intellect Olympiad', 'IO', 'Click', 'Payme', 'Uzum', 'Telegram', 'Google', 'QR']);
    const hasLetter = (s: string) => /[A-Za-z]/.test(s);
    const codey = (s: string) => /^[\s\d\W]*$/.test(s) || /\bIO-?\d/.test(s) || /@/.test(s) || /https?:\/\//.test(s) || BRAND.has(s.trim());

    const collect = (): Text[] => {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
          const t = node as Text;
          const p = t.parentElement;
          if (!p || p.closest(SKIP)) return NodeFilter.FILTER_REJECT;
          const v = t.nodeValue ?? '';
          if (!v.trim()) return NodeFilter.FILTER_REJECT;
          if (!hasLetter(v) && !originals.has(t)) return NodeFilter.FILTER_REJECT;
          if (codey(v)) return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        },
      });
      const nodes: Text[] = [];
      let n: Node | null;
      while ((n = walker.nextNode())) nodes.push(n as Text);
      return nodes;
    };

    const srcOf = (node: Text): string => {
      if (!originals.has(node)) originals.set(node, node.nodeValue ?? '');
      return originals.get(node) ?? '';
    };

    const pause = (fn: () => void) => {
      observer?.disconnect();
      fn();
      if (document.body) observer?.observe(document.body, { childList: true, characterData: true, subtree: true });
    };

    const restoreAll = () => pause(() => {
      for (const [node, orig] of originals) {
        if (node.isConnected && node.nodeValue !== orig) node.nodeValue = orig;
      }
    });

    const translateOf = (src: string, locale: Locale): string => {
      const raw = src.trim();
      if (!raw) return src;
      if (locale === 'uz-Cyrl') return src.replace(raw, latnToCyrl(raw));
      const hit = DICT[locale]?.[raw];
      return hit ? src.replace(raw, hit) : src; // lug'atda yo'q bo'lsa — asl
    };

    const apply = (locale: Locale) => {
      if (locale === 'uz-Latn') { restoreAll(); return; }
      const nodes = collect();
      pause(() => {
        for (const node of nodes) {
          const out = translateOf(srcOf(node), locale);
          if (node.nodeValue !== out) node.nodeValue = out;
        }
      });
    };

    const schedule = () => {
      if (debounce) clearTimeout(debounce);
      debounce = setTimeout(() => apply(current), 120);
    };

    if (current !== 'uz-Latn') schedule();

    observer = new MutationObserver((muts) => {
      if (muts.some((m) => (m.type === 'childList' ? m.addedNodes.length > 0 : true))) schedule();
    });
    if (document.body) observer.observe(document.body, { childList: true, characterData: true, subtree: true });

    const onLocale = (e: Event) => {
      const next = ((e as CustomEvent<Locale>).detail ?? getLocale());
      if (next === current) return;
      current = next;
      if (next === 'uz-Latn') restoreAll();
      else { restoreAll(); schedule(); }
    };
    window.addEventListener('io-locale', onLocale);

    return () => {
      window.removeEventListener('io-locale', onLocale);
      observer?.disconnect();
      if (debounce) clearTimeout(debounce);
    };
  }, []);

  return null;
}
