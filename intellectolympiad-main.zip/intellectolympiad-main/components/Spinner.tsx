// Chiroyli aylanma yuklash indikatori (Tailwind animate-spin).
export function Spinner({ size = 18, className = '' }: { size?: number; className?: string }) {
  return (
    <svg className={`animate-spin ${className}`} width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden>
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2.5" strokeOpacity="0.2" />
      <path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}

// Markazlashgan yuklash qatori (sahifa/bo'lim yuklanayotganda).
export function LoadingRow({ text = 'Yuklanmoqda…', className = '' }: { text?: string; className?: string }) {
  return (
    <div className={`flex items-center justify-center gap-2.5 text-muted py-12 anim-fade-up ${className}`}>
      <Spinner size={22} className="text-bordo" />
      <span className="text-[14px] font-medium">{text}</span>
    </div>
  );
}

// Skelet (joy ushlab turuvchi yengil shimmer bloklar).
export function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`skeleton rounded-lg ${className}`} />;
}
