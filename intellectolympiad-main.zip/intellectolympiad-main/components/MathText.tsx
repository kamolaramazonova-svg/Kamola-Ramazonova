'use client';

import 'katex/dist/katex.min.css';
import katex from 'katex';

// Matndagi $...$ (yoki $$...$$) LaTeX bo'laklarini KaTeX bilan render qiladi.
// [[IMG:url]] belgilari rasm sifatida AYNAN O'Z JOYIDA chiqadi (Word importdan).
// Oddiy matn HTML-escape qilinadi -> XSS xavfsiz (faqat KaTeX/img markup chiqadi).
function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function renderMath(text: string): string {
  const re = /\$\$([^$]+)\$\$|\$([^$]+)\$/g;
  let out = '';
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null) {
    out += escapeHtml(text.slice(last, m.index));
    const latex = m[1] ?? m[2];
    const display = m[1] != null;
    try {
      out += katex.renderToString(latex, { throwOnError: false, displayMode: display, output: 'html' });
    } catch {
      out += escapeHtml(m[0]);
    }
    last = re.lastIndex;
  }
  out += escapeHtml(text.slice(last));
  return out;
}

// [[IMG:url]] -> <img> (faqat / yoki http(s) bilan boshlanadigan xavfsiz URL'lar)
function renderAll(text: string): string {
  const re = /\[\[IMG:([^\]]+)\]\]/g;
  let out = '';
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null) {
    out += renderMath(text.slice(last, m.index));
    const src = m[1].trim();
    if (/^(https?:\/\/|\/)/i.test(src)) {
      out += `<img src="${escapeHtml(src)}" alt="savol rasmi" loading="lazy" ` +
        `style="max-width:100%;max-height:320px;display:block;margin:8px auto;border-radius:8px" />`;
    }
    last = re.lastIndex;
  }
  out += renderMath(text.slice(last));
  return out;
}

export default function MathText({ text, className }: { text: string; className?: string }) {
  if (!text) return null;
  // $ ham [[IMG ham bo'lmasa - oddiy matn (render shart emas, eng xavfsiz yo'l)
  if (!text.includes('$') && !text.includes('[[IMG:')) return <span className={className}>{text}</span>;
  return <span className={className} dangerouslySetInnerHTML={{ __html: renderAll(text) }} />;
}
