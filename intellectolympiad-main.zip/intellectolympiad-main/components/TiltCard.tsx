'use client';
import { useRef, type ReactNode, type CSSProperties } from 'react';

/** Sichqoncha bo'ylab 3D egiluvchi karta (wow effekt). Mobil/touch'da statik. */
export default function TiltCard({ children, className, style, max = 9 }: { children: ReactNode; className?: string; style?: CSSProperties; max?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const onMove = (e: React.MouseEvent) => {
    const el = ref.current;
    if (!el || window.matchMedia('(pointer: coarse)').matches) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;
    el.style.transform = `perspective(1100px) rotateY(${px * max}deg) rotateX(${-py * max}deg) scale(1.015)`;
  };
  const reset = () => { if (ref.current) ref.current.style.transform = ''; };
  return (
    <div ref={ref} className={`tilt ${className ?? ''}`} style={style} onMouseMove={onMove} onMouseLeave={reset}>
      {children}
    </div>
  );
}
