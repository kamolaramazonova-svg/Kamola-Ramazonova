'use client';
import { useEffect, useState } from 'react';
import { referral as referralApi, ratings as ratingsApi, type ReferralInfo, type RatingTeacher } from '@/lib/api';
import { LoadingRow } from '@/components/Spinner';

// Ustoz uchun referal panel: havola, statistika, reyting o'rni, ball sxemasi va mukofotlar.
export default function TeacherPanel({ token, teacherId, teacherName }: { token: string; teacherId?: string; teacherName?: string }) {
  const [info, setInfo] = useState<ReferralInfo | null>(null);
  const [me, setMe] = useState<RatingTeacher | null>(null);
  const [totalTeachers, setTotalTeachers] = useState(0);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let alive = true;
    Promise.all([
      referralApi.me(token).catch(() => null),
      ratingsApi.teachers({ limit: 500 }).catch(() => ({ teachers: [] as RatingTeacher[] })),
    ]).then(([ri, board]) => {
      if (!alive) return;
      setInfo(ri);
      setTotalTeachers(board.teachers.length);
      const mine = teacherId ? board.teachers.find(t => t.id === teacherId) : null;
      setMe(mine ?? null);
    }).finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
  }, [token, teacherId]);

  const code = info?.code ?? me?.referralCode ?? '';
  const link = code && typeof window !== 'undefined' ? `${window.location.origin}/register?ref=${code}` : '';

  const copy = async (text: string) => {
    try { await navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1800); } catch { /* ignore */ }
  };

  const shareTelegram = () => {
    const text = `Intellect Olympiad — bilim olimpiadasiga qo'shiling! Ustozim ${teacherName ?? ''} havolasi orqali ro'yxatdan o'ting:`;
    window.open(`https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent(text)}`, '_blank');
  };

  if (loading) return <LoadingRow className="py-16" />;

  const students = info?.studentCount ?? me?.students ?? 0;
  const points = me?.points ?? students * 5;
  const rank = me?.rank ?? null;
  const wins = me?.wins ?? 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-serif text-[26px] font-semibold text-ink">Ustozlar dasturi</h1>
        <p className="text-muted text-[14.5px] mt-1">
          Referal havolangizni o&apos;quvchilaringizga ulashing — har bir ishtirokchi uchun ball to&apos;playsiz, reytingda yuqorilaysiz va mukofot yutib olasiz.
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "O'quvchilarim", value: students, sub: 'havola orqali' },
          { label: 'Jami ball', value: points, sub: 'reyting bo\'yicha' },
          { label: 'Reytingdagi o\'rnim', value: rank != null ? `#${rank}` : '—', sub: rank != null ? `/ ${totalTeachers} ustoz` : 'hali yo\'q' },
          { label: 'Sovrinli o\'rinlar', value: wins, sub: '1-3 o\'rin' },
        ].map((s, i) => (
          <div key={i} className="bg-surface border border-line rounded-xl p-5 shadow-sm">
            <div className="text-[11px] uppercase tracking-[.1em] text-muted font-bold">{s.label}</div>
            <div className="font-serif text-[28px] font-bold text-bordo leading-none mt-2">{s.value}</div>
            <div className="text-[12px] text-muted mt-1">{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Referral link */}
      <div className="bg-surface border border-line rounded-xl p-6 shadow-sm">
        <div className="text-[13px] font-bold uppercase tracking-[.1em] text-muted mb-3">Referal havolangiz</div>
        {code ? (
          <>
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1 font-mono text-[13.5px] text-ink bg-parchment border border-line-2 rounded-lg px-4 py-3 break-all">{link}</div>
              <button onClick={() => copy(link)} className="flex-none inline-flex items-center justify-center gap-2 font-semibold text-[14px] px-5 py-3 rounded-lg bg-bordo text-white hover:bg-bordo-700 transition-colors">
                {copied ? 'Nusxa olindi ✓' : 'Nusxa olish'}
              </button>
              <button onClick={shareTelegram} className="flex-none inline-flex items-center justify-center gap-2 font-semibold text-[14px] px-5 py-3 rounded-lg border border-line-2 text-ink hover:bg-parchment-2 transition-colors">
                Telegramda ulashish
              </button>
            </div>
            <div className="mt-3 text-[13px] text-muted">
              Kod: <span className="font-mono font-semibold text-ink">{code}</span> — o&apos;quvchi ro&apos;yxatdan o&apos;tishda shu kodni kiritishi yoki havola orqali kelishi yetarli.
            </div>
          </>
        ) : (
          <div className="text-muted text-[14px]">Referal kodingiz tayyorlanmoqda. Sahifani yangilang.</div>
        )}
      </div>

      {/* Mening o'quvchilarim — havola orqali kelganlar ro'yxati */}
      <div className="bg-surface border border-line rounded-xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4 gap-3 flex-wrap">
          <div className="text-[13px] font-bold uppercase tracking-[.1em] text-muted">Mening o&apos;quvchilarim</div>
          <span className="text-[12px] text-muted">Jami <b className="text-ink font-mono">{info?.students?.length ?? 0}</b> ta</span>
        </div>
        {(info?.students?.length ?? 0) === 0 ? (
          <div className="text-[13.5px] text-muted py-8 text-center">
            Hali havolangiz orqali o&apos;quvchi qo&apos;shilmagan. Yuqoridagi referal havolani o&apos;quvchilaringizga ulashing.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-[13.5px] min-w-[460px]">
              <thead>
                <tr className="text-left text-[11px] uppercase tracking-wide text-muted border-b border-line">
                  <th className="py-2 pr-3 font-semibold">O&apos;quvchi</th>
                  <th className="py-2 px-3 font-semibold">Viloyat</th>
                  <th className="py-2 px-3 font-semibold text-center">Olimpiada</th>
                  <th className="py-2 pl-3 font-semibold text-right">Qo&apos;shilgan</th>
                </tr>
              </thead>
              <tbody>
                {info!.students.map((s) => (
                  <tr key={s.id} className="border-b border-line last:border-0 hover:bg-parchment/50 transition-colors">
                    <td className="py-2.5 pr-3">
                      <div className="font-semibold text-ink">{s.name}</div>
                      {s.school && <div className="text-[11.5px] text-muted">{s.school}</div>}
                    </td>
                    <td className="py-2.5 px-3 text-ink-2">{s.region ?? '—'}</td>
                    <td className="py-2.5 px-3 text-center font-mono font-semibold text-ink-2">{s.olympiads}</td>
                    <td className="py-2.5 pl-3 text-right text-muted text-[12.5px]">{new Date(s.joinedAt).toLocaleDateString('uz-UZ')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Point scheme */}
        <div className="bg-surface border border-line rounded-xl p-6 shadow-sm">
          <div className="text-[13px] font-bold uppercase tracking-[.1em] text-muted mb-4">Ball tizimi</div>
          <ul className="space-y-3">
            {[
              { t: "O'quvchi havola orqali ro'yxatdan o'tdi", p: '+5' },
              { t: "O'quvchi 3-o'rinni egalladi", p: '+10' },
              { t: "O'quvchi 2-o'rinni egalladi", p: '+20' },
              { t: "O'quvchi 1-o'rinni egalladi", p: '+30' },
            ].map((r, i) => (
              <li key={i} className="flex items-center justify-between gap-3 text-[14px]">
                <span className="text-ink-2">{r.t}</span>
                <span className="font-bold text-bordo font-mono flex-none">{r.p}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Prizes */}
        <div className="bg-bordo text-white rounded-xl p-6 shadow-sm relative overflow-hidden">
          <div className="text-[13px] font-bold uppercase tracking-[.1em] text-[#cfdde8] mb-4">Ustozlar uchun mukofotlar</div>
          <ul className="space-y-3">
            {[
              { place: '1-o\'rin', prize: 'Pul mukofoti + maxsus sovg\'a' },
              { place: '2-o\'rin', prize: 'Pul mukofoti' },
              { place: '3-o\'rin', prize: "Qimmatbaho sovg'a" },
              { place: 'Top 10', prize: 'Faxriy yorliq va sertifikat' },
            ].map((r, i) => (
              <li key={i} className="flex items-center gap-3 bg-white/[.08] border border-white/15 rounded-lg px-4 py-3">
                <span className="w-9 h-9 rounded-full bg-bordo text-white flex items-center justify-center font-bold text-[13px] flex-none">{i + 1}</span>
                <div>
                  <div className="font-semibold text-[14px]">{r.place}</div>
                  <div className="text-[12.5px] text-white/75">{r.prize}</div>
                </div>
              </li>
            ))}
          </ul>
          <p className="text-[12px] text-white/70 mt-4 leading-relaxed">
            Mukofotlar mavsum yakunida eng yuqori ball to&apos;plagan ustozlarga topshiriladi.
          </p>
        </div>
      </div>
    </div>
  );
}
