'use client';
import { useEffect } from 'react';

/** Scroll'da elementlar (data-reveal) ko'rinish maydoniga kirganda yumshoq paydo bo'ladi. */
export default function ScrollReveal() {
  useEffect(() => {
    const reveal = () => {
      const els = Array.from(document.querySelectorAll<HTMLElement>('[data-reveal]:not(.reveal-in)'));
      if (!els.length) return;
      if (!('IntersectionObserver' in window)) {
        els.forEach(e => e.classList.add('reveal-in'));
        return;
      }
      const io = new IntersectionObserver((entries) => {
        entries.forEach(en => {
          if (en.isIntersecting) {
            en.target.classList.add('reveal-in');
            io.unobserve(en.target);
          }
        });
      }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
      els.forEach(e => io.observe(e));
    };
    // Initial + re-scan a bit later (async-loaded sections: olimpiadalar, jury, reyting)
    reveal();
    const t = setTimeout(reveal, 900);
    return () => clearTimeout(t);
  }, []);
  return null;
}
